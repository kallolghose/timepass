In-order to get your activation license,send an email to:
evaluation@netcompss.com
The request email should contain your company name and the reason you want to evaluate JEC/EWSJ,
your email address should be a valid company, academic institute email address. 
Activation license will not be sent to webmails addresses.
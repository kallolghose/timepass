//import java.io.BufferedReader;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.TimeZone;

import jec.EWSConnectorFactory;
import jec.EWSSearchExpression;
import jec.ExchangeConstants;
import jec.ExchangeGeneralException;
import jec.dto.EWSEventDTO;
import jec.EWSConnectorInterface;

import java.util.Date;
import java.text.SimpleDateFormat;
import java.text.ParseException;

import jec.dto.AttachmentDTO;
import jec.dto.EWSContactDTO;
import jec.dto.EWSContactShallowDTO;
import jec.dto.EWSDTO;
import jec.dto.EWSEmailDTO;
import jec.dto.EWSExchangeVersionDTO;
import jec.dto.EWSFolderDTO;
import jec.dto.EWSGeneralConfiguration;
import jec.dto.EWSMailBoxDTO;
import jec.dto.EWSNotificationEventDTO;
import jec.dto.EWSNotificationsSubscriptionDTO;
import jec.dto.EWSOccurrenceDTO;
import jec.dto.EWSOofDTO;
import jec.dto.EWSRecurrence;
import jec.dto.EWSSorter;
import jec.dto.EWSTaskShallowDTO;
import jec.dto.EWSUDProp;
import jec.dto.EWSUpdateEventConfiguration;
import jec.dto.EmailAddressDTO;
import jec.dto.ExchangeAddressDTO;
import jec.dto.EWSTaskDTO;
import jec.dto.ExchangeEmailDTO;
import jec.dto.ExchangeEmailShallowDTO;
import jec.dto.ExchangeEventAttendeeDTO;
import jec.framework.exchange.exception.TrialLicenseException;
import jec.utils.AppLogger;
import jec.utils.EncodeHTML;


public class EWSJExamples {

    //=============================================================

//	static String _exchangeHost = "WIN-TXG30DYGNZS";
	static String _exchangeHost = "192.168.154.128";
	static String _userName = "test14";
	static String _password = "Kikaha58";
	static String _accountName = "test14";
    static String _domain = "test.exch2k10.msg";
	
      
    static String _email = "test1@domain1.com";
    static String _prefix = "Exchange";
    static boolean _useSSL = true;

    // =============================================================


    public static void main(String[] args) {
        try {
            BufferedReader in = new BufferedReader(new InputStreamReader(System.
                    in));
            String str = null;
            System.out.println("Welcome to EWSJ example!");
            System.out.println(
                    "To use the main default values just press <Enter>");
            System.out.println("");
            System.out.println("Please insert Exchange IP or host name: ");
            try {
                str = in.readLine();
            } catch (IOException ex1) {
                ex1.printStackTrace();
            }
            if ((str != null) && (!str.equals("")))
                _exchangeHost = str;
            System.out.println("Exchange Host:" + _exchangeHost);
            System.out.println("");

            System.out.println("Please insert Exchange username: ");
            try {
                str = in.readLine();
            } catch (IOException ex1) {
                ex1.printStackTrace();
            }
            if ((str != null) && (!str.equals("")))
                _userName = str;
            System.out.println("");
            System.out.println("userName:" +
                               _userName);

            System.out.print("Please insert Exchange password: ");
            try {
                str = in.readLine();
            } catch (IOException ex1) {
                ex1.printStackTrace();
            }
            if ((str != null) && (!str.equals("")))
                _password = str;
            System.out.println("");
            System.out.println("Password:" +
                               _password);

            System.out.print(
                    "Please insert account/mailbox name (in most cases its the same as the user name): ");
            try {
                str = in.readLine();
            } catch (IOException ex1) {
                ex1.printStackTrace();
            }
            if ((str != null) && (!str.equals("")))
                _accountName = str;
            System.out.println("");
            System.out.println("Account Name:" + _accountName);

            System.out.print(
                    "If your exchange is configured to use SSL/HTTPS write true, if not write false:");
            try {
                str = in.readLine();
            } catch (IOException ex1) {
                ex1.printStackTrace();
            }
            if ((str != null) && (!str.equals(""))) {
                if ((str.equals("true") || str.equals("True"))) {
                    _useSSL = true;
                } else if ((str.equals("false") || str.equals("False"))) {
                    _useSSL = false;
                }
            }
            System.out.println("");
            System.out.println("useSSL:" + _useSSL);

            //=========================================================================

            
            // contacts
            getContactsExample();
            createContactExample();
            updateContactExample();
            getContactFullExample();
            getPublicContactsExample();
            getContactsUsingFolderIdExample();
            updateContactOneFieldExample();
            resolveNameExample();
            getContactExtendedFieldExample();
            setContactExtendedFieldExample();
            setContactTitleUsingExtendedFieldExample();
            getContactTitleUsingExtendedFieldExample();
            expandDLExample();
            
            

            //  email
            getEmailsHeadersExample();
            getEmailIdsExample();
            updateEmailReadFlagExample();
            getEmailsShallowFromFolderIdExample();
            getFullEmailExample();
            getFullEmailUsingSearchSubject();
            sendEmailExample();
            sendEmailWithAttachmentsExample();
            sendEmailWithInlineAttachmentExample();
            createEmailExample();
            replyOrForwardEmailExample();
            getEmailsFromEmailSubFolderExample();
            createEmailAndSendItExample();

            // calendar
            getEventsExample();
            addEventExample();
            addEventToCustomFolderExample();
            addAndUpdateAppointmentExample();
            addAllDayEventExample();
            addEventWithAttendeesAndDeleteExample();
            updateEventExample();
            updateEventOneFieldExample();
            updateEventTimeZoneExchange2007Example();
            addEventWithManualTimezoneSettingExample();
            addAllDayEventExchange2010Example();
            updateEventTimeZone2010sp1Example();
            getFullEventExample();
            getFullEventsExample();
            getEventAttendeesResponseTypeExample();
            getEventsUsingFolderIdExample();
            addEventAndGetItByIDExample();
            getUserAvailabilityDataStrExample();
            updateEventAttendeesExample();
            removeEventAttendeesExample();
            getRecurrentEventsExample();
            addGetUpdateDeleteRecurrentEventExample();
            getRecurrentOccurrencesEventsExample();
            getRecurrentMastersAllPropsAndUDFieldsExample();
            getDeletedOccurrencesExample();
            getFirstLastOccurrencesUsingMasterExample();
            getMeetingRequestAndAcceptExample();
            getModifiedOccurrencesUsingMasterExample();
            getEventsWithUserDefinedPropertiesExample();
            
 
            // tasks
            allBasicTaskOperationsExample();
            getTasksExample();
            getFullTaskExample();

            // filters and sorters
            getContactsWithFreeTextFilterExample();
            getEmailsHeadersWithFreeTextDateRestrictionAndSorterExample();
            getEventsWithFreeTextFilterExample();
            getEventsWithFilterExample();
            getEventsWithFilterAndSorterExample();
            getContactsWithFilterExample();
            getContactsWithFilterAndSorterExample();
            getEmailsHeadersWithContainsFilterExample();
            getEmailsWithIsReadAndSinceFilterExample();
            getTasksWithFilterExample();
            getTasksWithFilterAndSorterExample();
            getDeletedEventsFilterExample();
            getUnReadMeetingRequestsExample();
            getItemsNumberExample();
            getEmailsWithPagingExample();
            getEmailsWithPagingExample2();

            // sharing and impersonation
            accessAnotherUserCalendarExample();
            accessAnotherUserEmailsExample();
            accessAnotherUserContactsExample();
            getAllFoldersFromAnotherUserAccountUsingImpersonationExample();
            addEventToAnotherUserCalendarExample();
            createTaskToAnotherUser();
            createContactToAnotherUserExample();
            updateContactWithAccessRightsSharingExample();
            sendEmailUsingAccessRightsExample();
            sendEmailUsingImpersonationExample();
            updateEventTimeZone2010sp1WithMailBoxSharingExample();
            sendEmailFromGroupExample();
            

            // notifications
            notificationsExample();
            notificationsCalendarExample();
            notificationsDeleteEventExample();
            notifications2CallsExample();
 
            // folders
            getAllFoldersExample();
            getSubFoldersExample();
            getAllPublicFoldersExample();
            
            getSubFoldersByIdExample();
            createFolderAndDeleteItExample();

            // misc
            deleteEventAttachmentExample();
            deleteItemExample();
            batchDeleteItemsExample();
            getUserDefinedPropertyValueExample();
            getUserDefinedPropertiesValuesExample();
            updateUserDefinedPropertyValueExample();
            updateUserDefinedPropertiesExample();
            disableNTLMAuthenticationExample();
            explicitPrivateKeyStroreLocationExample();
            settingPrivateKeyStrorePasswordExample();
             createConnectorWithExplicitLicenseFileLocationExample();
            // its possible to use this method to add attachments to tasks, contacts, emails, and events.
            addAttachmentsToEventExample();
            explicitLog4jPropFileLocationExample();
            updateItemFieldToNull();
            setOOFReplyExample();
            convertEmailIdToOwaIdExample();
            getExchangeVersionExample();
            isItemExistExample();
            getOofReplayExample();
            moveItemExample();
            addEventWithSessionPersistanceExample();
            runRemotePowerShellScriptExample();
            runWithKeyStoreInJarExample();
            markAsJunkExample();
            proxyExample();
    
           //TODO

           //=========================================================================

        } catch (ExchangeGeneralException ex) {
            ex.printStackTrace();
        }
    }


    public static void getAllEventsExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);

        ArrayList events = connector.getAllEvents();
        for (int i = 0; i < events.size(); i++) {
            System.out.println(((EWSEventDTO) events.get(i)).getSubject());
            System.out.println(((EWSEventDTO) events.get(i)).getLocation());
            System.out.println(((EWSEventDTO) events.get(i)).getStartDate());
            System.out.println(((EWSEventDTO) events.get(i)).getEndDate());
            System.out.println(((EWSEventDTO) events.get(i)).
                               isRecurrent());
            System.out.println(((EWSEventDTO) events.get(i)).
                               isAllDayEvent());
            System.out.println(((EWSEventDTO) events.get(i)).getImportance());
            System.out.println(((EWSEventDTO) events.get(i)).getBusyStatus());
            System.out.println(((EWSEventDTO) events.get(i)).getSensitivity());
            System.out.println("");
        }
    }

    public static void getEventsExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);

        SimpleDateFormat dateFormat = new SimpleDateFormat(
                "yyyy-MM-dd HH:mm:ss");
        Date startDate = null;
        Date endDate = null;
        try {
            startDate = dateFormat.parse("2009-01-20 06:00:00");
            endDate = dateFormat.parse("2009-01-20 23:00:00");
        } catch (ParseException ex) {
            ex.printStackTrace();
        }

        ArrayList events = connector.getEvents(startDate, endDate);
        System.out.println("Number of Events: " + events.size() );
        for (int i = 0; i < events.size(); i++) {
        	System.out.println(((EWSEventDTO) events.get(i)).getId());
        	System.out.println(((EWSEventDTO) events.get(i)).getChangeKey());
            System.out.println(((EWSEventDTO) events.get(i)).getSubject());
            System.out.println(((EWSEventDTO) events.get(i)).getLocation());
            System.out.println(((EWSEventDTO) events.get(i)).getStartDate());
            System.out.println(((EWSEventDTO) events.get(i)).getEndDate());
            System.out.println(((EWSEventDTO) events.get(i)).
                               isRecurrent());
            System.out.println(((EWSEventDTO) events.get(i)).
                               isAllDayEvent());
            System.out.println(((EWSEventDTO) events.get(i)).getImportance());
            System.out.println(((EWSEventDTO) events.get(i)).getBusyStatus());
            System.out.println(((EWSEventDTO) events.get(i)).getSensitivity());

            System.out.println("");
        }
    }


    public static void getEventsWithUserDefinedPropertiesExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);

        SimpleDateFormat dateFormat = new SimpleDateFormat(
                "yyyy-MM-dd HH:mm:ss");
        Date startDate = null;
        Date endDate = null;
        try {
            startDate = dateFormat.parse("2009-01-01 06:00:00");
            endDate = dateFormat.parse("2009-01-07 23:00:00");
        } catch (ParseException ex) {
            ex.printStackTrace();
        }
        EWSUDProp[] propNameTypeArr = {new EWSUDProp("udtest1", "String", null), new EWSUDProp("udtest2", "String", null)};
        ArrayList events = connector.getEventsWithCustomProperties(-1, startDate, endDate, null, null, propNameTypeArr);
        System.out.println("Number of Events: " + events.size() );
        for (int i = 0; i < events.size(); i++) {
        	System.out.println(((EWSEventDTO) events.get(i)).getId());
        	System.out.println(((EWSEventDTO) events.get(i)).getChangeKey());
            System.out.println(((EWSEventDTO) events.get(i)).getSubject());
            System.out.println(((EWSEventDTO) events.get(i)).getLocation());
            System.out.println(((EWSEventDTO) events.get(i)).getStartDate());
            System.out.println(((EWSEventDTO) events.get(i)).getEndDate());
            System.out.println(((EWSEventDTO) events.get(i)).
                               isRecurrent());
            System.out.println(((EWSEventDTO) events.get(i)).
                               isAllDayEvent());
            System.out.println(((EWSEventDTO) events.get(i)).getImportance());
            System.out.println(((EWSEventDTO) events.get(i)).getBusyStatus());
            System.out.println(((EWSEventDTO) events.get(i)).getSensitivity());
            System.out.println(((EWSEventDTO) events.get(i)).getCategoriesStr());

            ArrayList props = ((EWSEventDTO) events.get(i)).getUDProps();
            if (props != null) {
            	for (int j = 0; j < props.size(); j++) {
            		EWSUDProp prop = (EWSUDProp)props.get(j);
            		System.out.println("prop" + j + " Name: " + prop.getName());
            		System.out.println("prop" + j + " Value: " + prop.getValue());
            	}
            }

            System.out.println("");
        }
    }



    public static void getFullEventExample() throws ExchangeGeneralException {

            EWSConnectorFactory factory = new EWSConnectorFactory();
            EWSConnectorInterface connector = null;

            connector = factory.createEWSConnector(_exchangeHost,
                                                   _userName,
                                                   _password,
                                                   _prefix, _useSSL, _accountName);

            SimpleDateFormat dateFormat = new SimpleDateFormat(
                    "yyyy-MM-dd HH:mm:ss");
            Date startDate = null;
            Date endDate = null;
            try {
            	startDate = dateFormat.parse("2009-01-11 06:00:00");
                endDate = dateFormat.parse("2009-01-13 23:00:00");
            } catch (ParseException ex) {
                ex.printStackTrace();
            }

            ArrayList events = connector.getEvents(startDate, endDate);
            System.out.print("Num of events:" + events.size());
            if (events.size() > 0) {
            	for (int i = 0; i < events.size(); i++) {
            		String id = ((EWSEventDTO)events.get(i)).getId();
            		String changeKey = ((EWSEventDTO)events.get(i)).getChangeKey();
            		System.out.println("===== Getting EventFull for Id: " + id + " changeKey:" + changeKey +" =====");

            		EWSEventDTO event = connector.getEventFull(id, changeKey);
            		//EWSEventDTO event = connector.getEventFull(id);
            		
            		System.out.println("event.getParentFolderId(): " + event.getParentFolderId());
            		System.out.println("event.getParentFolderChangeKey(): " + event.getParentFolderChangeKey());
            		System.out.println(event.getStartDate());
            		System.out.println(event.getSubject());
            		System.out.println(event.getStartDate());
            		System.out.println(event.getEndDate());
            		System.out.println("isReminderIsSet: " + event.isReminderIsSet());
            		System.out.println("getReminderMinutesBeforeStart: " + event.getReminderMinutesBeforeStart());
            		System.out.println("event.getDescription(): " + event.getDescription());
            		System.out.println("event.isHtmlDescription(): " + event.isHtmlDescription());
             		System.out.println("isAllDayEvent: " + event.isAllDayEvent());
             		System.out.println("getCategoriesStr: " + event.getCategoriesStr());
             		System.out.println("getOrganizer: " + event.getOrganizer());
             		System.out.println("getDateTimeCreated: " + event.getDateTimeCreated());
             		System.out.println("event.getDateTimeSent(): " + event.getDateTimeSent());
            		//////////////////////////////getting event attendees ///////////////////////////
            		if ( event.getTo()!= null) {
            			System.out.println(" number of attendees: " + event.getTo().size());

            			for (int j = 0; j < (event).getTo().
            			size(); j++) {
            				System.out.println("attendee " + j + ":" + ((ExchangeEventAttendeeDTO)(event).getTo().get(j)).getDisplayName() +
            						" " + ((ExchangeEventAttendeeDTO)(event).getTo().get(j)).getEmailAddr()   );

            				if (((ExchangeEventAttendeeDTO)(event).getTo().get(j)).getType() == 1) {
            					System.out.println("REQUIRED");
            				}
            				else if (((ExchangeEventAttendeeDTO)(event).getTo().get(j)).getType() == 3) {
            					System.out.println("OPTIONAL");
            				}
            				System.out.println("");
            			}
            		}
            		////////////////////////////////////////////////////////////////////////////////////////////////


            		//////////////////////////////getting event attachments ///////////////////////////
            		if (((EWSEventDTO) event).getAttachments() != null) {
            			for (int j=0 ; j < ((EWSEventDTO) event).getAttachments().length; j++ ) {
            				String attachmentId = ((EWSEventDTO) event).getAttachments()[j].getId();
            				String attachmentName = ((EWSEventDTO) event).getAttachments()[j].getName();
            				System.out.println("attachmentId: " + attachmentId);
            				System.out.println("attachmentName: " + attachmentName);
            				System.out.println("contentType: " + ((EWSEventDTO) event).getAttachments()[j].getContentType());
            				System.out.println("");
            				System.out.println("");

            				// for this example we get only the first attachment
            				if (j == 0) {
            					System.out.println("============ get full attachment start ==========");
            					AttachmentDTO attachment = connector.getFullAttachment(attachmentId);
            					try {
            						String filePath = null;
            						if (attachment.getName() != null)
            							filePath = "c:/temp/" + attachment.getName();
            						else
            							filePath = "c:/temp/attachment.txt";

            						System.out.println("Make sure " + attachment.getName() + " Do not contain illigal filename charecters, or it will not be saved.");

            						FileOutputStream f = new FileOutputStream(filePath);
            						f.write(attachment.getByteData());
            						System.out.println("attachment was saved to " + filePath);
            						if (attachment.getContentType() != null && attachment.getContentType().equals("outlook/rfc822")) {
            							System.out.println("This is a msg attachment.");
            							System.out.println("Creating EWSEmailDTO...");
            							String msgXML = new String (attachment.getByteData());
            							EWSEmailDTO emailMsg = connector.parseFullEmailRFC822MsgFromXMLString(msgXML);
            							System.out.println("emailMsg.getSubject(): " + emailMsg.getSubject());
            							System.out.println("emailMsg.getBody(): " + emailMsg.getBody());
            							if (emailMsg.getAttachments() != null)
            								System.out.println("mailMsg.getAttachments().length: " + emailMsg.getAttachments().length);
            						}
            					} catch (FileNotFoundException e) {

            						e.printStackTrace();
            					} catch (IOException e) {

            						e.printStackTrace();
            					}

            					System.out.println("============ get full attachment end ============");
            				}
            			}
            		}
            		//////////////////////////////getting event attachments ///////////////////////////


            		System.out.println("Num of events:" + events.size());

            		System.out.println("==================================================================================");
            	}
            }



    }


    public static void getContactsExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;


        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);
        
        //connector.setUseNTLMAuthentication(false);
        
        ArrayList contacts = connector.getContacts();
        for (int i = 0; i < contacts.size(); i++) {
        	System.out.println(((EWSContactShallowDTO) contacts.get(i)).getId());
        	System.out.println(((EWSContactShallowDTO) contacts.get(i)).getChangeKey());
            System.out.println(((EWSContactShallowDTO) contacts.get(i)).getFirstName());
            System.out.println(((EWSContactShallowDTO) contacts.get(i)).getSurname());
            System.out.println(((EWSContactShallowDTO) contacts.get(i)).getEmailAddress1());
            System.out.println(((EWSContactShallowDTO) contacts.get(i)).getBusinessPhone());
            System.out.println(((EWSContactShallowDTO) contacts.get(i)).getHomePhone());
            System.out.println(((EWSContactShallowDTO) contacts.get(i)).getMobilePhone());
            System.out.println(((EWSContactShallowDTO) contacts.get(i)).getCompanyName());
            System.out.println("");
        }

    }

    public static void getPublicContactsExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);

        ArrayList contacts = connector.getPublicContacts();
        for (int i = 0; i < contacts.size(); i++) {
        	System.out.println(((EWSContactShallowDTO) contacts.get(i)).getId());
        	System.out.println(((EWSContactShallowDTO) contacts.get(i)).getChangeKey());
            System.out.println(((EWSContactShallowDTO) contacts.get(i)).getFirstName());
            System.out.println(((EWSContactShallowDTO) contacts.get(i)).getSurname());
            System.out.println(((EWSContactShallowDTO) contacts.get(i)).getEmailAddress1());
            System.out.println(((EWSContactShallowDTO) contacts.get(i)).getBusinessPhone());
            System.out.println(((EWSContactShallowDTO) contacts.get(i)).getHomePhone());
            System.out.println(((EWSContactShallowDTO) contacts.get(i)).getMobilePhone());
            System.out.println("");
        }

    }



    public static void getEmailsHeadersExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);

        // un-commnent to change the default folder (inbox)
        //connector.setFolder(ExchangeConstants.FOLDER_ENUM_drafts);
        connector.setFolder(ExchangeConstants.FOLDER_ENUM_inbox);

        ArrayList emails = connector.getEmailsShallow();
        for (int i = 0; i < emails.size(); i++) {
        	System.out.println(((ExchangeEmailShallowDTO) emails.get(i)).getId());
        	System.out.println(((ExchangeEmailShallowDTO) emails.get(i)).getChangeKey());
            System.out.println(((ExchangeEmailShallowDTO) emails.get(i)).getSubject());
            System.out.println(((ExchangeEmailShallowDTO) emails.get(i)).getTo());
            System.out.println(((ExchangeEmailShallowDTO) emails.get(i)).getCc());
            System.out.println(((ExchangeEmailShallowDTO) emails.get(i)).getDateReceived());
            System.out.println(((ExchangeEmailShallowDTO) emails.get(i)).getImportance());
            System.out.println(((ExchangeEmailShallowDTO) emails.get(i)).getSensitivity());
            System.out.println(((ExchangeEmailShallowDTO) emails.get(i)).isHasAttachments());
            System.out.println(((ExchangeEmailShallowDTO) emails.get(i)).isRead());
            System.out.println(((ExchangeEmailShallowDTO) emails.get(i)).getFrom());
            System.out.println("");
        }

    }

    public static void getEmailIdsExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        EWSGeneralConfiguration.setExchangeVersion(EWSGeneralConfiguration.EXCHANGE_VERSION_2010SP1);
        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);
        //connector.setUseNTLMAuthentication(false);

        // un-commnent to change the default folder (inbox)
        //connector.setFolder(ExchangeConstants.FOLDER_ENUM_drafts);
        connector.setFolder(ExchangeConstants.FOLDER_ENUM_sentitems);

        ArrayList emailIds = connector.getEmailIds(null, null);
        for (int i = 0; i < emailIds.size(); i++) {
        	System.out.println(((EWSDTO) emailIds.get(i)).getId());
        	System.out.println(((EWSDTO) emailIds.get(i)).getChangeKey());

            System.out.println("");
        }

    }

    
    public static void getEmailsHeadersWithFreeTextFilterContainsRestrictionExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);

        // un-commnent to change the default folder (inbox)
        connector.setFolder(ExchangeConstants.FOLDER_ENUM_drafts);

        // set this xml according the Restriction xml documentation.
        // http://msdn.microsoft.com/en-us/library/aa563791(EXCHG.80).aspx
        //String searchXmlStrEqualToSubject = "<Restriction><t:IsEqualTo><t:FieldURI FieldURI=\"item:Subject\"/><t:FieldURIOrConstant><t:Constant Value=\"test event\"/></t:FieldURIOrConstant></t:IsEqualTo></Restriction>";
        
        //String searchXmlStrSubString = "<Restriction><t:Contains ContainmentMode=\"Substring\" ContainmentComparison=\"IgnoreCaseAndNonSpacingCharacters\"><t:FieldURI FieldURI=\"item:Subject\"/><t:Constant Value=\"test em\"/></t:Contains></Restriction>";
        
        String searchXmlStrSubString = "<Restriction>" 
        	       + "<t:Or>"
        	+ "<t:Contains ContainmentMode=\"Substring\" ContainmentComparison=\"IgnoreCase\">"
        	+ "<t:FieldURI FieldURI=\"item:Body\"/>"
        	+ "<t:Constant Value=\"" + "filter" + "\"/></t:Contains>"
        	+ "<t:Contains ContainmentMode=\"Substring\" ContainmentComparison=\"IgnoreCase\">"
        	+ "<t:FieldURI FieldURI=\"item:Subject\"/>"
        	+ "<t:Constant Value=\"" + "test" + "\"/></t:Contains>"
        	+ "</t:Or>"
        	+ "</Restriction>";
        
        
        EWSSearchExpression searchExpression = new EWSSearchExpression(searchXmlStrSubString);

        ArrayList emails = connector.getEmailsShallow(searchExpression);
        for (int i = 0; i < emails.size(); i++) {
            System.out.println(((ExchangeEmailShallowDTO) emails.get(i)).getSubject());
            System.out.println(((ExchangeEmailShallowDTO) emails.get(i)).getTo());
            System.out.println(((ExchangeEmailShallowDTO) emails.get(i)).getCc());
            System.out.println(((ExchangeEmailShallowDTO) emails.get(i)).getDateReceived());
            System.out.println("");
        }

    }


    public static void getEmailsHeadersWithFreeTextDateRestrictionAndSorterExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'hh:mm:ss.S'Z'");
        sdf.setTimeZone(TimeZone.getTimeZone("GMT+0"));
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.MONTH, 0);
        Date date = cal.getTime();

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);

        // un-commnent to change the default folder (inbox)
        //connector.setFolder(ExchangeConstants.FOLDER_ENUM_drafts);

        // set this xml according the Restriction xml documentation.
        // http://msdn.microsoft.com/en-us/library/aa563791(EXCHG.80).aspx
        String searchXmlStr = "<Restriction>"
            + "<t:IsGreaterThanOrEqualTo>"
            + "<t:FieldURI FieldURI=\"item:DateTimeSent\"/>"
            + "<t:FieldURIOrConstant>"
            + "<t:Constant Value=\"" + /*sdf.format(date)*/ "2009-01-05T03:42:44.701Z"
            + "\"/>"
            + "</t:FieldURIOrConstant>"
            + "</t:IsGreaterThanOrEqualTo>"
            + "</Restriction>";
        EWSSearchExpression searchExpression = new EWSSearchExpression(searchXmlStr);

        EWSSorter sorter = new EWSSorter(EWSSorter.ORDER_ASCENDING, EWSSorter.FIELD_ORDER_ITEM_DateTimeReceived);

        ArrayList emails = connector.getEmailsShallow(searchExpression, sorter);

        // without sorter
        //ArrayList emails = connector.getEmailsShallow(searchExpression);

        for (int i = 0; i < emails.size(); i++) {
            System.out.println(((ExchangeEmailShallowDTO) emails.get(i)).getSubject());
            System.out.println(((ExchangeEmailShallowDTO) emails.get(i)).getTo());
            System.out.println(((ExchangeEmailShallowDTO) emails.get(i)).getCc());
            System.out.println(((ExchangeEmailShallowDTO) emails.get(i)).getDateReceived());
            System.out.println("");
        }

    }


    public static void addEventExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);


        SimpleDateFormat dateFormat = new SimpleDateFormat(
                "yyyy-MM-dd HH:mm:ss");
        Date startDate = null;
        Date endDate = null;
        try {
        	startDate = dateFormat.parse("2009-01-14 11:00:00");
            endDate = dateFormat.parse("2009-01-14 12:00:00");
        } catch (ParseException ex) {
            ex.printStackTrace();
        }

        EWSEventDTO event = new EWSEventDTO();

        event.setSubject("test event2");

        //event.setDescription("my test event");
        event.setHtmlDescription(true);
        event.setDescription("&lt;b&gt;updated body&lt;b&gt;");
        event.setCategoriesStr("<t:Categories><t:String>Business</t:String><t:String>School</t:String></t:Categories>");

        // setting a body that contain an html tag (using double encoding)
        //event.setDescription("&lt;b&gt;updated body &amp;lt;b&amp;gt;  &lt;b&gt;");


        event.setStartDate(startDate);
        event.setEndDate(endDate);
        event.setLocation("test location");
        event.setReminderIsSet(true);
        event.setReminderMinutesBeforeStart(10);

        String[] result = null;
		try {
			result = connector.createEvent(event);

			System.out.println("id: " + result[0]);
	        System.out.println("changeKey: " + result[1]);
		} catch (ExchangeGeneralException e) {

			e.printStackTrace();
		}


    }

    /**
     * If a calendar item is created without attendees, it is considered an appointment
     * @throws ExchangeGeneralException
     */
    public static void addAndUpdateAppointmentExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);


        SimpleDateFormat dateFormat = new SimpleDateFormat(
                "yyyy-MM-dd HH:mm:ss");
        Date startDate = null;
        Date endDate = null;
        try {
            startDate = dateFormat.parse("2009-01-20 11:00:00");
            endDate = dateFormat.parse("2009-01-20 12:00:00");
        } catch (ParseException ex) {
            ex.printStackTrace();
        }

        EWSEventDTO event = new EWSEventDTO();

        event.setSubject("test event");
        event.setDescription("my test event");
        event.setStartDate(startDate);
        event.setEndDate(endDate);
        event.setLocation("test location");

        String[] result = null;
		try {
			// creating event without sending meeting requests and attendees (appointment)
			result = connector.createEvent(event, false);

			////////// update the appointment
			event.setId(result[0]);
			event.setChangeKey(result[1]);
			event.setSubject("test event updated2");
			connector.updateEvent(event, new EWSUpdateEventConfiguration(EWSUpdateEventConfiguration.SET_ATTENDEES, EWSUpdateEventConfiguration.SEND_MEETING_INVITATIONS_OR_CANCELLATIONS_SendToNone));
			/////////

			System.out.println("id: " + result[0]);
	        System.out.println("changeKey: " + result[1]);
		} catch (ExchangeGeneralException e) {

			e.printStackTrace();
		}


    }


    public static void addAllDayEventExample() throws ExchangeGeneralException {

    	System.out.println("addAllDayEventExample");
        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);


        SimpleDateFormat dateFormat = new SimpleDateFormat(
                "yyyy-MM-dd HH:mm:ss");
        Date startDate = null;
        Date endDate = null;
        try {
            startDate = dateFormat.parse("2009-03-26 08:00:00");
            endDate = dateFormat.parse("2009-03-26 09:00:00");
        } catch (ParseException ex) {
            ex.printStackTrace();
        }

        System.out.println("startDate: " + startDate + " endDate: " + endDate);

        EWSEventDTO event = new EWSEventDTO();

        event.setSubject("test event");
        event.setDescription("my test event");
        event.setStartDate(startDate);
        event.setEndDate(endDate);
        event.setLocation("test location");
        event.setAllDayEvent(true);

        String[] result = null;
		try {
			result = connector.createEvent(event);
			System.out.println("id: " + result[0]);
	        System.out.println("changeKey: " + result[1]);
		} catch (ExchangeGeneralException e) {

			e.printStackTrace();
		}


    }

    public static void addEventWithAttendeesAndDeleteExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);

        SimpleDateFormat dateFormat = new SimpleDateFormat(
                "yyyy-MM-dd HH:mm:ss");
        Date startDate = null;
        Date endDate = null;
        try {
            startDate = dateFormat.parse("2014-10-14 11:00:00");
            endDate = dateFormat.parse("2014-10-14 12:00:00");
        } catch (ParseException ex) {
            ex.printStackTrace();
        }

        EWSEventDTO event = new EWSEventDTO();

        event.setSubject("test event1111");
        event.setDescription("my test event");
        event.setStartDate(startDate);
        event.setEndDate(endDate);
        event.setLocation("test location");



        ExchangeEventAttendeeDTO to2 = new ExchangeEventAttendeeDTO();
        to2.setType(ExchangeEventAttendeeDTO.ATTENDEE_TYPE_REQUIRED);
        to2.setEmailAddr("test2@domain1.com");
        event.addTo(to2);


        ExchangeEventAttendeeDTO to3 = new ExchangeEventAttendeeDTO();
        to3.setType(ExchangeEventAttendeeDTO.ATTENDEE_TYPE_OPTIONAL);
        to3.setEmailAddr("test3@domain1.com");
        event.addTo(to3);

        String[] result = connector.createEvent(event);

        // create event without sending meeting requests
		//result = connector.createEvent(event, /*sendMeetingReqs*/ false);

		// create event without sending meeting requests
        //String[] result = connector.createEvent(event, false);

        System.out.println("id: " + result[0]);
        System.out.println("changeKey: " + result[1]);

        // deleting the created event
        //connector.deleteEvent(result[0], result[1], ExchangeConstants.DELETE_TYPE_MOVE_TO_DELETED_ITEMS, ExchangeConstants.SEND_MEETING_CANCELLATIONS_ALL_AND_SAVE_COPY);


    }

    public static void deleteItemExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);
        // delete(id, changeKey)
        //connector.deleteItem("AQARAHRlc3QxQGRvbWFpbjEuY29tAEYAAAOI5eHkowVVRqyfb+K/CgeHBwDQuh5ItVuRToEG63n1XN3xAAADRgAAANC6Hki1W5FOgQbrefVc3fEAAAAnVRKoAAAA", "DwAAABYAAADQuh5ItVuRToEG63n1XN3xAAAnVTCw");


        //connector.deleteItem("AAMkADU2YTJjMjc0LTc0NmYtNDUzMi1hOGU5LTcwMDZkNzE0NDU0OQBGAAAAAACI5eHkowVVRqyfb+K/CgeHBwDQuh5ItVuRToEG63n1XN3xAAAAAABIAADQuh5ItVuRToEG63n1XN3xAAAnVRqbAAA=", "CQAAABYAAADQuh5ItVuRToEG63n1XN3xAAAnVS1L", ExchangeConstants.DELETE_TYPE_HARD_DELETE);
        connector.deleteItem("AAMkADU2YTJjMjc0LTc0NmYtNDUzMi1hOGU5LTcwMDZkNzE0NDU0OQBGAAAAAACI5eHkowVVRqyfb+K/CgeHBwDQuh5ItVuRToEG63n1XN3xAAAAAABIAADQuh5ItVuRToEG63n1XN3xAAAnVRqbAAA=", "CQAAABYAAADQuh5ItVuRToEG63n1XN3xAAAnVS1L", ExchangeConstants.DELETE_TYPE_MOVE_TO_DELETED_ITEMS);
    }

    public static void batchDeleteItemsExample() throws ExchangeGeneralException {

    	EWSConnectorFactory factory = new EWSConnectorFactory();
    	EWSConnectorInterface connector = null;

    	connector = factory.createEWSConnector(_exchangeHost,
    			_userName,
    			_password,
    			_prefix, _useSSL, _accountName);
    	ArrayList contacts = connector.getContacts();
    	if (contacts.size() >= 2) {
    		EWSDTO[] arr = new EWSDTO[2];
    		for (int i = 0; i < 2; i++) {
    			EWSDTO idChangeKey = new EWSDTO();
    			idChangeKey.setId( ((EWSContactShallowDTO) contacts.get(i)).getId());
    			idChangeKey.setChangeKey(((EWSContactShallowDTO) contacts.get(i)).getChangeKey());
    			arr[i]  = idChangeKey;
    		}
    		connector.deleteItems(arr, ExchangeConstants.DELETE_TYPE_HARD_DELETE, ExchangeConstants.SEND_MEETING_CANCELLATIONS_NONE , ExchangeConstants.DELETE_TYPE_AffectedTaskOccurrences_SpecifiedOccurrenceOnly);
    	}
    }

    public static void updateEventExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);
        //String subject2update = "update event example don't remove";
        //String subject2update = "test event1";
        String subject2update = "test event";
        EWSSearchExpression searchExpression = new EWSSearchExpression.Contains(EWSSearchExpression.Contains.ContainmentMode.Substring,
        		EWSSearchExpression.Contains.ContainmentComparison.IgnoreCaseAndNonSpacingCharacters,
        		EWSSearchExpression.Constants.General.Subject, subject2update);
        ArrayList events = connector.getEvents(searchExpression);
        if (events.size() > 0) {

        	EWSEventDTO event = connector.getEventFull(((EWSEventDTO)events.get(0)).getId());


        	EWSEventDTO event2update = new EWSEventDTO();
        	event2update.setId(event.getId());
        	event2update.setChangeKey(event.getChangeKey());
        	//event2update.setSensitivity("Private");
        	event2update.setSubject(subject2update + " updated");
        	event2update.setImportance(event._importance_HIGH);

        	// use this flag to append to the previous description (in some cases of HTML EWS will fail to append,
        	// in this cases you should use event.setAppendDescription(false) )
        	//event2update.setAppendDescription(true);

        	event2update.setDescription(" updated");

        	event2update.setLocation("Location updated2");
        	event2update.setBusyStatus(event._calendarBusyStatus_OUT_OF_OFFICE);
        	event2update.setCategoriesStr("<t:Categories><t:String>Business</t:String><t:String>School</t:String></t:Categories>");


        	SimpleDateFormat dateFormat = new SimpleDateFormat(
        	"yyyy-MM-dd HH:mm:ss");
        	Date startDate1 = null;
        	Date endDate1 = null;
        	try {
        		startDate1 = dateFormat.parse("2009-07-21 11:00:00");
        		endDate1 = dateFormat.parse("2009-07-21 12:00:00");
        	} catch (ParseException ex) {
        		ex.printStackTrace();
        	}
        	event2update.setStartDate(startDate1);
        	event2update.setEndDate(endDate1);


        	try {
        		String[] idChangeKey = connector.updateEvent(event2update);
        		System.out.println("Id: " + idChangeKey[0] + " ChangeKey: " + idChangeKey[1]);

        	} catch (ExchangeGeneralException e) {
        		//
        		e.printStackTrace();
        	}
        }


    }


    public static void updateEventOneFieldExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);

        String subject2update = "test event to update";
        EWSSearchExpression searchExpression = new EWSSearchExpression.Contains(EWSSearchExpression.Contains.ContainmentMode.Substring,
        		EWSSearchExpression.Contains.ContainmentComparison.IgnoreCaseAndNonSpacingCharacters,
        		EWSSearchExpression.Constants.General.Subject, subject2update);
        ArrayList events = connector.getEvents(searchExpression);
        if (events.size() > 0) {

        	EWSEventDTO event = connector.getEventFull(((EWSEventDTO)events.get(0)).getId());

        	EWSEventDTO event2update = new EWSEventDTO();
        	event2update.setId(event.getId());
        	event2update.setChangeKey(event.getChangeKey());

        	// Setting only the location field in the event2update DTO that contains only the Id, changeKey and the location.
        	// This will update only the location field, leaving the other fields intact.
        	//event2update.setLocation(event.getLocation() + " updated");

        	//event2update.setImportance(EWSEventDTO._importance_HIGH);
        	
        	//event2update.setReminderMinutesBeforeStart(1);
        	
        	event2update.updateReminder(true);
        	event2update.setReminderIsSet(false);

        	try {
        		String[] idChangeKey = connector.updateEvent(event2update);
        		System.out.println("Id: " + idChangeKey[0] + " ChangeKey: " + idChangeKey[1]);

        	} catch (ExchangeGeneralException e) {
        		
        		e.printStackTrace();
        	}
        }


    }


    /**
     * This example needs and event with the subject: "test attendees don't remove"
     * @throws ExchangeGeneralException
     */
    public static void updateEventAttendeesExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);
        String subject2find = "test event to update";
        EWSSearchExpression searchExpression = new EWSSearchExpression.Contains(EWSSearchExpression.Contains.ContainmentMode.Substring,
        		EWSSearchExpression.Contains.ContainmentComparison.IgnoreCaseAndNonSpacingCharacters,
        		EWSSearchExpression.Constants.General.Subject, subject2find);
        ArrayList events = connector.getEvents(searchExpression);
        if (events != null && events.size() > 0) {
        	EWSEventDTO foundEvent = (EWSEventDTO)events.get(0);


        	EWSEventDTO event = new EWSEventDTO();
        	event.setId(foundEvent.getId());
        	event.setChangeKey(foundEvent.getChangeKey());

//        	ExchangeEventAttendeeDTO to1 = new ExchangeEventAttendeeDTO();
//        	to1.setType(ExchangeEventAttendeeDTO.ATTENDEE_TYPE_REQUIRED);
//        	to1.setEmailAddr("test1@domain1.com");
//        	event.addTo(to1);

//        	ExchangeEventAttendeeDTO to2 = new ExchangeEventAttendeeDTO();
//        	to2.setType(ExchangeEventAttendeeDTO.ATTENDEE_TYPE_REQUIRED);
//        	to2.setEmailAddr("test2@domain1.com");
//        	event.addTo(to2);


        	ExchangeEventAttendeeDTO to3 = new ExchangeEventAttendeeDTO();
        	to3.setType(ExchangeEventAttendeeDTO.ATTENDEE_TYPE_OPTIONAL);
        	to3.setEmailAddr("test3@domain1.com");
        	event.addTo(to3);
        	

        	try {
        		// this is the default: will append the new attendees, will send an update email to all attendees.
        		//connector.updateEvent(event, new EWSUpdateEventConfiguration(EWSUpdateEventConfiguration.APPEND_ATTENDEES));

        		// when using this method you'll be able to remove attendees (make sure you use an empty EWSEventDTO, and set to it the ID, changeKey and attendees to set, all others will be removed).
        		// In case you need to remove all attendees, see the example: removeEventAttendeesExample()
        		//connector.updateEvent(event, new EWSUpdateEventConfiguration(EWSUpdateEventConfiguration.SET_ATTENDEES));
        		
        		

        		// will append the new attendees, but will not send an update email
        		//connector.updateEvent(event, new EWSUpdateEventConfiguration(EWSUpdateEventConfiguration.APPEND_ATTENDEES, EWSUpdateEventConfiguration.SEND_MEETING_INVITATIONS_OR_CANCELLATIONS_SendToNone));

        		// will append the new attendees, but will send an update email only to the changed attendees.
        		connector.updateEvent(event, new EWSUpdateEventConfiguration(EWSUpdateEventConfiguration.APPEND_ATTENDEES, EWSUpdateEventConfiguration.SEND_MEETING_INVITATIONS_OR_CANCELLATIONS_SendToChangedAndSaveCopy));
        		
        		
        	} catch (ExchangeGeneralException e) {
        		//
        		e.printStackTrace();
        	}




        }
        else
        	throw new ExchangeGeneralException("event was not found");

    }
    
    
    public static void removeEventAttendeesExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);
        String subject2find = "test event1";
        EWSSearchExpression searchExpression = new EWSSearchExpression.Contains(EWSSearchExpression.Contains.ContainmentMode.Substring,
        		EWSSearchExpression.Contains.ContainmentComparison.IgnoreCaseAndNonSpacingCharacters,
        		EWSSearchExpression.Constants.General.Subject, subject2find);
        ArrayList events = connector.getEvents(searchExpression);
        if (events != null && events.size() > 0) {
        	EWSEventDTO foundEvent = (EWSEventDTO)events.get(0);


        	EWSEventDTO event = new EWSEventDTO();
        	event.setId(foundEvent.getId());
        	event.setChangeKey(foundEvent.getChangeKey());


        	ExchangeEventAttendeeDTO to3 = new ExchangeEventAttendeeDTO();
        	// setting ExchangeEventAttendeeDTO.ATTENDEE_TYPE_REQUIRED will delete all the required attendees.
        	//to3.setType(ExchangeEventAttendeeDTO.ATTENDEE_TYPE_REQUIRED);
        	
        	// delete all the optional attendees
        	to3.setType(ExchangeEventAttendeeDTO.ATTENDEE_TYPE_OPTIONAL);
        	event.addTo(to3);
        	

        	try {
        		// when using this method you'll be able to remove attendees (make sure you use an empty EWSEventDTO, and set to it the ID, changeKey and attendees).
        		connector.updateEvent(event, new EWSUpdateEventConfiguration(EWSUpdateEventConfiguration.DELETE_ATTENDEES));
        		
        	} catch (ExchangeGeneralException e) {
        		//
        		e.printStackTrace();
        	}




        }
        else
        	throw new ExchangeGeneralException("event was not found");

    }


    public static void getAllFoldersExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);
        //connector.setUseNTLMAuthentication(false);
        ArrayList folders = connector.getAllFolders();
        for (int i = 0; i < folders.size(); i++) {
            System.out.println(((EWSFolderDTO) folders.get(i)).getId());
            System.out.println(((EWSFolderDTO) folders.get(i)).getChangeKey());
            System.out.println(((EWSFolderDTO) folders.get(i)).getDisplayName());
            System.out.println(((EWSFolderDTO) folders.get(i)).getChildFolderCount());
            System.out.println(((EWSFolderDTO) folders.get(i)).getTotalCount());
            System.out.println(((EWSFolderDTO) folders.get(i)).getUnreadCount());
            System.out.println(((EWSFolderDTO) folders.get(i)).getFolderClass());
            System.out.println("");
        }

    }


    public static void getAllPublicFoldersExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);

        ArrayList folders = connector.getAllSubFoldersByParentFolderName("publicfoldersroot", false);
        for (int i = 0; i < folders.size(); i++) {
            System.out.println(((EWSFolderDTO) folders.get(i)).getId());
            System.out.println(((EWSFolderDTO) folders.get(i)).getChangeKey());
            System.out.println(((EWSFolderDTO) folders.get(i)).getDisplayName());
            System.out.println(((EWSFolderDTO) folders.get(i)).getChildFolderCount());
            System.out.println(((EWSFolderDTO) folders.get(i)).getTotalCount());
            System.out.println(((EWSFolderDTO) folders.get(i)).getUnreadCount());

            System.out.println("");
        }
    }


    /**
     * possible values for the folder name
     * <xs:enumeration value="calendar" />
     * <xs:enumeration value="contacts" />
     * <xs:enumeration value="deleteditems" />
     * <xs:enumeration value="drafts" />
     * <xs:enumeration value="inbox" />
     * <xs:enumeration value="journal" />
     * <xs:enumeration value="notes" />
     * <xs:enumeration value="outbox" />
     * <xs:enumeration value="sentitems" />
     * <xs:enumeration value="tasks" />
     * <xs:enumeration value="msgfolderroot" />
     * <xs:enumeration value="publicfoldersroot" />
     * <xs:enumeration value="root" />
     * <xs:enumeration value="junkemail" />
     * <xs:enumeration value="searchfolders" />
     * <xs:enumeration value="voicemail" />
     * @throws ExchangeGeneralException
     */
    public static void getSubFoldersExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);

        //ArrayList folders = connector.getAllSubFoldersByParentFolderName("calendar", true);
        ArrayList folders = connector.getAllSubFoldersByParentFolderName("root", false);
        for (int i = 0; i < folders.size(); i++) {
            System.out.println(((EWSFolderDTO) folders.get(i)).getId());
            System.out.println(((EWSFolderDTO) folders.get(i)).getChangeKey());
            System.out.println(((EWSFolderDTO) folders.get(i)).getDisplayName());
            System.out.println(((EWSFolderDTO) folders.get(i)).getFolderClass());
            System.out.println(((EWSFolderDTO) folders.get(i)).getChildFolderCount());
            System.out.println(((EWSFolderDTO) folders.get(i)).getTotalCount());
            System.out.println(((EWSFolderDTO) folders.get(i)).getUnreadCount());
            System.out.println("");
        }
    }


    public static void getSubFoldersByIdExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);

        ArrayList folders = connector.getAllFolders();
        String inboxId = null;

        /////////////////// find the inbox folder Id /////
        for (int i = 0; i < folders.size(); i++) {

        	String displayName = ((EWSFolderDTO) folders.get(i)).getDisplayName();
        	if (displayName.equals("Inbox")) {
        		inboxId = ((EWSFolderDTO) folders.get(i)).getId();
        	}
        }
        //////////////////////////////////////////////////

        ///// get inbox folder children
        if (inboxId != null) {
        	ArrayList inboxFolders = connector.getAllSubFoldersByParentFolderId(inboxId, false);
            for (int i = 0; i < inboxFolders.size(); i++) {
                System.out.println(((EWSFolderDTO) inboxFolders.get(i)).getId());
                System.out.println(((EWSFolderDTO) inboxFolders.get(i)).getChangeKey());
                System.out.println(((EWSFolderDTO) inboxFolders.get(i)).getDisplayName());
                System.out.println(((EWSFolderDTO) inboxFolders.get(i)).getChildFolderCount());
                System.out.println(((EWSFolderDTO) inboxFolders.get(i)).getTotalCount());
                System.out.println(((EWSFolderDTO) inboxFolders.get(i)).getUnreadCount());
                System.out.println("");
            }
        }
    }

    public static void getEmailsShallowFromFolderIdExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);

        ArrayList folders = connector.getAllFolders();
        String draftsId = null;

        /////////////////// find the Drafs folder Id /////
        for (int i = 0; i < folders.size(); i++) {

        	String displayName = ((EWSFolderDTO) folders.get(i)).getDisplayName();
        	if (displayName.equals("Drafts")) {
        		draftsId = ((EWSFolderDTO) folders.get(i)).getId();
        	}
        }
        //////////////////////////////////////////////////
        connector.setFolder(draftsId);
        ArrayList emails = connector.getEmailsShallow();
        for (int i = 0; i < emails.size(); i++) {
            System.out.println(((ExchangeEmailShallowDTO) emails.get(i)).getSubject());
            System.out.println(((ExchangeEmailShallowDTO) emails.get(i)).getTo());
            System.out.println(((ExchangeEmailShallowDTO) emails.get(i)).getCc());
            System.out.println(((ExchangeEmailShallowDTO) emails.get(i)).getDateReceived());
            System.out.println("");
        }

    }

    public static void getEventsUsingFolderIdExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);

        ArrayList folders = connector.getAllFolders();
        String folderId = null;

        /////////////////// find the Calendar folder Id /////
        for (int i = 0; i < folders.size(); i++) {

        	String displayName = ((EWSFolderDTO) folders.get(i)).getDisplayName();
        	if (displayName.equals("Calendar")) {
        	//if (displayName.equals("testCalendar")) {
        		folderId = ((EWSFolderDTO) folders.get(i)).getId();
        	}
        }
        //////////////////////////////////////////////////
        // the events will be retrieved from this calendar folder,
        //this method can be used to retrieve events from any events sub-folder.
        connector.setFolder(folderId);
        //////////////////////////////////////////////////

        SimpleDateFormat dateFormat = new SimpleDateFormat(
        "yyyy-MM-dd HH:mm:ss");
        Date startDate = null;
        Date endDate = null;
        try {
        	startDate = dateFormat.parse("2008-03-26 11:00:00");
        	endDate = dateFormat.parse("2009-01-26 12:00:00");
        } catch (ParseException ex) {
        	ex.printStackTrace();
        }

        ArrayList events = connector.getEvents(startDate, endDate);
        for (int i = 0; i < events.size(); i++) {
        	System.out.println(((EWSEventDTO) events.get(i)).getId());
        	System.out.println(((EWSEventDTO) events.get(i)).getChangeKey());
            System.out.println(((EWSEventDTO) events.get(i)).getSubject());
            System.out.println(((EWSEventDTO) events.get(i)).getLocation());
            System.out.println(((EWSEventDTO) events.get(i)).getStartDate());
            System.out.println(((EWSEventDTO) events.get(i)).getEndDate());
            System.out.println(((EWSEventDTO) events.get(i)).
                               isRecurrent());
            System.out.println(((EWSEventDTO) events.get(i)).
                               isAllDayEvent());
            System.out.println(((EWSEventDTO) events.get(i)).getImportance());
            System.out.println(((EWSEventDTO) events.get(i)).getBusyStatus());
            System.out.println(((EWSEventDTO) events.get(i)).getSensitivity());
            System.out.println("");
        }

    }

    public static void getContactsUsingFolderIdExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);

        ArrayList folders = connector.getAllFolders();
        String folderId = null;

        /////////////////// find the Contacts folder Id /////
        for (int i = 0; i < folders.size(); i++) {

        	String displayName = ((EWSFolderDTO) folders.get(i)).getDisplayName();
        	if (displayName.equals("Contacts")) {
        		folderId = ((EWSFolderDTO) folders.get(i)).getId();
        	}
        }
        //////////////////////////////////////////////////
        // the contacts will be retrieved from this Contacts folder,
        //this method can be used to retrieve contacts from any contacts sub-folder.
        connector.setFolder(folderId);
        //////////////////////////////////////////////////

        ArrayList contacts = connector.getContacts();
        for (int i = 0; i < contacts.size(); i++) {
        	System.out.println(((EWSContactShallowDTO) contacts.get(i)).getId());
        	System.out.println(((EWSContactShallowDTO) contacts.get(i)).getChangeKey());
            System.out.println(((EWSContactShallowDTO) contacts.get(i)).getFirstName());
            System.out.println(((EWSContactShallowDTO) contacts.get(i)).getSurname());
            System.out.println(((EWSContactShallowDTO) contacts.get(i)).getEmailAddress1());
            System.out.println(((EWSContactShallowDTO) contacts.get(i)).getBusinessPhone());
            System.out.println(((EWSContactShallowDTO) contacts.get(i)).getHomePhone());
            System.out.println(((EWSContactShallowDTO) contacts.get(i)).getMobilePhone());
            System.out.println("");
        }

    }



    public static void getFullEmailExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);

        // un-comment to change the default folder (inbox)
        //connector.setFolder(ExchangeConstants.FOLDER_ENUM_drafts);
        connector.setDomain(_domain);

        ArrayList emails = connector.getEmailsShallow();
        String id = null;
        for (int i = 0; i < emails.size(); i++) {
        	// for this example we get only the first email
        	if (i == 0) {
        		id = ((ExchangeEmailShallowDTO) emails.get(i)).getId();
        		String changeKey = ((ExchangeEmailShallowDTO) emails.get(i)).getChangeKey();
        		System.out.println("getting full email: " + id + " changeKey: " + changeKey);

        		// if you don't have to get the email mime content, use this method for better performance.
        		//EWSEmailDTO email = connector.getFullEmail(id, changeKey);

        		// setting the includeMimeContent flag to true, will get also the mime content of the email,
        		// use the EWSEmailDTO getMimeContent() to get the base64 encoded mime content of the email.
        		EWSEmailDTO email = connector.getFullEmail(id, changeKey, true);

        		

        		System.out.println(((EWSEmailDTO) email).getId());
        		System.out.println(((EWSEmailDTO) email).getChangeKey());
        		System.out.println("getSubject: " + ((EWSEmailDTO) email).getSubject());
        		System.out.println("getImportance: " + ((EWSEmailDTO) email).getImportance());
        		System.out.println("getItemClass: " + ((EWSEmailDTO) email).getItemClass());
        		
        		// Supported on Exchange 2010 and above.
        		if (((EWSEmailDTO) email).getReplyTo() != null) {
        			String replyTo = ((EWSEmailDTO) email).getReplyTo();
        			System.out.println("replyTo: " + replyTo);
        		}
        		

        		if (((EWSEmailDTO) email).getFrom() != null) {
        			EmailAddressDTO from = ((EWSEmailDTO) email).getFrom();
        			System.out.println(from.getEmailAddress() + " " + from.getName());
        		}

        		if (((EWSEmailDTO) email).getTo() != null) {
        			EmailAddressDTO firstTo = ((EWSEmailDTO) email).getTo()[0];
        			System.out.println(firstTo.getEmailAddress() + " " + firstTo.getName());
        		}

        		if (((EWSEmailDTO) email).getCc() != null) {
        			EmailAddressDTO firstCc = ((EWSEmailDTO) email).getCc()[0];
        			System.out.println(firstCc.getEmailAddress() + " " + firstCc.getName());
        		}
        		if (((EWSEmailDTO) email).getBcc() != null) {
        			EmailAddressDTO firstBcc = ((EWSEmailDTO) email).getBcc()[0];
        			System.out.println(firstBcc.getEmailAddress() + " " + firstBcc.getName());
        		}

        		System.out.println("getDateCreated: " + ((EWSEmailDTO) email).getDateCreated());
        		System.out.println("getDateSent: " + ((EWSEmailDTO) email).getDateSent());
        		System.out.println("getSensitivity: " + ((EWSEmailDTO) email).getSensitivity());
        		System.out.println("getSizeInBytes: " + ((EWSEmailDTO) email).getSizeInBytes());
        		System.out.println("isHasAttachment: " + ((EWSEmailDTO) email).isHasAttachment());
        		System.out.println("isHtmlBody: " + ((EWSEmailDTO) email).isHtmlBody());
        		System.out.println("isRead: " + ((EWSEmailDTO) email).isRead());
        		
        		//System.out.println("================= body ==================");
        		//System.out.println(((EWSEmailDTO) email).getBody());
        		//System.out.println("================= body ==================");

        		if (((EWSEmailDTO) email).getCategoriesStr() != null) {
        			System.out.println("================= categories ==================");
        			System.out.println(((EWSEmailDTO) email).getCategoriesStr());
        			System.out.println("================= categories ==================");
        		}

        		if (((EWSEmailDTO) email).getMimeContent() != null) {
        			System.out.println("================= Mime content (base64 encoded) ==================");
        			System.out.println(((EWSEmailDTO) email).getMimeContent());
        			System.out.println("================= Mime content (base64 encoded) ==================");
        		}

        		if (((EWSEmailDTO) email).getAttachments() != null) {
        			System.out.println("================= Attachments ==================");
        			for (int j=0 ; j < ((EWSEmailDTO) email).getAttachments().length; j++ ) {
        				String attachmentId = ((EWSEmailDTO) email).getAttachments()[j].getId();
        				String attachmentName = ((EWSEmailDTO) email).getAttachments()[j].getName();
        				System.out.println("attachmentId: " + attachmentId);
        				System.out.println("attachmentName: " + attachmentName);
        				System.out.println("contentType: " + ((EWSEmailDTO) email).getAttachments()[j].getContentType());
        				System.out.println("");

        				// for this example we get only the first attachment
        				if (j == 0) {
        					System.out.println("============ get full attachment start ==========");
        					AttachmentDTO attachment = connector.getFullAttachment(attachmentId);
        					try {
        						String filePath = null;
        						if (attachment.getName() != null)
        						  filePath = "c:/temp/" + attachment.getName();
        						else
        						  filePath = "c:/temp/attachment.txt";

        						System.out.println("Make sure " + attachment.getName() + " Do not contain illigal filename charecters, or it will not be saved.");

        						FileOutputStream f = new FileOutputStream(filePath);
        						f.write(attachment.getByteData());
        						System.out.println("attachment was saved to " + filePath);
        						if (attachment.getContentType() != null && attachment.getContentType().equals("outlook/rfc822")) {
        							System.out.println("This is a msg attachment.");
        							System.out.println("Creating EWSEmailDTO...");
        							String msgXML = new String (attachment.getByteData());
        							EWSEmailDTO emailMsg = connector.parseFullEmailRFC822MsgFromXMLString(msgXML);
        							System.out.println("emailMsg.getSubject(): " + emailMsg.getSubject());
        							System.out.println("emailMsg.getBody(): " + emailMsg.getBody());
        							if (emailMsg.getAttachments() != null)
        								System.out.println("mailMsg.getAttachments().length: " + emailMsg.getAttachments().length);
        						}
        					} catch (FileNotFoundException e) {

        						e.printStackTrace();
        					} catch (IOException e) {

        						e.printStackTrace();
        					}

        					System.out.println("============ get full attachment end ============");
        				}


        			}
        			System.out.println("================= Attachments ==================");
        		}
         		System.out.println("");
        	}
        }

    }

    public static void getContactsWithFreeTextFilterExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);



        // set this xml according the Restriction xml documentation.
        // http://msdn.microsoft.com/en-us/library/aa563791(EXCHG.80).aspx
        //String searchValue = "John";
        //String searchXmlStr = "<Restriction><t:IsEqualTo><t:FieldURI FieldURI=\"contacts:GivenName\"/><t:FieldURIOrConstant><t:Constant Value=\"" + searchValue + "\"/></t:FieldURIOrConstant></t:IsEqualTo></Restriction>";

        String searchXmlStr ="<Restriction>"
            +"<t:And>"
            + "<t:IsEqualTo>"
            + "<t:FieldURI FieldURI=\"contacts:GivenName\"/>"
             + "<t:FieldURIOrConstant>"
             + "<t:Constant Value=\"" + "John"
             + "\"/>"
             + "</t:FieldURIOrConstant>"
             + "</t:IsEqualTo>"
             +"<t:IsEqualTo>"
             +"<t:FieldURI FieldURI=\"contacts:Surname\"/>"
             +"<t:FieldURIOrConstant>"
             +"<t:Constant Value=\"" + "Dow" + "\"/>"
             +"</t:FieldURIOrConstant>"
             +"</t:IsEqualTo>"
             +"</t:And>"
            +"</Restriction>";

        EWSSearchExpression searchExpression = new EWSSearchExpression(searchXmlStr);



        ArrayList contacts = connector.getContacts(searchExpression);
        for (int i = 0; i < contacts.size(); i++) {
        	System.out.println(((EWSContactShallowDTO) contacts.get(i)).getId());
            System.out.println(((EWSContactShallowDTO) contacts.get(i)).getFirstName());
           System.out.println(((EWSContactShallowDTO) contacts.get(i)).getSurname());
           System.out.println(((EWSContactShallowDTO) contacts.get(i)).getEmailAddress1());
           System.out.println(((EWSContactShallowDTO) contacts.get(i)).getBusinessPhone());
           System.out.println(((EWSContactShallowDTO) contacts.get(i)).getHomePhone());
           System.out.println(((EWSContactShallowDTO) contacts.get(i)).getMobilePhone());
            System.out.println("");
        }

    }


    public static void getContactsWithPagingExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);



        int pageNo = 1;
        String searchXmlStr ="<IndexedPageItemView MaxEntriesReturned=\"20\" Offset=\""
            + (pageNo - 1) * 20 + "\" BasePoint=\"Beginning\"/>";

        EWSSearchExpression searchExpression = new EWSSearchExpression(searchXmlStr);



        ArrayList contacts = connector.getContacts(searchExpression);
        for (int i = 0; i < contacts.size(); i++) {
        	System.out.println(((EWSContactShallowDTO) contacts.get(i)).getId());
            System.out.println(((EWSContactShallowDTO) contacts.get(i)).getFirstName());
           System.out.println(((EWSContactShallowDTO) contacts.get(i)).getSurname());
           System.out.println(((EWSContactShallowDTO) contacts.get(i)).getEmailAddress1());
           System.out.println(((EWSContactShallowDTO) contacts.get(i)).getBusinessPhone());
           System.out.println(((EWSContactShallowDTO) contacts.get(i)).getHomePhone());
           System.out.println(((EWSContactShallowDTO) contacts.get(i)).getMobilePhone());
            System.out.println("");
        }

    }

    public static void getEventsWithFreeTextFilterExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);

        // location contains example
        //String searchXmlStr = "<Restriction><t:Contains ContainmentMode=\"Substring\" ContainmentComparison=\"IgnoreCaseAndNonSpacingCharacters\"><t:FieldURI FieldURI=\"calendar:Location\"/><t:Constant Value=\"user\"/></t:Contains></Restriction>";

        // subject equal example
        //String searchXmlStr = "<Restriction><t:IsEqualTo><t:FieldURI FieldURI=\"item:Subject\"/><t:FieldURIOrConstant><t:Constant Value=\"test\"/></t:FieldURIOrConstant></t:IsEqualTo></Restriction>";

        // restriction with AND operator that used to filter events using the startDate endDate elements and subject.
        String searchXmlStr = "<Restriction><t:And><t:And><t:IsGreaterThanOrEqualTo><t:FieldURI FieldURI=\"item:DateTimeReceived\" /><t:FieldURIOrConstant><t:Constant Value=\"2008-01-05T03:42:44.701Z\" /></t:FieldURIOrConstant></t:IsGreaterThanOrEqualTo><t:IsLessThanOrEqualTo><t:FieldURI FieldURI=\"item:DateTimeReceived\" /><t:FieldURIOrConstant><t:Constant Value=\"2009-11-05T03:42:44.701Z\" /></t:FieldURIOrConstant></t:IsLessThanOrEqualTo></t:And><t:IsEqualTo><t:FieldURI FieldURI=\"item:Subject\"/><t:FieldURIOrConstant><t:Constant Value=\"test event\"/></t:FieldURIOrConstant></t:IsEqualTo></t:And></Restriction>";

        EWSSearchExpression searchExpression = new EWSSearchExpression(searchXmlStr);

        ArrayList events = connector.getEvents(searchExpression);
        for (int i = 0; i < events.size(); i++) {
        	System.out.println(((EWSEventDTO) events.get(i)).getId());
        	System.out.println(((EWSEventDTO) events.get(i)).getChangeKey());
            System.out.println(((EWSEventDTO) events.get(i)).getSubject());
            System.out.println(((EWSEventDTO) events.get(i)).getLocation());
            System.out.println(((EWSEventDTO) events.get(i)).getStartDate());
            System.out.println(((EWSEventDTO) events.get(i)).getEndDate());
            System.out.println(((EWSEventDTO) events.get(i)).
                               isRecurrent());
            System.out.println(((EWSEventDTO) events.get(i)).
                               isAllDayEvent());
            System.out.println(((EWSEventDTO) events.get(i)).getImportance());
            System.out.println(((EWSEventDTO) events.get(i)).getBusyStatus());
            System.out.println(((EWSEventDTO) events.get(i)).getSensitivity());
            System.out.println("");
        }
    }

    public static void getEventsWithFilterExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);

        // The below searchExpression will generate this XML:
        //<Restriction><t:Contains ContainmentMode=\"Substring\" ContainmentComparison=\"IgnoreCaseAndNonSpacingCharacters\"><t:FieldURI FieldURI=\"calendar:Location\"/><t:Constant Value=\"location1\"/></t:Contains></Restriction>
        EWSSearchExpression searchExpression = new EWSSearchExpression.Contains(EWSSearchExpression.Contains.ContainmentMode.Substring,
        		EWSSearchExpression.Contains.ContainmentComparison.IgnoreCaseAndNonSpacingCharacters,
        		EWSSearchExpression.Constants.Calendar.Location, "location");

        ArrayList events = connector.getEvents(searchExpression);
        for (int i = 0; i < events.size(); i++) {
        	System.out.println(((EWSEventDTO) events.get(i)).getId());
        	System.out.println(((EWSEventDTO) events.get(i)).getChangeKey());
            System.out.println(((EWSEventDTO) events.get(i)).getSubject());
            System.out.println(((EWSEventDTO) events.get(i)).getLocation());
            System.out.println(((EWSEventDTO) events.get(i)).getStartDate());
            System.out.println(((EWSEventDTO) events.get(i)).getEndDate());
            System.out.println(((EWSEventDTO) events.get(i)).
                               isRecurrent());
            System.out.println(((EWSEventDTO) events.get(i)).
                               isAllDayEvent());
            System.out.println(((EWSEventDTO) events.get(i)).getImportance());
            System.out.println(((EWSEventDTO) events.get(i)).getBusyStatus());
            System.out.println(((EWSEventDTO) events.get(i)).getSensitivity());
            System.out.println("");
        }
    }

    public static void getEmailsWithIsReadAndSinceFilterExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);

        // Text Expression that get unread emails from a specific date:
        String searchXmlStr ="<Restriction>"
            +"<t:And>"
            + "<t:IsGreaterThanOrEqualTo>"
            + "<t:FieldURI FieldURI=\"item:DateTimeReceived\"/>"
             + "<t:FieldURIOrConstant>"
             + "<t:Constant Value=\"" + "2009-04-09T03:42:44.701Z"
             + "\"/>"
             + "</t:FieldURIOrConstant>"
             + "</t:IsGreaterThanOrEqualTo>"
             +"<t:IsEqualTo>"
             +"<t:FieldURI FieldURI=\"message:IsRead\"/>"
             +"<t:FieldURIOrConstant>"
             +"<t:Constant Value=\"1\"/>"
             +"</t:FieldURIOrConstant>"
             +"</t:IsEqualTo>"
             +"</t:And>"
            +"</Restriction>";

        EWSSearchExpression searchExpression = new EWSSearchExpression(searchXmlStr);

        ArrayList emails = connector.getEmailsShallow(searchExpression);
        for (int i = 0; i < emails.size(); i++) {
        	System.out.println(((ExchangeEmailShallowDTO) emails.get(i)).getId());
            System.out.println(((ExchangeEmailShallowDTO) emails.get(i)).getSubject());
            System.out.println(((ExchangeEmailShallowDTO) emails.get(i)).getTo());
            System.out.println(((ExchangeEmailShallowDTO) emails.get(i)).getCc());
            System.out.println(((ExchangeEmailShallowDTO) emails.get(i)).getDateReceived());
            System.out.println("");
        }
    }

    public static void getEventsWithFilterAndSorterExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);

        // The below searchExpression will generate this XML:
        //<Restriction><t:Contains ContainmentMode=\"Substring\" ContainmentComparison=\"IgnoreCaseAndNonSpacingCharacters\"><t:FieldURI FieldURI=\"calendar:Location\"/><t:Constant Value=\"location1\"/></t:Contains></Restriction>
        EWSSearchExpression searchExpression = new EWSSearchExpression.Contains(EWSSearchExpression.Contains.ContainmentMode.Substring,
        		EWSSearchExpression.Contains.ContainmentComparison.IgnoreCaseAndNonSpacingCharacters,
        		EWSSearchExpression.Constants.Calendar.Location, "location");

        // Searching the location field using contains operation, Sorting by subject
        //ArrayList events = connector.getEvents(searchExpression, new EWSSorter(EWSSorter.ORDER_ASCENDING, EWSSorter.FIELD_ORDER_ITEM_Subject));

         // Searching the location field using contains operation, Sorting by location, using free text sorter
        //ArrayList events = connector.getEvents(searchExpression, new EWSSorter(EWSSorter.ORDER_ASCENDING, "calendar:Location"));

        // Searching the location field using contains operation, Sorting by location
        //ArrayList events = connector.getEvents(searchExpression, new EWSSorter(EWSSorter.ORDER_ASCENDING, EWSSorter.FIELD_ORDER_CALENDAR_Location));

        // Searching the location field using contains operation, Sorting by Start date
        ArrayList events = connector.getEvents(searchExpression, new EWSSorter(EWSSorter.ORDER_ASCENDING, EWSSorter.FIELD_ORDER_CALENDAR_Start));

        for (int i = 0; i < events.size(); i++) {
        	System.out.println(((EWSEventDTO) events.get(i)).getId());
        	System.out.println(((EWSEventDTO) events.get(i)).getChangeKey());
            System.out.println(((EWSEventDTO) events.get(i)).getSubject());
            System.out.println(((EWSEventDTO) events.get(i)).getLocation());
            System.out.println(((EWSEventDTO) events.get(i)).getStartDate());
            System.out.println(((EWSEventDTO) events.get(i)).getEndDate());
            System.out.println(((EWSEventDTO) events.get(i)).
                               isRecurrent());
            System.out.println(((EWSEventDTO) events.get(i)).
                               isAllDayEvent());
            System.out.println(((EWSEventDTO) events.get(i)).getImportance());
            System.out.println(((EWSEventDTO) events.get(i)).getBusyStatus());
            System.out.println(((EWSEventDTO) events.get(i)).getSensitivity());
            System.out.println("");
        }
    }

    public static void getContactsWithFilterExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);

        //The below searchExpression will generate this XML:
        //<Restriction><t:IsEqualTo><t:FieldURI FieldURI=\"contacts:GivenName\"/><t:FieldURIOrConstant><t:Constant Value=\"user1\"/></t:FieldURIOrConstant></t:IsEqualTo></Restriction>";
        EWSSearchExpression searchExpression = new EWSSearchExpression.IsEqualTo(EWSSearchExpression.Constants.Contacts.GivenName, "user1");

        ArrayList contacts = connector.getContacts(searchExpression);
        for (int i = 0; i < contacts.size(); i++) {
        	System.out.println(((EWSContactShallowDTO) contacts.get(i)).getId());
        	System.out.println(((EWSContactShallowDTO) contacts.get(i)).getFirstName());
        	System.out.println(((EWSContactShallowDTO) contacts.get(i)).getSurname());
        	System.out.println(((EWSContactShallowDTO) contacts.get(i)).getEmailAddress1());
        	System.out.println(((EWSContactShallowDTO) contacts.get(i)).getBusinessPhone());
        	System.out.println(((EWSContactShallowDTO) contacts.get(i)).getHomePhone());
        	System.out.println(((EWSContactShallowDTO) contacts.get(i)).getMobilePhone());
            System.out.println("");
        }

    }

    public static void getContactsWithFilterAndSorterExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);


        EWSSearchExpression searchExpression = new EWSSearchExpression.IsEqualTo(EWSSearchExpression.Constants.Contacts.GivenName, "user1");

        ArrayList contacts = connector.getContacts(searchExpression, new EWSSorter(EWSSorter.ORDER_ASCENDING, EWSSorter.FIELD_ORDER_CONTACTS_Surname));
        for (int i = 0; i < contacts.size(); i++) {
        	System.out.println(((EWSContactShallowDTO) contacts.get(i)).getId());
        	System.out.println(((EWSContactShallowDTO) contacts.get(i)).getFirstName());
        	System.out.println(((EWSContactShallowDTO) contacts.get(i)).getSurname());
        	System.out.println(((EWSContactShallowDTO) contacts.get(i)).getEmailAddress1());
        	System.out.println(((EWSContactShallowDTO) contacts.get(i)).getBusinessPhone());
        	System.out.println(((EWSContactShallowDTO) contacts.get(i)).getHomePhone());
        	System.out.println(((EWSContactShallowDTO) contacts.get(i)).getMobilePhone());
            System.out.println("");
        }

    }


    public static void getEmailsHeadersWithContainsFilterExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);

        // un-commnent to change the default folder (inbox)
        //connector.setFolder(ExchangeConstants.FOLDER_ENUM_drafts);

        //The below searchExpression will generate this XML:
        //<Restriction><t:Contains ContainmentMode=\"Substring\" ContainmentComparison=\"IgnoreCaseAndNonSpacingCharacters\"><t:FieldURI FieldURI=\"item:Subject\"/><t:Constant Value=\"test em\"/></t:Contains></Restriction>";
        EWSSearchExpression searchExpression = new EWSSearchExpression.Contains(EWSSearchExpression.Contains.ContainmentMode.Substring,
        		EWSSearchExpression.Contains.ContainmentComparison.IgnoreCaseAndNonSpacingCharacters,
        		EWSSearchExpression.Constants.General.Subject, "test subject");

        ArrayList emails = connector.getEmailsShallow(searchExpression);
        for (int i = 0; i < emails.size(); i++) {
        	System.out.println(((ExchangeEmailShallowDTO) emails.get(i)).getId());
            System.out.println(((ExchangeEmailShallowDTO) emails.get(i)).getSubject());
            System.out.println(((ExchangeEmailShallowDTO) emails.get(i)).getTo());
            System.out.println(((ExchangeEmailShallowDTO) emails.get(i)).getCc());
            System.out.println(((ExchangeEmailShallowDTO) emails.get(i)).getDateReceived());
            System.out.println("");
        }

    }

    public static void getUnReadMeetingRequestsExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);

        // un-commnent to change the default folder (inbox)
        //connector.setFolder(ExchangeConstants.FOLDER_ENUM_drafts);

        String searchXmlStr ="<Restriction>"
            +"<t:And>"
            + "<t:IsEqualTo>"
            + "<t:FieldURI FieldURI=\"item:ItemClass\"/>"
             + "<t:FieldURIOrConstant>"
             + "<t:Constant Value=\"" + "IPM.Schedule.Meeting.Request"
             + "\"/>"
             + "</t:FieldURIOrConstant>"
             + "</t:IsEqualTo>"

             +"<t:IsEqualTo>"
             +"<t:FieldURI FieldURI=\"message:IsRead\"/>"
             +"<t:FieldURIOrConstant>"
             +"<t:Constant Value=\"1\"/>"
             +"</t:FieldURIOrConstant>"
             +"</t:IsEqualTo>"
             +"</t:And>"
            +"</Restriction>";
        EWSSearchExpression searchExpression = new EWSSearchExpression(searchXmlStr);

        ArrayList emails = connector.getEmailsShallow(searchExpression);
        for (int i = 0; i < emails.size(); i++) {
        	System.out.println(((ExchangeEmailShallowDTO) emails.get(i)).getId());
            System.out.println(((ExchangeEmailShallowDTO) emails.get(i)).getSubject());
            System.out.println(((ExchangeEmailShallowDTO) emails.get(i)).getTo());
            System.out.println(((ExchangeEmailShallowDTO) emails.get(i)).getCc());
            System.out.println(((ExchangeEmailShallowDTO) emails.get(i)).getDateReceived());
            System.out.println("");
        }

    }


    public static void getMeetingRequestAndAcceptExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);

        // un-commnent to change the default folder (inbox)
        connector.setFolder(ExchangeConstants.FOLDER_ENUM_drafts);

        EWSSearchExpression searchExpression = new EWSSearchExpression.IsEqualTo(EWSSearchExpression.Constants.General.ItemClass, "IPM.Schedule.Meeting.Request");


        ArrayList meetingReqs = connector.getEmailsShallow(searchExpression);
        if (meetingReqs.size() > 0) {
        	String id = ((ExchangeEmailShallowDTO) meetingReqs.get(0)).getId();
        	String changeKey = ((ExchangeEmailShallowDTO) meetingReqs.get(0)).getChangeKey();
        	EWSEmailDTO email = connector.getFullEmail(id);
        	System.out.println("Subject: " + email.getSubject());
        	System.out.println("getAssociatedCalendarItemId: " + email.getAssociatedCalendarItemId());
        	System.out.println("getAssociatedCalendarItemChangeKey: " + email.getAssociatedCalendarItemChangeKey());

        	// In case you are not the owner of the meeting, you should use the UID
        	// to match related meetings requests, e.g meeting request, and the same meeting request update.
        	// The UID is not always available
        	System.out.println("getUID: " + email.getUID());

        	connector.meetingReqAccept(id, changeKey);
        	//connector.meetingReqDecline(id, changeKey);
        	//connector.meetingReqTentativelyAccept(id, changeKey);
        }


    }


    public static void updateEmailReadFlagExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);

        // un-commnent to change the default folder (inbox)
        //connector.setFolder(ExchangeConstants.FOLDER_ENUM_drafts);
        String subject2search = "example subject";

        EWSSearchExpression searchExpression = new EWSSearchExpression.Contains(EWSSearchExpression.Contains.ContainmentMode.Substring,
        		EWSSearchExpression.Contains.ContainmentComparison.IgnoreCaseAndNonSpacingCharacters,
        		EWSSearchExpression.Constants.General.Subject, subject2search);

        ArrayList emails = connector.getEmailsShallow(searchExpression);
        if (emails.size() > 0) {
        	String id = ((ExchangeEmailShallowDTO) emails.get(0)).getId();
        	String changeKey = ((ExchangeEmailShallowDTO) emails.get(0)).getChangeKey();
        	connector.updateEmailReadFlag(id, changeKey, true);
        	System.out.println("Email: " + id + " read flag updated");
        }
        else {
        	System.out.println("No Email was found to update, change the subject2search param to find one");
        }

    }
    
    
    public static void markAsJunkExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);

        // un-commnent to change the default folder (inbox)
        //connector.setFolder(ExchangeConstants.FOLDER_ENUM_drafts);
        String subject2search = "Getting the";

        EWSSearchExpression searchExpression = new EWSSearchExpression.Contains(EWSSearchExpression.Contains.ContainmentMode.Substring,
        		EWSSearchExpression.Contains.ContainmentComparison.IgnoreCaseAndNonSpacingCharacters,
        		EWSSearchExpression.Constants.General.Subject, subject2search);

        ArrayList emails = connector.getEmailsShallow(searchExpression);
        if (emails.size() > 0) {
        	String id = ((ExchangeEmailShallowDTO) emails.get(0)).getId();
        	String changeKey = ((ExchangeEmailShallowDTO) emails.get(0)).getChangeKey();
        	connector.markAsJunk(id, changeKey, true, true);
        	System.out.println("Email: " + id + " marked as junk and move to trash, its sender is blocked");
        }
        else {
        	System.out.println("No Email was found to update, change the subject2search param to find one");
        }

    }

    /**
     * You need to make sure you have sufficient access rights for this operations.
     * to give access rights you can use the following Exchange PowerShell command:
     * add-mailboxpermission test1 -user test2 -accessright fullaccess
     * @throws ExchangeGeneralException
     */
    public static void accessAnotherUserCalendarExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        //notice that we are setting different username and mailbox name
        connector = factory.createEWSConnector(_exchangeHost,
                                               "test2", // test2 user have access rights to test1 mailbox
                                               "Kikaha58",
                                               _prefix, _useSSL, "test1");

        // use this method to force account sharing on email address that can be different then the domain
        //connector.setForcedSharingAddress("user2@domain2.com");
        // make sure you set the domain, in this case the domain is needed.
        connector.setDomain(_domain);
        connector.setMailboxSharingType(ExchangeConstants.MAILBOX_SHARING_TYPE_ACCESS_RIGHTS);

        SimpleDateFormat dateFormat = new SimpleDateFormat(
                "yyyy-MM-dd HH:mm:ss");
        Date startDate = null;
        Date endDate = null;
        try {
            startDate = dateFormat.parse("2008-03-26 11:00:00");
            endDate = dateFormat.parse("2008-03-27 12:00:00");
        } catch (ParseException ex) {
            ex.printStackTrace();
        }

        ArrayList events = connector.getEvents(startDate, endDate);
        for (int i = 0; i < events.size(); i++) {
        	System.out.println(((EWSEventDTO) events.get(i)).getSubject());

            System.out.println("");
        }
    }

    /**
     * You need to make sure you have sufficient access rights for this operations.
     * to give access rights you can use the following Exchange PowerShell command:
     * add-mailboxpermission test1 -user test2 -accessright fullaccess
     * @throws ExchangeGeneralException
     */
    public static void accessAnotherUserEmailsExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        //notice that we are setting different username and mailbox name
        connector = factory.createEWSConnector(_exchangeHost,
                                               "test2", // test2 user have access rights to test1 mailbox
                                               "Kikaha58",
                                               _prefix, _useSSL, "test1");
        // make sure you set the domain, in this case the domain is needed.
        connector.setDomain(_domain);
        connector.setMailboxSharingType(ExchangeConstants.MAILBOX_SHARING_TYPE_ACCESS_RIGHTS);

        connector.setFolder(ExchangeConstants.FOLDER_ENUM_drafts);

        ArrayList emails = connector.getEmailsShallow();
        for (int i = 0; i < emails.size(); i++) {
        	System.out.println(((ExchangeEmailShallowDTO) emails.get(i)).getId());
        	System.out.println(((ExchangeEmailShallowDTO) emails.get(i)).getChangeKey());
            System.out.println(((ExchangeEmailShallowDTO) emails.get(i)).getSubject());
            System.out.println(((ExchangeEmailShallowDTO) emails.get(i)).getTo());
            System.out.println(((ExchangeEmailShallowDTO) emails.get(i)).getCc());
            System.out.println(((ExchangeEmailShallowDTO) emails.get(i)).getDateReceived());
            System.out.println("");
        }
    }

    /**
     * You need to make sure you have sufficient access rights for this operations.
     * to give access rights you can use the following Exchange PowerShell command:
     * add-mailboxpermission test1 -user test2 -accessright fullaccess
     * @throws ExchangeGeneralException
     */
    public static void accessAnotherUserContactsExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        //notice that we are setting different username and mailbox name
        connector = factory.createEWSConnector(_exchangeHost,
                                               "test2", // test2 user have access rights to test1 mailbox
                                               "Kikaha58",
                                               _prefix, _useSSL, "test1");
        // make sure you set the domain, in this case the domain is needed.
        connector.setDomain(_domain);
        connector.setMailboxSharingType(ExchangeConstants.MAILBOX_SHARING_TYPE_ACCESS_RIGHTS);

        ArrayList contacts = connector.getContacts();
        for (int i = 0; i < contacts.size(); i++) {
        	System.out.println(((EWSContactShallowDTO) contacts.get(i)).getId());
        	System.out.println(((EWSContactShallowDTO) contacts.get(i)).getFirstName());
        	System.out.println(((EWSContactShallowDTO) contacts.get(i)).getSurname());
        	System.out.println(((EWSContactShallowDTO) contacts.get(i)).getEmailAddress1());
        	System.out.println(((EWSContactShallowDTO) contacts.get(i)).getBusinessPhone());
        	System.out.println(((EWSContactShallowDTO) contacts.get(i)).getHomePhone());
        	System.out.println(((EWSContactShallowDTO) contacts.get(i)).getMobilePhone());
            System.out.println("");
        }

    }

    /**
     * use the below Exchange powershell command to give test2 user impersonation abilities (in this example, to all users):
     * Get-ExchangeServer | where {$_.IsClientAccessServer -eq $TRUE} | ForEach-Object {Add-ADPermission -Identity $_.distinguishedname -User (Get-User -Identity test2 | select-object).identity -extendedRight ms-Exch-EPI-Impersonation}
     * @throws ExchangeGeneralException
     */
    public static void getAllFoldersFromAnotherUserAccountUsingImpersonationExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        //notice that we are setting different username and mailbox name
        connector = factory.createEWSConnector(_exchangeHost,
                                               "test2", // test2 user have access rights to test1 mailbox
                                               "Kikaha58",
                                               _prefix, _useSSL, "test1");

        // use this method to force account sharing on email address that can be different then the domain
        connector.setForcedSharingAddress("test1@domain1.com");
        connector.setMailboxSharingType(ExchangeConstants.MAILBOX_SHARING_TYPE_IMPERSONATION);
        // make sure you set the domain, in this case the domain is needed.
        connector.setDomain(_domain);

        ArrayList folders = connector.getAllFolders();
        for (int i = 0; i < folders.size(); i++) {
            System.out.println(((EWSFolderDTO) folders.get(i)).getId());
            System.out.println(((EWSFolderDTO) folders.get(i)).getChangeKey());
            System.out.println(((EWSFolderDTO) folders.get(i)).getDisplayName());
            System.out.println(((EWSFolderDTO) folders.get(i)).getChildFolderCount());
            System.out.println(((EWSFolderDTO) folders.get(i)).getTotalCount());
            System.out.println(((EWSFolderDTO) folders.get(i)).getUnreadCount());
            System.out.println("");
        }

    }

    public static void addEventAndGetItByIDExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);


        SimpleDateFormat dateFormat = new SimpleDateFormat(
                "yyyy-MM-dd HH:mm:ss");
        Date startDate = null;
        Date endDate = null;
        try {
            startDate = dateFormat.parse("2008-06-13 11:00:00");
            endDate = dateFormat.parse("2008-06-13 12:00:00");
        } catch (ParseException ex) {
            ex.printStackTrace();
        }

        EWSEventDTO event = new EWSEventDTO();

        event.setSubject("test event");
        event.setDescription("my test event");
        event.setStartDate(startDate);
        event.setEndDate(endDate);
        event.setLocation("test location");

        String[] result = null;
		try {
			result = connector.createEvent(event);
			System.out.println("id: " + result[0]);
	        System.out.println("changeKey: " + result[1]);

	        EWSEventDTO event2 = connector.getEventFull(result[0]);
	        System.out.println(event2.getSubject());
	        System.out.println(event2.getId());
		} catch (ExchangeGeneralException e) {

			e.printStackTrace();
		}


    }


    /**
     * use the below Exchange powershell command to give test2 user impersonation abilities (in this example, to all users):
     * Get-ExchangeServer | where {$_.IsClientAccessServer -eq $TRUE} | ForEach-Object {Add-ADPermission -Identity $_.distinguishedname -User (Get-User -Identity test2 | select-object).identity -extendedRight ms-Exch-EPI-Impersonation}
     * @throws ExchangeGeneralException
     */
    public static void addEventToAnotherUserCalendarExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        //notice that we are setting different username and mailbox name
        connector = factory.createEWSConnector(_exchangeHost,
                                               "test2", // test2 user have access rights to test1 mailbox
                                               "Kikaha58",
                                               _prefix, _useSSL, "test1");

        // use this method to force account sharing on email address that can be different then the domain
        connector.setForcedSharingAddress("test1@domain1.com");


        connector.setMailboxSharingType(ExchangeConstants.MAILBOX_SHARING_TYPE_IMPERSONATION);
        // You can use also the Access rights sharing type.
        //connector.setMailboxSharingType(ExchangeConstants.MAILBOX_SHARING_TYPE_ACCESS_RIGHTS);


        // make sure you set the domain, in this case the domain is needed.
        connector.setDomain(_domain);


        SimpleDateFormat dateFormat = new SimpleDateFormat(
                "yyyy-MM-dd HH:mm:ss");
        Date startDate = null;
        Date endDate = null;
        try {
            startDate = dateFormat.parse("2008-09-29 11:00:00");
            endDate = dateFormat.parse("2008-09-29 12:00:00");
        } catch (ParseException ex) {
            ex.printStackTrace();
        }

        EWSEventDTO event = new EWSEventDTO();

        event.setSubject("test event set from impersonated user");
        event.setDescription("my test event");
        event.setStartDate(startDate);
        event.setEndDate(endDate);
        event.setLocation("test location");

        String[] result = null;
		try {
			result = connector.createEvent(event);
			System.out.println("id: " + result[0]);
	        System.out.println("changeKey: " + result[1]);
		} catch (ExchangeGeneralException e) {

			e.printStackTrace();
		}


    }

    /**
      *  gets the users calendar Availability Data as String between the startDate and the EndDate with the
      * intervalMins, which determines sample rate.<br>
      * <p>Description: String that represent user availability information, the information is presented
      * as a String that holds numbers, every number represent the State (FREE=0,TENTATIVE=1,BUSY=2,OUT_OF_OFFICE=3,NO_INFO=4), and the number place
      * in the String represent the time location in the time section (form StartDate to EndDate) selected
      * according to the interval selected.
      * Here is an example for such String: <BR>
      * 000000000000000000000000002200220000000000 <br>
      * The start time is: 2007-07-22 00:00:00 <br>
      * The end time is  : 2007-07-22 21:00:00 <br>
      * The interval is  : 30mins <br>
      * So every number represent 30mins a time section of 21 hours starting at 2007-07-22 00:00:00 and ending
      *  at 2007-07-22 21:00:00 so according to the availability String, the user was busy from 13:00 till
      *  14:00 and from 15:00 till 16:00 and at the rest of the time he was free.
      * </p>
     * @throws ExchangeGeneralException
     */
    public static void getUserAvailabilityDataStrExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);

        SimpleDateFormat dateFormat = new SimpleDateFormat(
                "yyyy-MM-dd HH:mm:ss");
        Date startDate = null;
        Date endDate = null;
        try {
            startDate = dateFormat.parse("2008-10-13 00:00:00");
            endDate = dateFormat.parse("2008-10-15 23:59:59");
        } catch (ParseException ex) {
            ex.printStackTrace();
        }
        int intervalMins = 60;
        ExchangeEventAttendeeDTO attendee = new ExchangeEventAttendeeDTO();
        attendee.setEmailAddr(_email);


        String avalabilityStr = connector.getUserAvailabilityData(startDate, endDate, intervalMins, attendee);
        System.out.println(avalabilityStr);

    }


    public static void sendEmailWithAttachmentsExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;
        connector = factory.createEWSConnector(_exchangeHost,
                _userName,
                _password,
                _prefix, _useSSL, _accountName);

        EWSEmailDTO email = new EWSEmailDTO();
        email.setSubject("example subject");
        email.setBody("example body");

        EmailAddressDTO[] to = new EmailAddressDTO[2];
        EmailAddressDTO to1 = new EmailAddressDTO();
        to1.setEmailAddress("test2@domain1.com");
        EmailAddressDTO to2 = new EmailAddressDTO();
        to2.setEmailAddress("test1@domain1.com");
        to[0] = to1;
        to[1] = to2;
        email.setTo(to);

        EmailAddressDTO[] cc = new EmailAddressDTO[2];
        EmailAddressDTO cc1 = new EmailAddressDTO();
        cc1.setEmailAddress("test2@domain1.com");
        EmailAddressDTO cc2 = new EmailAddressDTO();
        cc2.setEmailAddress("test1@domain1.com");
        cc[0] = cc1;
        cc[1] = cc2;
        email.setCc(cc);


        EmailAddressDTO[] bcc = new EmailAddressDTO[2];
        EmailAddressDTO bcc1 = new EmailAddressDTO();
        bcc1.setEmailAddress("test2@domain1.com");
        EmailAddressDTO bcc2 = new EmailAddressDTO();
        bcc2.setEmailAddress("test1@domain1.com");
        bcc[0] = bcc1;
        bcc[1] = bcc2;
        email.setBcc(bcc);

        /////////// add attachments ///////////////////////////////////

        AttachmentDTO attach1 = new AttachmentDTO();
        attach1.setName("attachment 1.png");


        AttachmentDTO attach2 = new AttachmentDTO();
        attach2.setName("attachment 2.png");
        byte[] filebuffer = null;
		try {
			FileInputStream fis = new FileInputStream("c:/temp/1.png");
			int size = fis.available();
			filebuffer = new byte[size];
			fis.read(filebuffer);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
        attach1.setByteData(filebuffer);
        attach2.setByteData(filebuffer);

        AttachmentDTO[] attachArr = new AttachmentDTO[2];
        attachArr[0] = attach1;
        attachArr[1] = attach2;
        email.setAttachments(attachArr);
        ////////////////////////////////////////////////////////////////



        //============ send & save a copy to drafts ========
        connector.sendEmail(email, ExchangeConstants.FOLDER_ENUM_sentitems);
        //==================================================


/*
        //====== sends and save a copy to a folder =========
        ArrayList folders = connector.getAllFolders();
        EWSFolderDTO folder = null;
        for (int i = 0; i < folders.size(); i++) {
        	folder = (EWSFolderDTO)folders.get(i);
        	if (folder.getDisplayName().equals("Sent Items"))
        		break;

        }
        connector.sendEmail(email, folder.getId());
        //======================================================
  */
         


    }

    public static void createContactExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);
        EWSContactDTO contact = new EWSContactDTO();
        // set company name AT&T (& is a special character).
        contact.setCompanyName("AT&amp;T");
        contact.setJobTitle("test title");

        contact.setManager("test Manager");
        contact.setDepartment("test Department");
        contact.setBirthday("2008-12-30T00:00:00");
        contact.setAssistantName("test assistantName");

        contact.setEmailAddress1("test_email1@domain1.com");
        contact.setEmailAddress2("test_email2@domain1.com");
        contact.setEmailAddress3("test_email3@domain1.com");

        contact.setFileAs("test11 FileAs");
        contact.setFirstName("test11 firstName");
        contact.setMiddleName("test11 Middle");

        contact.setCategoriesStr("<t:Categories><t:String>Business</t:String><t:String>School</t:String></t:Categories>");

        // this field is generated and cant be created (or updated)
        //contact.setInitials("test initials");

        contact.setSurname("test lastName");
        contact.setNickName("test Nickname");
        contact.setBusinessPhone("test telBusiness");

        // will work Exchange 2010 and above.
        contact.setBusinessHomePage("http://www.test2.com");

        ExchangeAddressDTO businessAddress = new ExchangeAddressDTO();
        businessAddress.setStreet("test bu street");
        businessAddress.setCity("test bu city");
        businessAddress.setCountryOrRegion("test bu country");
        // province or state
        businessAddress.setProvinceOrState("test bu province or state");
        businessAddress.setPostcode("bu postcode");
        contact.setBusinessAddress(businessAddress);

        ExchangeAddressDTO homeAddress = new ExchangeAddressDTO();
        homeAddress.setStreet("test ho street");
        homeAddress.setCity("test ho city");
        homeAddress.setCountryOrRegion("test ho country");
        homeAddress.setProvinceOrState("test ho province or state");
        homeAddress.setPostcode("ho postcode");
        contact.setHomeAddress(homeAddress);

        ExchangeAddressDTO otherAddress = new ExchangeAddressDTO();
        otherAddress.setStreet("test ot street");
        otherAddress.setCity("test ot city");
        otherAddress.setCountryOrRegion("test ot country");
        otherAddress.setProvinceOrState("test ot province or state");
        otherAddress.setPostcode("ot postcode");
        contact.setOtherAddress(otherAddress);

        contact.setHomePhone("telHome");
        contact.setMobilePhone("Mobile phone");
        contact.setHomePhone2("telHome2");
        contact.setBusinessPhone2("telBusiness2");
        contact.setBusinessFax("business fax");
        contact.setHomeFax("homeFax");
        contact.setImAddress1("test imAddress1");
        contact.setImAddress2("test imAddress2");
        contact.setImAddress3("test imAddress3");

        // representation of: <b>bold body<b>
        contact.setBody("&lt;b&gt;bold body&lt;b&gt;");
        contact.setBodyType(EWSContactDTO.BODY_TYPE_HTML);
        //contact.setBody("Text Body");

        // setting business as mailing index (0 for non, 1 for home, 2 for business, 3 for other)
        contact.setPostalAddressIndex(contact.POSTAL_ADDRESS_INDEX_OTHER);

        String[] IdAndChangeKey = connector.createContact(contact);


    }


    public static void sendEmailExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;
        connector = factory.createEWSConnector(_exchangeHost,
                _userName,
                _password,
                _prefix, _useSSL, _accountName);

        EWSEmailDTO email = new EWSEmailDTO();
        email.setSubject("example categories subject");
        //email.setBody("example body");


        email.setBody("&lt;b&gt;updated body&lt;b&gt;");
        email.setIsHtmlBody(true);

        email.setCategoriesStr("<t:Categories><t:String>Business</t:String><t:String>School</t:String></t:Categories>");
        
        // works on Exchange 2010 and up
        //email.setReplyTo("<t:ReplyTo><t:Mailbox><t:EmailAddress>test@test.com</t:EmailAddress></t:Mailbox></t:ReplyTo>");

        EmailAddressDTO[] to = new EmailAddressDTO[2];
        EmailAddressDTO to1 = new EmailAddressDTO();
        to1.setEmailAddress("test3@test.exch2k10.msg");
        EmailAddressDTO to2 = new EmailAddressDTO();
        to2.setEmailAddress("test1@domain1.com");
        to[0] = to1;
        to[1] = to2;
        email.setTo(to);

        EmailAddressDTO[] cc = new EmailAddressDTO[2];
        EmailAddressDTO cc1 = new EmailAddressDTO();
        cc1.setEmailAddress("test2@domain1.com");
        EmailAddressDTO cc2 = new EmailAddressDTO();
        cc2.setEmailAddress("test1@domain1.com");
        cc[0] = cc1;
        cc[1] = cc2;
        email.setCc(cc);


        EmailAddressDTO[] bcc = new EmailAddressDTO[2];
        EmailAddressDTO bcc1 = new EmailAddressDTO();
        bcc1.setEmailAddress("test2@domain1.com");
        EmailAddressDTO bcc2 = new EmailAddressDTO();
        bcc2.setEmailAddress("test1@domain1.com");
        bcc[0] = bcc1;
        bcc[1] = bcc2;
        email.setBcc(bcc);

        //============ send & save a copy to drafts ========
        //connector.sendEmail(email);
        //==================================================



        //====== sends and save a copy to "Sent Items" =========
        ArrayList folders = connector.getAllFolders();
        EWSFolderDTO folder = null;
        for (int i = 0; i < folders.size(); i++) {
        	folder = (EWSFolderDTO)folders.get(i);
        	if (folder.getDisplayName().equals("Sent Items"))
        		break;

        }
        connector.sendEmail(email, folder.getId());
        //======================================================


    }

    // Bring a full contact or a distribution list.
    public static void getContactFullExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);

        ArrayList contacts = connector.getContacts();
        if (contacts.size() > 0) {
        	//EWSContactDTO contact = connector.getFullContact("AQARAHRlc3QxQGRvbWFpbjEuY29tAEYAAAPdLVY/NA2aSINCNie04dgcBwADPlm9F8rTSLOUCPXcUKs0AAADOgAAAAM+Wb0XytNIs5QI9dxQqzQARgq4cHkAAAA=");
        	EWSContactShallowDTO contactShallow =  (EWSContactShallowDTO)contacts.get(0);
        	EWSContactDTO contact = connector.getFullContact(contactShallow.getId());

        	System.out.println(contact.getId());
        	System.out.println(contact.getChangeKey());
        	System.out.println(contact.getItemClass());

        	// this fields are supported from 2007sp1 and up ////
        	System.out.println("getLastModifiedTime: " + contact.getLastModifiedTime());
        	System.out.println("getLastModifiedName: " + contact.getLastModifiedName());
        	////////////////////////////////////////////

            System.out.println(contact.getFirstName());
            System.out.println(contact.getSurname());
            System.out.println(contact.getNickName());
            System.out.println(contact.getMiddleName());
            System.out.println(contact.getInitials());
            System.out.println("getCategoriesStr: " + contact.getCategoriesStr());

            System.out.println("getBirthday: " + contact.getBirthday());
            System.out.println(contact.getDepartment());
            System.out.println(contact.getAssistantName());
            System.out.println(contact.getManager());

            System.out.println(contact.getEmailAddress1());
            System.out.println(contact.getBusinessPhone());
            System.out.println(contact.getHomePhone());
            System.out.println(contact.getMobilePhone());
            System.out.println(contact.getBody());
            if (contact.getBusinessAddress() != null) {
            	ExchangeAddressDTO business = contact.getBusinessAddress();
            	System.out.println("BusinessAddress:");
            	System.out.println(business.getStreet());
            	System.out.println(business.getCity());
            	System.out.println(business.getProvinceOrState());
            	System.out.println(business.getCountryOrRegion());
            	System.out.println("");
            }
            if (contact.getHomeAddress() != null) {
            	ExchangeAddressDTO home = contact.getHomeAddress();
            	System.out.println("HomeAddress:");
            	System.out.println(home.getStreet());
            	System.out.println(home.getCity());
            	System.out.println(home.getProvinceOrState());
            	System.out.println(home.getCountryOrRegion());
            	System.out.println("");
            }
            if (contact.getOtherAddress() != null) {
            	ExchangeAddressDTO other = contact.getOtherAddress();
            	System.out.println("OtherAddress:");
            	System.out.println(other.getStreet());
            	System.out.println(other.getCity());
            	System.out.println(other.getProvinceOrState());
            	System.out.println(other.getCountryOrRegion());
            	System.out.println("");
            }
            System.out.println(contact.getImAddress1());
            System.out.println(contact.getImAddress2());
            System.out.println(contact.getImAddress3());
            System.out.println(contact.getPostalAddressIndex());
            System.out.println(contact.getHomePhone2());
            System.out.println(contact.getHomeFax());
            System.out.println(contact.getBusinessFax());
            // Exchange 2010 and up
            System.out.println(contact.getBusinessHomePage());

            //////////////////////////////getting attachments ///////////////////////////
			if (contact.getAttachments() != null) {
				for (int j=0 ; j < contact.getAttachments().length; j++ ) {
					String attachmentId =  contact.getAttachments()[j].getId();
					String attachmentName = contact.getAttachments()[j].getName();
					System.out.println("attachmentId: " + attachmentId);
					System.out.println("attachmentName: " + attachmentName);
					System.out.println("contentType: " + contact.getAttachments()[j].getContentType());
					System.out.println("");
					System.out.println("");

					// for this example we get only the first attachment
					if (j == 0) {
						System.out.println("============ get full attachment start ==========");
						AttachmentDTO attachment = connector.getFullAttachment(attachmentId);
						try {
							String filePath = null;
							if (attachment.getName() != null)
								filePath = "c:/temp/" + attachment.getName();
							else
								filePath = "c:/temp/attachment.txt";

							System.out.println("Make sure " + attachment.getName() + " Do not contain illigal filename charecters, or it will not be saved.");

							FileOutputStream f = new FileOutputStream(filePath);
							f.write(attachment.getByteData());
							System.out.println("attachment was saved to " + filePath);

						} catch (FileNotFoundException e) {
							//
							e.printStackTrace();
						} catch (IOException e) {

							e.printStackTrace();
						}
						//////////////////////////////getting attachments ///////////////////////////
					}

				}
			}
            System.out.println("");
        }



        else {
        	System.out.println("No Contacts found");
        }


    }

    public static void createTaskExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);
        EWSTaskDTO task = new EWSTaskDTO();
        task.setSubject("test subject");

        task.setBody("Text Body");

        Date now = new Date();
        // now + one day
        Date due = new Date(now.getTime() + (1* 24 * 3600 * 1000));
        task.setDueDate(due);
        task.setStartDate(now);

        // due - 15min for the reminder
        task.setReminderDueBy(new Date(due.getTime() + (15 * 60 * 1000)));

        // a number between 0-100
        task.setPercentComplete("0");

        //  NotStarted
        // InProgress
        // Completed
        // WaitingOnOthers
        // Deferred
        task.setStatus(task.STATUS_NotStarted);

        // if more then 0% then the status need to change accordingly.
        //task.setPercentComplete("30");
        //task.setStatus("InProgress");

        String[] IdAndChangeKey = connector.createTask(task);

        System.out.println("ID: " + IdAndChangeKey[0] + " ChangeKey: " +   IdAndChangeKey[1]);

    }

    public static void getRecurrentEventsExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                _userName,
                _password,
                _prefix, _useSSL, _accountName);



        SimpleDateFormat dateFormat = new SimpleDateFormat(
                "yyyy-MM-dd HH:mm:ss");
        Date startDate = null;
        Date endDate = null;
        try {
            startDate = dateFormat.parse("2009-01-02 06:00:00");
            endDate = dateFormat.parse("2009-01-15 23:00:00");
        } catch (ParseException ex) {
            ex.printStackTrace();
        }

        // this will bring all the recurrence events that have in their subject "Daily recurrence"
        //ArrayList events = connector.getRecurrentMastersEvents(startDate, endDate, "Daily recurrence");

        // use this method to get the recurrent events in the date range (no subject filtering).
        ArrayList events = connector.getRecurrentMastersEvents(startDate, endDate);

        System.out.println("Number of Events: " + events.size() );
        for (int i = 0; i < events.size(); i++) {
        	System.out.println(((EWSEventDTO) events.get(i)).getId());
        	System.out.println(((EWSEventDTO) events.get(i)).getChangeKey());
            System.out.println(((EWSEventDTO) events.get(i)).getSubject());
            System.out.println(((EWSEventDTO) events.get(i)).isRecurrenceMasterRecord());
            System.out.println("");
            if (i == 0) {
            	EWSEventDTO eventFull = connector.getEventFull( ((EWSEventDTO) events.get(i)).getId());
            	System.out.println("=============Getting full event information (for the first event)============");
            	System.out.println(((EWSEventDTO) events.get(i)).getId());
            	System.out.println(((EWSEventDTO) events.get(i)).getChangeKey());
                System.out.println(((EWSEventDTO) events.get(i)).getSubject());
                System.out.println(((EWSEventDTO) events.get(i)).isRecurrenceMasterRecord());
            	System.out.println(eventFull.getDescription());
         		System.out.println("Organizer: " + eventFull.getOrganizer());
         		System.out.println("Recurrence rule: " + eventFull.getRecurrenceRule().getXmlStr());

         	    // this field is not changing even if the event occurrence is updated, it is a common value for all the recurrence series.
         		System.out.println("event.getDateTimeSent(): " + eventFull.getDateTimeSent());
            	System.out.println("=============================================================================");
            }
        }
    }


    public static void addGetUpdateDeleteRecurrentEventExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);


        SimpleDateFormat dateFormat = new SimpleDateFormat(
                "yyyy-MM-dd HH:mm:ss");
        Date startDate = null;
        Date rangeStartDate = null;
        Date rangeEndDate = null;
        Date endDate = null;
        try {
        	rangeStartDate = dateFormat.parse("2008-06-12 11:00:00");
        	rangeEndDate = dateFormat.parse("2008-06-20 12:00:00");
            startDate = dateFormat.parse("2008-06-13 11:00:00");
            endDate = dateFormat.parse("2008-06-13 12:00:00");

        } catch (ParseException ex) {
            ex.printStackTrace();
        }

        EWSEventDTO event = new EWSEventDTO();

        event.setSubject("test event");
        event.setDescription("my test event");
        event.setStartDate(startDate);
        event.setEndDate(endDate);
        event.setLocation("test location");

        // http://msdn.microsoft.com/en-us/library/aa580471%28v=exchg.140%29
        // daily numbered
        EWSRecurrence recurrence = new EWSRecurrence("<t:Recurrence><t:DailyRecurrence><t:Interval>1</t:Interval></t:DailyRecurrence><t:NumberedRecurrence><t:StartDate>2008-06-13Z</t:StartDate><t:NumberOfOccurrences>10</t:NumberOfOccurrences></t:NumberedRecurrence></t:Recurrence>");

        // weekly no end date
        //EWSRecurrence recurrence = new EWSRecurrence("<t:Recurrence><t:WeeklyRecurrence><t:Interval>1</t:Interval><t:DaysOfWeek>Friday</t:DaysOfWeek></t:WeeklyRecurrence><t:NoEndRecurrence><t:StartDate>2008-06-13Z</t:StartDate></t:NoEndRecurrence></t:Recurrence>");

        // monthly no end date
        //EWSRecurrence recurrence = new EWSRecurrence("<t:Recurrence><t:AbsoluteMonthlyRecurrence><t:Interval>1</t:Interval><t:DayOfMonth>13</t:DayOfMonth></t:AbsoluteMonthlyRecurrence><t:NoEndRecurrence><t:StartDate>2008-06-13Z</t:StartDate></t:NoEndRecurrence></t:Recurrence>");

        // yearly no end date
        //EWSRecurrence recurrence = new EWSRecurrence("<t:Recurrence><t:AbsoluteYearlyRecurrence><t:DayOfMonth>13</t:DayOfMonth><t:Month>June</t:Month></t:AbsoluteYearlyRecurrence><t:NoEndRecurrence><t:StartDate>2008-06-13Z</t:StartDate></t:NoEndRecurrence></t:Recurrence>");


        event.setRecurrenceRule(recurrence);

        String[] result = null;
		try {
			result = connector.createEvent(event);

			// create event without sending meeting requests
			//result = connector.createEvent(event, false);

			System.out.println("id: " + result[0]);
	        System.out.println("changeKey: " + result[1]);

	        ArrayList events = connector.getRecurrentMastersEvents(rangeStartDate, rangeEndDate);

	        System.out.println("Number of Recurrence Master Records in range: " + events.size() );
	        for (int i = 0; i < events.size(); i++) {
	        	System.out.println(((EWSEventDTO) events.get(i)).getId());
	        	System.out.println(((EWSEventDTO) events.get(i)).getChangeKey());
	            System.out.println(((EWSEventDTO) events.get(i)).getSubject());
	            System.out.println(((EWSEventDTO) events.get(i)).isRecurrenceMasterRecord());
	            System.out.println("");
	            if (i == 0) {
	            	EWSEventDTO eventFull = connector.getEventFull( ((EWSEventDTO) events.get(i)).getId());
	            	System.out.println("=============Getting full event information (for the first event)============");
	            	System.out.println(((EWSEventDTO) events.get(i)).getId());
	            	System.out.println(((EWSEventDTO) events.get(i)).getChangeKey());
	                System.out.println(((EWSEventDTO) events.get(i)).getSubject());
	                System.out.println(((EWSEventDTO) events.get(i)).isRecurrenceMasterRecord());
	            	System.out.println(eventFull.getDescription());
	         		System.out.println("Organizer: " + eventFull.getOrganizer());
	         		System.out.println("Recurrence rule: " + eventFull.getRecurrenceRule().getXmlStr());
	            	System.out.println("=============================================================================");


	            	//////////////// update the recurrence //////////////////////////////////////////////////
	            	EWSEventDTO event2Update = new EWSEventDTO();
	            	event2Update.setId(eventFull.getId());
	            	event2Update.setChangeKey(eventFull.getChangeKey());
	            	// daily numbered (added 2 events, now we have 12 recurring events)
	                EWSRecurrence recurrence2 = new EWSRecurrence("<t:Recurrence><t:DailyRecurrence><t:Interval>1</t:Interval></t:DailyRecurrence><t:NumberedRecurrence><t:StartDate>2008-06-13Z</t:StartDate><t:NumberOfOccurrences>12</t:NumberOfOccurrences></t:NumberedRecurrence></t:Recurrence>");
	                event2Update.setRecurrenceRule(recurrence2);
	                String[] idAndChangeKey = connector.updateEvent(event2Update);
	            	/////////////////////////////////////////////////////////////////////////////////////////

	            	// deleting the Master record will delete the recurrence
	            	connector.deleteEvent(idAndChangeKey[0], idAndChangeKey[1] , ExchangeConstants.DELETE_TYPE_HARD_DELETE, ExchangeConstants.SEND_MEETING_CANCELLATIONS_NONE);
	            }
	        }
		} catch (ExchangeGeneralException e) {

			e.printStackTrace();
		}


    }

    public static void updateContactExample() throws ExchangeGeneralException {

    	EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);

        ArrayList contacts = connector.getContacts();
        if (contacts.size() > 0){
        	// updating the first contact
        	EWSContactDTO contact = new EWSContactDTO();
        	String origId = ((EWSContactShallowDTO)contacts.get(0)).getId();
        	System.out.println("origId: " + origId);
        	contact.setId(origId);
        	
        	
        	contact.setChangeKey(((EWSContactShallowDTO)contacts.get(0)).getChangeKey());
        	contact.setFirstName(((EWSContactShallowDTO)contacts.get(0)).getFirstName() + " u");
        	//contact.setFirstName(null);
        	contact.setMiddleName(((EWSContactShallowDTO)contacts.get(0)).getMiddleName() + " u");
        	contact.setNickName(((EWSContactShallowDTO)contacts.get(0)).getNickName() + " u");

        	// setting to empty will remove the field 
        	//contact.setMiddleName("");

        	contact.setEmailAddress1(((EWSContactShallowDTO)contacts.get(0)).getEmailAddress1() + "1u");
        	contact.setEmailAddress1DisplayName("addr1 disp");


        	contact.setEmailAddress2(((EWSContactShallowDTO)contacts.get(0)).getEmailAddress2() + "2u");
        	contact.setEmailAddress2DisplayName("addr2 disp");

        	contact.setEmailAddress3(((EWSContactShallowDTO)contacts.get(0)).getEmailAddress3() + "3u");
        	contact.setEmailAddress3DisplayName("addr3 disp");

        	contact.setCompanyName("company" + " u");
        	contact.setFileAs(((EWSContactDTO)contacts.get(0)).getFileAs() + " u");

        	contact.setSurname(((EWSContactShallowDTO)contacts.get(0)).getSurname() + " u");

        	contact.setBusinessPhone(((EWSContactShallowDTO)contacts.get(0)).getBusinessPhone() + "u");
        	contact.setBusinessPhone2(((EWSContactShallowDTO)contacts.get(0)).getBusinessPhone2() + "u");
        	contact.setBusinessFax(((EWSContactDTO)contacts.get(0)).getBusinessFax() + "u");
        	contact.setHomePhone(((EWSContactShallowDTO)contacts.get(0)).getHomePhone() + "u");
        	contact.setHomePhone2(((EWSContactDTO)contacts.get(0)).getHomePhone2() + "u");
        	contact.setHomeFax(((EWSContactDTO)contacts.get(0)).getHomeFax() + "u");
        	contact.setMobilePhone(((EWSContactShallowDTO)contacts.get(0)).getMobilePhone() + "u");

        	// setting text body
        	//contact.setBody("updated body");

        	// setting html body: <b>updated body<b>
        	contact.setBody("&lt;b&gt;updated body&lt;b&gt;");
        	contact.setBodyType(contact.BODY_TYPE_HTML);

        	contact.setJobTitle(((EWSContactShallowDTO)contacts.get(0)).getJobTitle() + " u");
        	contact.setAssistantName("AssistantName");
        	contact.setBirthday("2008-12-30T00:00:00");
        	contact.setDepartment("department");
        	contact.setManager("manager");

        	contact.setImAddress1("Im address1" + " u");
        	contact.setImAddress2("Im address2" + " u");
        	contact.setImAddress3("Im address3" + " u");

        	ExchangeAddressDTO businessAddress = new ExchangeAddressDTO();
            businessAddress.setStreet("test bu street up");
            //businessAddress.setCity("test bu city u");
            businessAddress.setCity("");
            businessAddress.setCountryOrRegion("test bu country u");
            businessAddress.setProvinceOrState("test bu province or state u");
            businessAddress.setPostcode("bu postcode u");
            contact.setBusinessAddress(businessAddress);

            ExchangeAddressDTO homeAddress = new ExchangeAddressDTO();
            homeAddress.setStreet("test ho street u");
            homeAddress.setCity("test ho city u");
            homeAddress.setCountryOrRegion("test ho country u");
            homeAddress.setProvinceOrState("test ho province or state u");
            homeAddress.setPostcode("ho postcode u");
            contact.setHomeAddress(homeAddress);

            ExchangeAddressDTO otherAddress = new ExchangeAddressDTO();
            otherAddress.setStreet("test ot street u");
            otherAddress.setCity("test ot city u");
            otherAddress.setCountryOrRegion("test ot country u");
            otherAddress.setProvinceOrState("test ot province or state u");
            otherAddress.setPostcode("ot postcode u");
            contact.setOtherAddress(otherAddress);

            contact.setPostalAddressIndex(contact.POSTAL_ADDRESS_INDEX_HOME);

        	String[] IdAndChangeKey = connector.updateContact(contact);
        	System.out.println("contact: " + IdAndChangeKey[0]  + " changeKey: " + IdAndChangeKey[1] + "updated.");
        }
        else {
        	System.out.println("No Contacts found.");
        }

    }

    public static void allBasicTaskOperationsExample() throws ExchangeGeneralException {

    	EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;
        EWSGeneralConfiguration.setExchangeVersion(EWSGeneralConfiguration.EXCHANGE_VERSION_2010SP1);

        connector = factory.createEWSConnector(_exchangeHost,
                _userName,
                _password,
                _prefix, _useSSL, _accountName);


        EWSTaskDTO task = new EWSTaskDTO();
        task.setSubject("test subject");

        // EWS support only text body for Tasks, so, no HTML option here.
        task.setBody("Text Body");

        Date now = new Date();

        // now + one day
        Date due = new Date(now.getTime() + (1* 24 * 3600 * 1000));
        task.setDueDate(due);
        task.setStartDate(now);

        // due - 15min for the reminder
        task.setReminderDueBy(new Date(due.getTime() - (15 * 60 * 1000)));

        // a number between 0-100
        task.setPercentComplete("0");

        //  NotStarted
        // InProgress
        // Completed
        // WaitingOnOthers
        // Deferred
        task.setStatus(task.STATUS_NotStarted);

        // if more then 0% then the status need to change accordingly.
        //task.setPercentComplete("30");
        //task.setStatus("InProgress");

        task.setImportance(task.IMPORTANCE_High);

        String[] IdAndChangeKey = connector.createTask(task);

        System.out.println("ID: " + IdAndChangeKey[0] + " ChangeKey: " +   IdAndChangeKey[1]);

        /// update task ////////////////////////////////////////////////////////////////

        task.setId(IdAndChangeKey[0]);
        task.setChangeKey(IdAndChangeKey[1]);
        task.setBody(task.getBody() + " u");
        task.setSubject(task.getSubject() + " u");
        Date newStart = new Date(now.getTime() + (1 * 3600 * 1000));
        task.setStartDate(newStart);

        // now + 2 days
        Date newDue = new Date(now.getTime() + (2* 24 * 3600 * 1000));
        task.setDueDate(newDue);

        // due - 15min for the reminder
        task.setReminderDueBy(new Date(newDue.getTime() - (15 * 60 * 1000)));

        task.setPercentComplete("55");
        task.setStatus(task.STATUS_Deferred);
        // complete the task
        //task.setIsCompleted(true);

        task.setImportance(task.IMPORTANCE_Low);

        String[] result = connector.updateTask(task);

        /////////////////////////////////////////////////////////////////////////////////

        connector.deleteTask(result[0], result[1], ExchangeConstants.DELETE_TYPE_HARD_DELETE, ExchangeConstants.SEND_MEETING_CANCELLATIONS_ALL_AND_SAVE_COPY);
    }


    public static void getTasksExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);
        //connector.setUseNTLMAuthentication(false);

        ArrayList tasks = connector.getTasks();

        for (int i = 0; i < tasks.size(); i++) {

        	System.out.println(((EWSTaskShallowDTO) tasks.get(i)).getId());
        	System.out.println(((EWSTaskShallowDTO) tasks.get(i)).getChangeKey());

        	System.out.println(((EWSTaskShallowDTO) tasks.get(i)).getImportance());
        	System.out.println(((EWSTaskShallowDTO) tasks.get(i)).getSubject());
        	System.out.println(((EWSTaskShallowDTO) tasks.get(i)).getStartDate());
        	System.out.println(((EWSTaskShallowDTO) tasks.get(i)).getDueDate());
        	System.out.println(((EWSTaskShallowDTO) tasks.get(i)).getStatus());
        	System.out.println(((EWSTaskShallowDTO) tasks.get(i)).getPercentComplete());
        	System.out.println(((EWSTaskShallowDTO) tasks.get(i)).getSensitivity());

        	System.out.println(((EWSTaskShallowDTO) tasks.get(i)).getCreationDate());
        	System.out.println(((EWSTaskShallowDTO) tasks.get(i)).getReminderDueBy());

            System.out.println("");
        }

    }


    public static void getFullTaskExample() throws ExchangeGeneralException {

    	EWSConnectorFactory factory = new EWSConnectorFactory();
    	EWSConnectorInterface connector = null;

    	connector = factory.createEWSConnector(_exchangeHost,
    			_userName,
    			_password,
    			_prefix, _useSSL, _accountName);

    	ArrayList tasks = connector.getTasks();


    	if (tasks.size() > 0) {
    		for (int i = 0; i < tasks.size(); i++) {
    			String id = ((EWSTaskShallowDTO) tasks.get(i)).getId();
    			System.out.println(id);
    			String changeKey = ((EWSTaskShallowDTO) tasks.get(i)).getChangeKey();
    			EWSTaskDTO task = connector.getFullTask(id, changeKey);
    			System.out.println(task.getBody());
    			System.out.println(task.getCategoriesStr());


    			System.out.println(((EWSTaskShallowDTO) tasks.get(i)).getId());
    			System.out.println(((EWSTaskShallowDTO) tasks.get(i)).getChangeKey());

    			System.out.println(((EWSTaskShallowDTO) tasks.get(i)).getImportance());
    			System.out.println(((EWSTaskShallowDTO) tasks.get(i)).getSubject());
    			System.out.println(((EWSTaskShallowDTO) tasks.get(i)).getStartDate());
    			System.out.println(((EWSTaskShallowDTO) tasks.get(i)).getDueDate());
    			System.out.println(((EWSTaskShallowDTO) tasks.get(i)).getStatus());
    			System.out.println(((EWSTaskShallowDTO) tasks.get(i)).getPercentComplete());
    			System.out.println(((EWSTaskShallowDTO) tasks.get(i)).getSensitivity());

    			System.out.println(((EWSTaskShallowDTO) tasks.get(i)).getCreationDate());
    			System.out.println(((EWSTaskShallowDTO) tasks.get(i)).getReminderDueBy());


    			//////////////////////////////getting task attachments ///////////////////////////
    			if (task.getAttachments() != null) {
    				for (int j=0 ; j < task.getAttachments().length; j++ ) {
    					String attachmentId =  task.getAttachments()[j].getId();
    					String attachmentName = task.getAttachments()[j].getName();
    					System.out.println("attachmentId: " + attachmentId);
    					System.out.println("attachmentName: " + attachmentName);
    					System.out.println("contentType: " + task.getAttachments()[j].getContentType());
    					System.out.println("");
    					System.out.println("");

    					// for this example we get only the first attachment
    					if (j == 0) {
    						System.out.println("============ get full attachment start ==========");
    						AttachmentDTO attachment = connector.getFullAttachment(attachmentId);
    						try {
    							String filePath = null;
    							if (attachment.getName() != null)
    								filePath = "c:/temp/" + attachment.getName();
    							else
    								filePath = "c:/temp/attachment.txt";

    							System.out.println("Make sure " + attachment.getName() + " Do not contain illigal filename charecters, or it will not be saved.");

    							FileOutputStream f = new FileOutputStream(filePath);
    							f.write(attachment.getByteData());
    							System.out.println("attachment was saved to " + filePath);
    							if (attachment.getContentType() != null && attachment.getContentType().equals("outlook/rfc822")) {
    								System.out.println("This is a msg attachment.");
    								System.out.println("Creating EWSEmailDTO...");
    								String msgXML = new String (attachment.getByteData());
    								EWSEmailDTO emailMsg = connector.parseFullEmailRFC822MsgFromXMLString(msgXML);
    								System.out.println("emailMsg.getSubject(): " + emailMsg.getSubject());
    								System.out.println("emailMsg.getBody(): " + emailMsg.getBody());
    								if (emailMsg.getAttachments() != null)
    									System.out.println("mailMsg.getAttachments().length: " + emailMsg.getAttachments().length);
    							}
    						} catch (FileNotFoundException e) {

    							e.printStackTrace();
    						} catch (IOException e) {

    							e.printStackTrace();
    						}
    						//////////////////////////////getting task attachments ///////////////////////////

    						System.out.println("============ get full attachment end ============");
    					}
    				}
    			}



    		}
    	}



    }


    public static void getTasksWithFilterExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);
        EWSSearchExpression searchExpression = new EWSSearchExpression.IsEqualTo(EWSSearchExpression.Constants.General.Subject, "test subject u");
        ArrayList tasks = connector.getTasks(searchExpression);

        for (int i = 0; i < tasks.size(); i++) {
        	System.out.println(((EWSTaskShallowDTO) tasks.get(i)).getId());
        	System.out.println(((EWSTaskShallowDTO) tasks.get(i)).getChangeKey());

        	System.out.println(((EWSTaskShallowDTO) tasks.get(i)).getImportance());
        	System.out.println(((EWSTaskShallowDTO) tasks.get(i)).getSubject());
        	System.out.println(((EWSTaskShallowDTO) tasks.get(i)).getStartDate());
        	System.out.println(((EWSTaskShallowDTO) tasks.get(i)).getDueDate());
        	System.out.println(((EWSTaskShallowDTO) tasks.get(i)).getStatus());
        	System.out.println(((EWSTaskShallowDTO) tasks.get(i)).getPercentComplete());
        	System.out.println(((EWSTaskShallowDTO) tasks.get(i)).getSensitivity());

        	System.out.println(((EWSTaskShallowDTO) tasks.get(i)).getCreationDate());
        	System.out.println(((EWSTaskShallowDTO) tasks.get(i)).getReminderDueBy());

            System.out.println("");
        }

    }


    public static void getTasksWithFilterAndSorterExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);
        EWSSearchExpression searchExpression = new EWSSearchExpression.IsEqualTo(EWSSearchExpression.Constants.General.Subject, "test task");

        // free text sorter
        //ArrayList tasks = connector.getTasks(searchExpression, new EWSSorter(EWSSorter.ORDER_DESCENDING, "item:DateTimeReceived"));

        ArrayList tasks = connector.getTasks(searchExpression, new EWSSorter(EWSSorter.ORDER_DESCENDING, EWSSorter.FIELD_ORDER_ITEM_Subject));

        for (int i = 0; i < tasks.size(); i++) {
        	System.out.println(((EWSTaskShallowDTO) tasks.get(i)).getId());
        	System.out.println(((EWSTaskShallowDTO) tasks.get(i)).getChangeKey());

        	System.out.println(((EWSTaskShallowDTO) tasks.get(i)).getImportance());
        	System.out.println(((EWSTaskShallowDTO) tasks.get(i)).getSubject());
        	System.out.println(((EWSTaskShallowDTO) tasks.get(i)).getStartDate());
        	System.out.println(((EWSTaskShallowDTO) tasks.get(i)).getDueDate());
        	System.out.println(((EWSTaskShallowDTO) tasks.get(i)).getStatus());
        	System.out.println(((EWSTaskShallowDTO) tasks.get(i)).getPercentComplete());
        	System.out.println(((EWSTaskShallowDTO) tasks.get(i)).getSensitivity());

        	System.out.println(((EWSTaskShallowDTO) tasks.get(i)).getCreationDate());
        	System.out.println(((EWSTaskShallowDTO) tasks.get(i)).getReminderDueBy());

            System.out.println("");
        }

    }

    public static void runRemotePowerShellScriptExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector();
        // run the script using a script file
        //String response = connector.runRemotePowerShellScript("c:/projects/JEC/psb/bin/regular_powershell_script.ps1", "127.0.0.1", 18000, false, 10000);

        // run script file securely.
        String response = connector.runRemotePowerShellScript("c:/projects/JEC/psb/bin/regular_powershell_script.ps1", "127.0.0.1", 1443, true, 100000);

        // run a script using script String.
        //String response = connector.runRemotePowerShellScript("spps 4468", "127.0.0.1", 1443, true, 10000);

//        Example of a blocking script ("restart-service" waits for a parameter)
//        String response = connector.runRemotePowerShellScript("restart-service"  /* script as text */,
//        													  "127.0.0.1"		 /* Host */,
//        													  18000       		 /* port */,
//        													  false       		 /* use SSL */,
//        													  10000       		 /* timeout in milliseconds */);
     }


    /**
     * to run this example successfully, you need to define a user defined (custom) property named "udtest1" with a String type
     * for a contact with first name (Given Name): user_defined1
     * @throws ExchangeGeneralException
     */
    public static void getUserDefinedPropertyValueExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);

        EWSSearchExpression searchExpression = new EWSSearchExpression.IsEqualTo(EWSSearchExpression.Constants.Contacts.GivenName, "user_defined1");
        ArrayList contacts = connector.getContacts(searchExpression);

        if (contacts.size() > 0) {
        	String id = ((EWSContactShallowDTO) contacts.get(0)).getId();
        	System.out.println("Id: " + id);
        	System.out.println(((EWSContactShallowDTO) contacts.get(0)).getChangeKey());
            System.out.println(((EWSContactShallowDTO) contacts.get(0)).getFirstName());

            System.out.println("");

            String userDefinedPropertyValue = connector.getCustomProperty(id, "udtest1", "String");
            System.out.println("userDefinedPropertyValue: " + userDefinedPropertyValue);
        }
        else {
        	System.out.println("User Defined contact not found");
        }

    }

    /**
     * to run this example successfully, you need to define a user defined (custom) property named "udtest1" with a String type
     * for a contact with first name (Given Name): user_defined1
     * @throws ExchangeGeneralException
     */
    public static void getUserDefinedPropertiesValuesExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);

        EWSSearchExpression searchExpression = new EWSSearchExpression.IsEqualTo(EWSSearchExpression.Constants.Contacts.GivenName, "user_defined1");
        ArrayList contacts = connector.getContacts(searchExpression);

        if (contacts.size() > 0) {
        	String id = ((EWSContactShallowDTO) contacts.get(0)).getId();
        	System.out.println("Id: " + id);
        	System.out.println(((EWSContactShallowDTO) contacts.get(0)).getChangeKey());
            System.out.println(((EWSContactShallowDTO) contacts.get(0)).getFirstName());

            System.out.println("");
            EWSUDProp[] propNameTypeArr = {new EWSUDProp("udtest1", "String", null), new EWSUDProp("udtest2", "String", null)};
            EWSUDProp[] userDefinedPropertyValues = connector.getCustomProperties(id, propNameTypeArr);
            for (EWSUDProp p : userDefinedPropertyValues)
            	System.out.println("userDefinedProperty: name:" + p.getName() + " type:" + p.getType() + " value:" + p.getValue());
        }
        else {
        	System.out.println("User Defined contact not found");
        }

    }

    /**
     * For subsequent GetEvents requests, use the last watermark returned in the previous GetEvents request.
     * Set the new watermark like this:
     *
     * notification is the last notification
     * notificationsSubscriptionDTO.setWatermark(notification.getWatermark())
     * then make the call again
     * connector.getNotificationEvents(notificationsSubscriptionDTO);
     * @throws ExchangeGeneralException
     */
    public static void notificationsExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);

        connector.setFolder(ExchangeConstants.FOLDER_ENUM_inbox);
        
        EWSNotificationsSubscriptionDTO notificationsSubscriptionDTO = connector.pullSubscriptionRequest(EWSNotificationsSubscriptionDTO.EVENT_TYPE_NewMailEvent, 10);
        System.out.println("notificationsSubscriptionDTO.getSubscriptionId(): " + notificationsSubscriptionDTO.getSubscriptionId());
        System.out.println("notificationsSubscriptionDTO.getWatermark(): " + notificationsSubscriptionDTO.getWatermark());


        /// send email to test the new email notification
        EWSEmailDTO email = new EWSEmailDTO();
        email.setSubject("example subject");
        EmailAddressDTO[] to = new EmailAddressDTO[1];
        EmailAddressDTO to1 = new EmailAddressDTO();
        to1.setEmailAddress("test1@domain1.com");
        //to1.setEmailAddress("ericshlo13@NetCompsLTD3.onmicrosoft.com");
        to[0] = to1;
        email.setTo(to);
        //send & save a copy to drafts
        connector.sendEmail(email, null);
        // sleep till email arrives
        try {
        	System.out.println("Sleeping 5 secs, waiting to for email to be sent");
			Thread.sleep(5000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
        ////////////////////////////////////////////////


        ArrayList notifications = connector.getNotificationEvents(notificationsSubscriptionDTO);


        if (notifications.size() >= 1) {
        	EWSNotificationEventDTO notification = (EWSNotificationEventDTO)notifications.get(0);
        	System.out.println("notification.getNotificationType(): " + notification.getNotificationType());
        	System.out.println("notification.getItemId(): " + notification.getItemId());
        	System.out.println("notification.getItemChangeKey(): " + notification.getItemChangeKey());
        	System.out.println("notification.getTimeStamp(): " + notification.getTimeStamp());
        	System.out.println("notification.getWatermark(): " + notification.getWatermark());
        	System.out.println("notification.getParentFolderId(): " + notification.getParentFolderId());
        	System.out.println("notification.getParentFolderChangeKey(): " + notification.getParentFolderChangeKey());

        	// getting the new email
        	EWSEmailDTO newEmail = connector.getFullEmail(notification.getItemId());
        	System.out.println("newEmail.getSubject(): " + newEmail.getSubject());
        }
        else {
        	System.out.println("Didn't find the notification");
        }

        // remove the subscription
        connector.unSubscriptionRequest(notificationsSubscriptionDTO);



    }

    /**
     * This Example shows how to disable NTLM authentication, it will work only if your server sets Basic or Digest (or both) authentication.
     * This will increase performance and enable you to override NTLM v2.
     * @throws ExchangeGeneralException
     */
    public static void disableNTLMAuthenticationExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;


        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);

        connector.setUseNTLMAuthentication(false);

        ArrayList emails = connector.getEmailsShallow();
        System.out.println("Emails: " + emails.size());


    }


    /**
     * to run this example successfully, you need to define a user defined (custom) property named "test1" with a String type
     * for a contact with first name (Given Name): user_defined1
     * @throws ExchangeGeneralException
     */
    public static void updateUserDefinedPropertyValueExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);

        EWSSearchExpression searchExpression = new EWSSearchExpression.IsEqualTo(EWSSearchExpression.Constants.Contacts.GivenName, "user_defined1");
        ArrayList contacts = connector.getContacts(searchExpression);

        if (contacts.size() > 0) {
        	String id = ((EWSContactShallowDTO) contacts.get(0)).getId();
        	String changeKey = ((EWSContactShallowDTO) contacts.get(0)).getChangeKey();
        	System.out.println("Id: " + id);
        	System.out.println(((EWSContactShallowDTO) contacts.get(0)).getChangeKey());
            System.out.println(((EWSContactShallowDTO) contacts.get(0)).getFirstName());

            System.out.println("");

            String[] result = connector.updateCustomProperty(id, changeKey, "Contact", "udtest1", "String", "7");
            System.out.println("id: " + result[0] + " changeKey: " + result[1]);
        }
        else {
        	System.out.println("User Defined contact not found");
        }

    }


    /**
     * to run this example successfully, you need to define a user defined (custom) property named "test1" with a String type
     * for a contact with first name (Given Name): user_defined1
     * @throws ExchangeGeneralException
     */
    public static void updateUserDefinedPropertiesExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);

        EWSSearchExpression searchExpression = new EWSSearchExpression.IsEqualTo(EWSSearchExpression.Constants.Contacts.GivenName, "user_defined1");
        ArrayList contacts = connector.getContacts(searchExpression);

        if (contacts.size() > 0) {
        	String id = ((EWSContactShallowDTO) contacts.get(0)).getId();
        	String changeKey = ((EWSContactShallowDTO) contacts.get(0)).getChangeKey();
        	System.out.println("Id: " + id);
        	System.out.println(((EWSContactShallowDTO) contacts.get(0)).getChangeKey());
            System.out.println(((EWSContactShallowDTO) contacts.get(0)).getFirstName());

            System.out.println("");

            EWSUDProp[] propNameTypeValueArr = {new EWSUDProp("udtest1", "String", "5"), new EWSUDProp("udtest2", "String", "4")};
            String[] result = connector.updateCustomProperties(id, changeKey, "Contact", propNameTypeValueArr);
            System.out.println("id: " + result[0] + " changeKey: " + result[1]);
        }
        else {
        	System.out.println("User Defined contact not found");
        }

    }


    public static void addEventWithManualTimezoneSettingExample() throws ExchangeGeneralException {

    	System.out.println("addEventWithManualTimezoneSettingExample");
        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);

        //connector.setUseNTLMAuthentication(false);
        SimpleDateFormat dateFormat = new SimpleDateFormat(
                "yyyy-MM-dd HH:mm:ss");
        Date startDate = null;
        Date endDate = null;
        try {
        	// The start / end date are set according to your current timezone and not selected in event.setTimezoneStr,
        	// If you want the time in the selected timezone you need to shift it accordingly.
            startDate = dateFormat.parse("2011-06-23 00:00:00");
            endDate = dateFormat.parse("2011-06-23 02:00:00");
        } catch (ParseException ex) {
            ex.printStackTrace();
        }

        System.out.println("startDate: " + startDate + " endDate: " + endDate);

        EWSEventDTO event = new EWSEventDTO();

        event.setSubject("test event");
        event.setDescription("my test event");
        event.setStartDate(startDate);
        event.setEndDate(endDate);
        event.setLocation("test location");


        // If not all day event, this short timezone annotation should be used.
        // GMT-08:00 -> PT8H
        // GMT+10:00 -> -PT10H
        // Fully manual
        //event.setTimezoneStr("PT7H");
        // Semi-Automatic
        //event.setTimeZoneShortAnnotationUsingTimeZonXMLGenerator(event.getStartDate());


        // The below 2 lines create All day event with manual timezone XML input.
        // Paris timezone; DayOfWeekIndex: First; Second; Third; Fourth; Last
        /*
        event.setTimeZoneStr(
        			"<t:MeetingTimeZone>" +
						"<t:BaseOffset>-PT1H</t:BaseOffset>" +
						"<t:Standard>" +
							"<t:Offset>P0D</t:Offset>" +
							"<t:RelativeYearlyRecurrence>" +
								"<t:DaysOfWeek>Sunday</t:DaysOfWeek>" +
								"<t:DayOfWeekIndex>Last</t:DayOfWeekIndex>" +
								"<t:Month>October</t:Month>" +
							"</t:RelativeYearlyRecurrence>" +
							"<t:Time>03:00:00</t:Time>" +
						"</t:Standard>" +
						"<t:Daylight>" +
							"<t:Offset>-PT1H</t:Offset>" +
							"<t:RelativeYearlyRecurrence>" +
								"<t:DaysOfWeek>Sunday</t:DaysOfWeek>" +
								"<t:DayOfWeekIndex>Last</t:DayOfWeekIndex>" +
								"<t:Month>March</t:Month>" +
							"</t:RelativeYearlyRecurrence>" +
							"<t:Time>02:00:00</t:Time>" +
						"</t:Daylight>" +
					"</t:MeetingTimeZone>");

        event.setAllDayEvent(true);*/




        // its possible to use this instead the above 2 lines .
        // it will automatically generate the TimeZone String, and will use the startDate as the reference date for the
        // TimeZone XML generation (the reference date effect the daylight saving XML generation).
        event.setAllDayEvent(true);

        // in-case you don't want to use timezone information in an all day event (not recommended):
        //event.setTimezoneStr("");
        //event.setAllDayEvent(true);


        // you can control the reference date of the generated TimeZone XML using this method.
        // In this Example we use the end date as the reference date for the TimeZone XML generation, the default is the startDate
        //event.setAllDayEvent(true);
        //event.setTimeZoneStrUsingTimeZonFullXMLGenerator(event.getEndDate());



        String[] result = null;
		try {
			result = connector.createEvent(event);
			System.out.println("id: " + result[0]);
	        System.out.println("changeKey: " + result[1]);
		} catch (ExchangeGeneralException e) {
			//
			e.printStackTrace();
		}


    }

    public static void explicitPrivateKeyStroreLocationExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        factory.setPrivkeystoreFullPath("c:/temp/privkeystore");
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);

        ArrayList contacts = connector.getContacts();
        System.out.println("");

    }

    public static void createConnectorWithExplicitLicenseFileLocationExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory("C:/temp/");

        EWSConnectorInterface connector = null;

        try {
			connector = factory.createEWSConnector(_exchangeHost,
			                                       _userName,
			                                       _password,
			                                       _prefix, _useSSL, _accountName);
			ArrayList contacts = connector.getContacts();
	        System.out.println("");
		} catch (TrialLicenseException e) {
			System.out.println("License is not valid, expired or not found");
		}

        

    }


    public static void getFullEmailAndForwardItExample() throws ExchangeGeneralException {

    	EWSConnectorFactory factory = new EWSConnectorFactory();
    	EWSConnectorInterface connector = null;

    	connector = factory.createEWSConnector(_exchangeHost,
    			_userName,
    			_password,
    			_prefix, _useSSL, _accountName);

    	// un-comment to change the default folder (inbox)
    	//connector.setFolder(ExchangeConstants.FOLDER_ENUM_drafts);
    	connector.setDomain(_domain);

    	ArrayList emails = connector.getEmailsShallow();
    	String id = null;

    	id = ((ExchangeEmailShallowDTO) emails.get(0)).getId();
    	System.out.println("getting full email: " + id);
    	EWSEmailDTO email = connector.getFullEmail(id);
    	System.out.println(((EWSEmailDTO) email).getId());
    	System.out.println(((EWSEmailDTO) email).getChangeKey());
    	System.out.println(((EWSEmailDTO) email).getSubject());


    	// updating the forward address
    	EmailAddressDTO[] to = new EmailAddressDTO[2];
    	EmailAddressDTO to1 = new EmailAddressDTO();
    	to1.setEmailAddress("test2@domain1.com");
    	EmailAddressDTO to2 = new EmailAddressDTO();
    	to2.setEmailAddress("test1@domain1.com");
    	to[0] = to1;
    	to[1] = to2;
    	email.setTo(to);
    	////

    	// to remove the old cc from the original email, uncomment below line, and comment out the email.setCC(cc)
    	//email.setCc(null);

    	EmailAddressDTO[] cc = new EmailAddressDTO[1];
    	EmailAddressDTO cc1 = new EmailAddressDTO();
    	cc1.setEmailAddress("test1@domain1.com");
    	cc[0] = cc1;
    	email.setCc(cc);


    	AttachmentDTO[] attachments = null;

    	if (((EWSEmailDTO) email).getAttachments() != null) {
    		attachments = new AttachmentDTO[((EWSEmailDTO) email).getAttachments().length];
    		System.out.println("================= Attachments ==================");
    		for (int j=0 ; j < ((EWSEmailDTO) email).getAttachments().length; j++ ) {
    			String attachmentId = ((EWSEmailDTO) email).getAttachments()[j].getId();
    			String attachmentName = ((EWSEmailDTO) email).getAttachments()[j].getName();
    			System.out.println(attachmentId);
    			System.out.println(attachmentName);
    			System.out.println(((EWSEmailDTO) email).getAttachments()[j].getContentType());
    			System.out.println("");
    			System.out.println("============ Full Attachment==========");
    			AttachmentDTO attachment = connector.getFullAttachment(attachmentId);
    			attachments[j] = attachment;
    			System.out.println("============ Full Attachment==========");



    		}
    		System.out.println("================= Attachments ==================");
    	}

    	email.setAttachments(attachments);
    	connector.sendEmail(email);
    	System.out.println("");

    }

    public static void createEmailExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;
        connector = factory.createEWSConnector(_exchangeHost,
                _userName,
                _password,
                _prefix, _useSSL, _accountName);

        EWSEmailDTO email = new EWSEmailDTO();
        email.setSubject("create email example5");
        //email.setBody("example body");

        email.setBody("&lt;b&gt;updated body&lt;b&gt;");
        email.setIsHtmlBody(true);
        email.setImportance(email.IMPORTANCE_low);

        email.setCategoriesStr("<t:Categories><t:String>Business</t:String><t:String>School</t:String></t:Categories>");

        EmailAddressDTO[] to = new EmailAddressDTO[2];
        EmailAddressDTO to1 = new EmailAddressDTO();
        to1.setEmailAddress("test2@domain1.com");
        EmailAddressDTO to2 = new EmailAddressDTO();
        to2.setEmailAddress("test1@domain1.com");
        to[0] = to1;
        to[1] = to2;
        email.setTo(to);

        EmailAddressDTO[] cc = new EmailAddressDTO[2];
        EmailAddressDTO cc1 = new EmailAddressDTO();
        cc1.setEmailAddress("test2@domain1.com");
        EmailAddressDTO cc2 = new EmailAddressDTO();
        cc2.setEmailAddress("test1@domain1.com");
        cc[0] = cc1;
        cc[1] = cc2;
        email.setCc(cc);


        EmailAddressDTO[] bcc = new EmailAddressDTO[2];
        EmailAddressDTO bcc1 = new EmailAddressDTO();
        bcc1.setEmailAddress("test2@domain1.com");
        EmailAddressDTO bcc2 = new EmailAddressDTO();
        bcc2.setEmailAddress("test1@domain1.com");
        bcc[0] = bcc1;
        bcc[1] = bcc2;
        email.setBcc(bcc);


        //============ creates in drafts ========
        //String[] idChangeKey = connector.createEmailInDrafts(email);
        //System.out.println("Id: " + idChangeKey[0]);
        //System.out.println("changeKey: " + idChangeKey[1]);
        //==================================================



        //====== creates an email in the sent items folder =========
        ArrayList folders = connector.getAllFolders();
        EWSFolderDTO folder = null;
        for (int i = 0; i < folders.size(); i++) {
        	folder = (EWSFolderDTO)folders.get(i);
        	if (folder.getDisplayName().equals("Sent Items"))
        		break;

        }
        connector.createEmail(email, folder.getId());
        //======================================================


    }




    public static void updateContactOneFieldExample() throws ExchangeGeneralException {

    	EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);

        ArrayList contacts = connector.getContacts();
        if (contacts.size() > 0){
        	// updating the first contact
        	EWSContactDTO contact = new EWSContactDTO();
        	contact.setId(((EWSContactShallowDTO)contacts.get(0)).getId());

        	contact.setChangeKey(((EWSContactShallowDTO)contacts.get(0)).getChangeKey());

        	contact.setFirstName(((EWSContactShallowDTO)contacts.get(0)).getFirstName() + " u");



        	String[] IdAndChangeKey = connector.updateContact(contact);
        	System.out.println("contact: " + IdAndChangeKey[0]  + " changeKey: " + IdAndChangeKey[1] + "updated.");
        }
        else {
        	System.out.println("No Contacts found.");
        }

    }


    public static void updateContactOneFieldAdressExample() throws ExchangeGeneralException {

    	EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);

        ArrayList contacts = connector.getContacts();
        if (contacts.size() > 0){
        	// updating the first contact
        	EWSContactDTO contact = new EWSContactDTO();
        	contact.setId(((EWSContactShallowDTO)contacts.get(0)).getId());

        	contact.setChangeKey(((EWSContactShallowDTO)contacts.get(0)).getChangeKey());

        	//contact.setFirstName(((EWSContactDTO)contacts.get(0)).getFirstName() + " u");
        	ExchangeAddressDTO businessAddress = new ExchangeAddressDTO();
            businessAddress.setStreet("Street");
            businessAddress.setCity("City");
            businessAddress.setProvinceOrState("State");
            businessAddress.setPostcode("PostCode");
            businessAddress.setCountryOrRegion("Country");
            contact.setBusinessAddress(businessAddress);

            String[] IdAndChangeKey = connector.updateContact(contact);
        	System.out.println("contact: " + IdAndChangeKey[0]  + " changeKey: " + IdAndChangeKey[1] + "updated.");
        }
        else {
        	System.out.println("No Contacts found.");
        }

    }


    public static void notificationsCalendarExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);

        // setting the folder using named folder
        //connector.setFolder(ExchangeConstants.FOLDER_ENUM_calendar);
        ///////////////////////////////////////

        ///////////// setting folder using the folder ID //////////
        ArrayList folders = connector.getAllFolders();
        EWSFolderDTO folder = null;
        for (int i = 0; i < folders.size(); i++) {
        	folder = (EWSFolderDTO)folders.get(i);
        	if (folder.getDisplayName().equals("Calendar"))
        		break;

        }
        if (folder != null)
           connector.setFolder(folder.getId());
        else {
        	System.out.println("Folder not found");
        	return;
        }
        ////////////////////////////////////////////////////////////


        EWSNotificationsSubscriptionDTO notificationsSubscriptionDTO = connector.pullSubscriptionRequest(EWSNotificationsSubscriptionDTO.EVENT_TYPE_CreatedEvent, 10);
        System.out.println("notificationsSubscriptionDTO.getSubscriptionId(): " + notificationsSubscriptionDTO.getSubscriptionId());
        System.out.println("notificationsSubscriptionDTO.getWatermark(): " + notificationsSubscriptionDTO.getWatermark());


        /// create event to test the notification.
        SimpleDateFormat dateFormat = new SimpleDateFormat(
        "yyyy-MM-dd HH:mm:ss");
        Date startDate = null;
        Date endDate = null;
        try {
        	startDate = dateFormat.parse("2009-01-11 11:00:00");
        	endDate = dateFormat.parse("2009-01-11 12:00:00");
        } catch (ParseException ex) {
        	ex.printStackTrace();
        }

        EWSEventDTO event = new EWSEventDTO();

        event.setSubject("test event (for notification)");
        event.setStartDate(startDate);
        event.setEndDate(endDate);

        String[] result = null;
        result = connector.createEvent(event);
        System.out.println("id: " + result[0]);
        System.out.println("changeKey: " + result[1]);
        // sleep till the calendar meeting is created.
        try {
        	Thread.sleep(5000);
        } catch (InterruptedException e) {
        	//
        	e.printStackTrace();
        }
        ////////////////////////////////////////////////


        ArrayList notifications = connector.getNotificationEvents(notificationsSubscriptionDTO);

        if (notifications.size() > 0) {
        	System.out.println("notifications.size(): " + notifications.size());
        	EWSNotificationEventDTO notification = (EWSNotificationEventDTO)notifications.get(0);
        	System.out.println("notification.getNotificationType(): " + notification.getNotificationType());
        	System.out.println("notification.getItemId(): " + notification.getItemId());
        	System.out.println("notification.getItemChangeKey(): " + notification.getItemChangeKey());
        	System.out.println("notification.getTimeStamp(): " + notification.getTimeStamp());
        	System.out.println("notification.getWatermark(): " + notification.getWatermark());
        	System.out.println("notification.getParentFolderId(): " + notification.getParentFolderId());
        	System.out.println("notification.getParentFolderChangeKey(): " + notification.getParentFolderChangeKey());

        	// getting the new calendar event
        	if (notification.getItemId() != null) {
        		EWSEventDTO newCalendarEvent = null;
				try {
					// sometimes the first event is not a correct (getting invalid ID) one, I checked the second
					// and it worked, need to check why it happens
					newCalendarEvent = connector.getEventFull(notification.getItemId());
				} catch (Exception e) {
					System.out.println("Failed to get the EventFull: " + e.getMessage() );
				}
        		if (newCalendarEvent != null)
        			System.out.println("newCalendarEvent.getSubject(): " + newCalendarEvent.getSubject());
        	}
        }
        else {
        	System.out.println("Didn't find the notification");
        }

        // remove the subscription
        connector.unSubscriptionRequest(notificationsSubscriptionDTO);



    }




    public static void addEventToCustomFolderExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);


        SimpleDateFormat dateFormat = new SimpleDateFormat(
                "yyyy-MM-dd HH:mm:ss");
        Date startDate = null;
        Date endDate = null;
        try {
        	startDate = dateFormat.parse("2009-01-10 11:00:00");
            endDate = dateFormat.parse("2009-01-10 12:00:00");
        } catch (ParseException ex) {
            ex.printStackTrace();
        }



        ///////////// setting folder using the folder ID //////////
        ArrayList folders = connector.getAllFolders();
        EWSFolderDTO folder = null;
        for (int i = 0; i < folders.size(); i++) {
        	folder = (EWSFolderDTO)folders.get(i);
        	if (folder.getDisplayName().equals("myCalendar"))
        		break;

        }
        if (folder != null)
           connector.setFolder(folder.getId());
        else {
        	System.out.println("Folder not found");
        	return;
        }
        ////////////////////////////////////////////////////////////


        EWSEventDTO event = new EWSEventDTO();

        event.setSubject("test event1");

        //event.setDescription("my test event");
        event.setHtmlDescription(true);
        event.setDescription("&lt;b&gt;updated body&lt;b&gt;");
        event.setStartDate(startDate);
        event.setEndDate(endDate);
        event.setLocation("test location");
        event.setReminderIsSet(true);
        event.setReminderMinutesBeforeStart(10);

        String[] result = null;
		try {
			result = connector.createEvent(event);

			System.out.println("id: " + result[0]);
	        System.out.println("changeKey: " + result[1]);
		} catch (ExchangeGeneralException e) {
			//
			e.printStackTrace();
		}


    }


    public static void createFolderAndDeleteItExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);
        // creating a folder under root
        //String[] result = connector.createFolder(EWSFolderDTO.FOLDER_TYPE_CalendarFolder, "myCalendar");

        // creating a folder under calendar folder
        String[] result = connector.createFolder("calendar", EWSFolderDTO.FOLDER_TYPE_CalendarFolder, "myCalendar6");
        if (result != null)
        	System.out.println("Folder id: " + result[0] + " Folder ChangeKey: " + result[1]);

        // Delete the folder
        connector.deleteFolder(result[0], result[1], ExchangeConstants.DELETE_TYPE_HARD_DELETE );
    }

    /**
     * possible values for the folder name
     * <xs:enumeration value="calendar" />
     * <xs:enumeration value="contacts" />
     * <xs:enumeration value="deleteditems" />
     * <xs:enumeration value="drafts" />
     * <xs:enumeration value="inbox" />
     * <xs:enumeration value="journal" />
     * <xs:enumeration value="notes" />
     * <xs:enumeration value="outbox" />
     * <xs:enumeration value="sentitems" />
     * <xs:enumeration value="tasks" />
     * <xs:enumeration value="msgfolderroot" />
     * <xs:enumeration value="publicfoldersroot" />
     * <xs:enumeration value="root" />
     * <xs:enumeration value="junkemail" />
     * <xs:enumeration value="searchfolders" />
     * <xs:enumeration value="voicemail" />
     */
    public static void createEmailAndSendItExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;
        connector = factory.createEWSConnector(_exchangeHost,
                _userName,
                _password,
                _prefix, _useSSL, _accountName);

        EWSEmailDTO email = new EWSEmailDTO();
        email.setSubject("create email example");
        //email.setBody("example body");

        //email.setBody("&lt;b&gt;updated body&lt;b&gt;");
        email.setBody(EncodeHTML.encode("<h1>This is test 1.</h1>  I <b>have $3 & also bee\tom  want < my keep the</br> - + * ! @ # $ % ^ & * ( ) - ; \\ / { } [ ] | ' , . ?  <and> </b>"));
        email.setIsHtmlBody(true);

        EmailAddressDTO[] to = new EmailAddressDTO[2];
        EmailAddressDTO to1 = new EmailAddressDTO();
        to1.setEmailAddress("test2@domain1.com");
        EmailAddressDTO to2 = new EmailAddressDTO();
        to2.setEmailAddress("test1@domain1.com");
        to[0] = to1;
        to[1] = to2;
        email.setTo(to);

        EmailAddressDTO[] cc = new EmailAddressDTO[2];
        EmailAddressDTO cc1 = new EmailAddressDTO();
        cc1.setEmailAddress("test2@domain1.com");
        EmailAddressDTO cc2 = new EmailAddressDTO();
        cc2.setEmailAddress("test1@domain1.com");
        cc[0] = cc1;
        cc[1] = cc2;
        email.setCc(cc);


        EmailAddressDTO[] bcc = new EmailAddressDTO[2];
        EmailAddressDTO bcc1 = new EmailAddressDTO();
        bcc1.setEmailAddress("test2@domain1.com");
        EmailAddressDTO bcc2 = new EmailAddressDTO();
        bcc2.setEmailAddress("test1@domain1.com");
        bcc[0] = bcc1;
        bcc[1] = bcc2;
        email.setBcc(bcc);

        //============ creates in Sent Items ========
        String[] idChangeKey = connector.createEmail(email, "sentitems");
        System.out.println("Id: " + idChangeKey[0]);
        System.out.println("changeKey: " + idChangeKey[1]);
        //==================================================

        connector.sendItem(idChangeKey, ExchangeConstants.FOLDER_ENUM_sentitems, false);


    }

    
    public static void moveItemExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);

        connector.setFolder(ExchangeConstants.FOLDER_ENUM_sentitems);

        ArrayList emails = connector.getEmailsShallow();
        
        if (emails.size() > 0) {
        	// getting the first email
        	String itemId = ((ExchangeEmailShallowDTO) emails.get(0)).getId();
        	String itemChangeKey = ((ExchangeEmailShallowDTO) emails.get(0)).getChangeKey();

        	// moving the email to deleted items folder (you can use also the folder ID)
        	//connector.moveItem("deleteditems", itemId, itemChangeKey);
        	// return of Id and changeKey supported on Exchange 2010 and above.
        	String[] idChangekey = connector.moveItem("deleteditems", itemId, null);
        	if (idChangekey != null) {
        	 System.out.println("Id: " + idChangekey[0]);
             System.out.println("changeKey: " + idChangekey[1]);
        	}
        	
        }
        else {
        	System.out.println("no emails found, you need some emails for this example.");
        }

    }

    /**
     * This Example shows how to search the Exchage address book (GAL)
     * @throws ExchangeGeneralException
     */
    public static void resolveNameExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);
        // partial match
        //ArrayList resolvedNames = connector.resolveNames("test11");

        // exact match
        ArrayList resolvedNames = null;
		try {
			resolvedNames = connector.resolveNames("test10@domain1.com");
		} catch (Exception e) {
			AppLogger.getLogger().error(e.getMessage(), e);
		}
		
		
		EWSContactDTO contact = null;
        if (resolvedNames != null && resolvedNames.size() > 0 )
        	contact = (EWSContactDTO)resolvedNames.get(0);
        else
        	return;

        System.out.println(contact.getFirstName());
        System.out.println(contact.getSurname());
        System.out.println(contact.getEmailAddress1());
        System.out.println(contact.getEmailAddress1DisplayName());

        System.out.println(contact.getEmailAddress1());
        System.out.println(contact.getBusinessPhone());

        // Gal mailbox information
        System.out.println("contact.getGalUserId(): " + contact.getGalUserId());
        System.out.println("contact.getGalMailboxName(): " + contact.getGalMailboxName());
        System.out.println("contact.getGalMailboxEmailAddress(): " + contact.getGalMailboxEmailAddress());
        System.out.println("contact.getGalMailboxMailboxType(): " + contact.getGalMailboxMailboxType());
        System.out.println("contact.getGalMailboxRoutingType(): " + contact.getGalMailboxRoutingType());


        if (contact.getBusinessAddress() != null) {
        	ExchangeAddressDTO business = contact.getBusinessAddress();
        	System.out.println("BusinessAddress:");
        	System.out.println(business.getStreet());
        	System.out.println(business.getCity());
        	System.out.println(business.getProvinceOrState());
        	System.out.println(business.getCountryOrRegion());
        	System.out.println("");
        }


    }

    /**
     * setting inline attachments (like email signatures).
     * cid (content ID) should contain only ascii charecters, with no special ones.
     * the cid is the pointer to the attachment content, marked by the same cid (content ID).
     * @throws ExchangeGeneralException
     */
    public static void sendEmailWithInlineAttachmentExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;
        connector = factory.createEWSConnector(_exchangeHost,
                _userName,
                _password,
                _prefix, _useSSL, _accountName);

        // true inline works for Exchange 2010 and above,
        // if your Exchange is 2007 then the image will apear inline, but the attachment will also show in the
        // attachment list.
        //EWSGeneralConfiguration.setExchangeVersion(EWSGeneralConfiguration.EXCHANGE_VERSION_2010);

        EWSGeneralConfiguration.setExchangeVersion(EWSGeneralConfiguration.EXCHANGE_VERSION_2007);

        EWSEmailDTO email = new EWSEmailDTO();
        email.setSubject("Inline Attachment Example8");


        // setting inline attachments (like email signatures):
        // note that the HTML relates to the "cid_attachment1" defined in the attachment cid field below
        //email.setBody("Hi there&lt;BR&gt;&lt;DIV&gt;&lt;IMG src=&quot;cid:cid_attachment1&quot;&gt;&lt;/DIV&gt;&lt;BR&gt;Next line");
        email.setBody(EncodeHTML.encode("Hi there<BR><DIV><IMG src=\"cid:cid_attachment1\"></DIV><BR>Next line"));
        email.setIsHtmlBody(true);

        EmailAddressDTO[] to = new EmailAddressDTO[2];
        EmailAddressDTO to1 = new EmailAddressDTO();
        to1.setEmailAddress("test2@domain1.com");
        EmailAddressDTO to2 = new EmailAddressDTO();
        to2.setEmailAddress("test1@domain1.com");
        to[0] = to1;
        to[1] = to2;
        email.setTo(to);

        EmailAddressDTO[] cc = new EmailAddressDTO[2];
        EmailAddressDTO cc1 = new EmailAddressDTO();
        cc1.setEmailAddress("test2@domain1.com");
        EmailAddressDTO cc2 = new EmailAddressDTO();
        cc2.setEmailAddress("test1@domain1.com");
        cc[0] = cc1;
        cc[1] = cc2;
        email.setCc(cc);


        EmailAddressDTO[] bcc = new EmailAddressDTO[2];
        EmailAddressDTO bcc1 = new EmailAddressDTO();
        bcc1.setEmailAddress("test2@domain1.com");
        EmailAddressDTO bcc2 = new EmailAddressDTO();
        bcc2.setEmailAddress("test1@domain1.com");
        bcc[0] = bcc1;
        bcc[1] = bcc2;
        email.setBcc(bcc);

        /////////// add attachments ///////////////////////////////////

        AttachmentDTO attach1 = new AttachmentDTO();
        // this attachment is used inline.
        attach1.setName("attachment1.png");
        // cid should contain only ascii charecters, with no special ones.
        attach1.setCid("cid_attachment1");


        byte[] filebuffer = null;
		try {
			FileInputStream fis = new FileInputStream("c:/temp/1.png");
			int size = fis.available();
			filebuffer = new byte[size];
			fis.read(filebuffer);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
        attach1.setByteData(filebuffer);


        AttachmentDTO[] attachArr = new AttachmentDTO[1];
        attachArr[0] = attach1;

        email.setAttachments(attachArr);
        ////////////////////////////////////////////////////////////////

        //============ send & save a copy to drafts ========
        connector.sendEmail(email, null);
        //==================================================


    }

    /**
     * This example was verified also on Exchange 2010 sp1
     * You need to make sure you have sufficient access rights for this operations.
     * to give access rights you can use the following Exchange PowerShell command:
     * add-mailboxpermission test1 -user test2 -accessright fullaccess
     * @throws ExchangeGeneralException
     */
    public static void createTaskToAnotherUser() throws ExchangeGeneralException {

    	EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        //notice that we are setting different username and mailbox name
        connector = factory.createEWSConnector(_exchangeHost,
                                               "test2", // test2 user have access rights to test1 mailbox
                                               "Kikaha58",
                                               _prefix, _useSSL, "test1");

        // use this method to force account sharing on email address that can be different then the domain
        connector.setForcedSharingAddress("test1@domain1.com");

        // make sure you set the domain, in this case the domain is needed.
        connector.setDomain(_domain);
        connector.setMailboxSharingType(ExchangeConstants.MAILBOX_SHARING_TYPE_ACCESS_RIGHTS);


        EWSTaskDTO task = new EWSTaskDTO();
        task.setSubject("test subject");

        task.setBody("Text Body");

        Date now = new Date();

        // now + one day
        Date due = new Date(now.getTime() + (1* 24 * 3600 * 1000));
        task.setDueDate(due);
        task.setStartDate(now);

        // due - 15min for the reminder
        task.setReminderDueBy(new Date(due.getTime() - (15 * 60 * 1000)));

        // a number between 0-100
        task.setPercentComplete("0");

        //  NotStarted
        // InProgress
        // Completed
        // WaitingOnOthers
        // Deferred
        task.setStatus(task.STATUS_NotStarted);

        // if more then 0% then the status need to change accordingly.
        //task.setPercentComplete("30");
        //task.setStatus("InProgress");

        task.setImportance(task.IMPORTANCE_High);

        String[] IdAndChangeKey = connector.createTask(task);

        System.out.println("ID: " + IdAndChangeKey[0] + " ChangeKey: " +   IdAndChangeKey[1]);
    }

    /**
     * You need to make sure you have sufficient access rights for this operations.
     * to give access rights you can use the following Exchange PowerShell command:
     * add-mailboxpermission test1 -user test2 -accessright fullaccess
     * @throws ExchangeGeneralException
     */
    public static void createContactToAnotherUserExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        //notice that we are setting different username and mailbox name
        connector = factory.createEWSConnector(_exchangeHost,
                                               "test2", // test2 user have access rights to test1 mailbox
                                               "Kikaha58",
                                               _prefix, _useSSL, "test1");

        // use this method to force account sharing on email address that can be different then the domain
        connector.setForcedSharingAddress("test1@domain1.com");
        // make sure you set the domain, in this case the domain is needed.
        connector.setDomain(_domain);
        connector.setMailboxSharingType(ExchangeConstants.MAILBOX_SHARING_TYPE_ACCESS_RIGHTS);

        EWSContactDTO contact = new EWSContactDTO();
        contact.setCompanyName("test company");
        contact.setJobTitle("test job title");

        contact.setEmailAddress1("test_email1@domain1.com");


        contact.setFileAs("test file as");
        contact.setFirstName("test firstName");
        contact.setMiddleName("test Middle");
        contact.setSurname("test lastName");
        contact.setBusinessPhone("test telBusiness");


        String[] IdAndChangeKey = connector.createContact(contact);


    }


    public static void notificationsDeleteEventExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);

        // setting the folder using named folder
        connector.setFolder(ExchangeConstants.FOLDER_ENUM_calendar);
        ///////////////////////////////////////

        EWSNotificationsSubscriptionDTO notificationsSubscriptionDTO = connector.pullSubscriptionRequest(EWSNotificationsSubscriptionDTO.EVENT_TYPE_DeletedEvent, 10);
        System.out.println("notificationsSubscriptionDTO.getSubscriptionId(): " + notificationsSubscriptionDTO.getSubscriptionId());
        System.out.println("notificationsSubscriptionDTO.getWatermark(): " + notificationsSubscriptionDTO.getWatermark());


        /// create event to test the delete notification.
        SimpleDateFormat dateFormat = new SimpleDateFormat(
        "yyyy-MM-dd HH:mm:ss");
        Date startDate = null;
        Date endDate = null;
        try {
        	startDate = dateFormat.parse("2009-01-12 11:00:00");
        	endDate = dateFormat.parse("2009-01-12 12:00:00");
        } catch (ParseException ex) {
        	ex.printStackTrace();
        }

        EWSEventDTO event = new EWSEventDTO();

        event.setSubject("test event (for notification)");
        event.setStartDate(startDate);
        event.setEndDate(endDate);

        String[] result = null;
        result = connector.createEvent(event);
        System.out.println("id: " + result[0]);
        System.out.println("changeKey: " + result[1]);
        // sleep till the calendar meeting is created.
        try {
        	Thread.sleep(5000);
        } catch (InterruptedException e) {
        	//
        	e.printStackTrace();
        }

        connector.deleteEvent(result[0], result[1], "HardDelete", "SendToNone");
        // sleep till the calendar meeting is deleted.
        try {
        	Thread.sleep(5000);
        } catch (InterruptedException e) {

        	e.printStackTrace();
        }
        ////////////////////////////////////////////////


        ArrayList notifications = connector.getNotificationEvents(notificationsSubscriptionDTO);

        if (notifications.size() > 1) {
        	System.out.println("notifications.size(): " + notifications.size());
        	EWSNotificationEventDTO notification = (EWSNotificationEventDTO)notifications.get(1);
        	System.out.println("notification.getNotificationType(): " + notification.getNotificationType());
        	System.out.println("notification.getItemId(): " + notification.getItemId());
        	System.out.println("notification.getItemChangeKey(): " + notification.getItemChangeKey());
        	System.out.println("notification.getTimeStamp(): " + notification.getTimeStamp());
        	System.out.println("notification.getWatermark(): " + notification.getWatermark());
        	System.out.println("notification.getParentFolderId(): " + notification.getParentFolderId());
        	System.out.println("notification.getParentFolderChangeKey(): " + notification.getParentFolderChangeKey());
        }
        else {
        	System.out.println("Didn't find the notification");
        }


        // remove the subscription
        connector.unSubscriptionRequest(notificationsSubscriptionDTO);

    }


    public static void addAttachmentsToEventExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);

        String subject2update = "test event attach";
        EWSSearchExpression searchExpression = new EWSSearchExpression.Contains(EWSSearchExpression.Contains.ContainmentMode.Substring,
        		EWSSearchExpression.Contains.ContainmentComparison.IgnoreCaseAndNonSpacingCharacters,
        		EWSSearchExpression.Constants.General.Subject, subject2update);
        ArrayList events = connector.getEvents(searchExpression);
        if (events.size() > 0) {

        	EWSEventDTO event = connector.getEventFull(((EWSEventDTO)events.get(0)).getId());

        	//////// creating the attachments /////////////////////////////////////////////

            AttachmentDTO attach1 = new AttachmentDTO();
            attach1.setName("attachment 1.png");


            AttachmentDTO attach2 = new AttachmentDTO();
            attach2.setName("attachment 2.png");
            byte[] filebuffer = null;
    		try {
    			FileInputStream fis = new FileInputStream("c:/temp/1.png");
    			int size = fis.available();
    			filebuffer = new byte[size];
    			fis.read(filebuffer);
    		} catch (FileNotFoundException e) {
    			e.printStackTrace();
    		} catch (IOException e) {
    			e.printStackTrace();
    		}
            attach1.setByteData(filebuffer);
            attach2.setByteData(filebuffer);

            AttachmentDTO[] attachArr = new AttachmentDTO[2];
            attachArr[0] = attach1;
            attachArr[1] = attach2;

        	///////////////////////////////////////////////////////////////////////////////

            String[] idChangeKey = connector.addAttachments(event.getId(), event.getChangeKey(), attachArr);
            System.out.println("Id: " + idChangeKey[0] + " ChangeKey: " + idChangeKey[1]);



        }
    }

 // explicit log4j property file location Example.
    public static void explicitLog4jPropFileLocationExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        factory.setLog4jPropFilePath("c:/temp/log4j.properties");
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);

        ArrayList contacts = connector.getContacts();
        System.out.println("num of contacts: " + contacts.size());

    }


    public static void updateEventTimeZoneExchange2007Example() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);

        String subject2update = "test event";
        EWSSearchExpression searchExpression = new EWSSearchExpression.Contains(EWSSearchExpression.Contains.ContainmentMode.Substring,
        		EWSSearchExpression.Contains.ContainmentComparison.IgnoreCaseAndNonSpacingCharacters,
        		EWSSearchExpression.Constants.General.Subject, subject2update);
        ArrayList events = connector.getEvents(searchExpression);
        if (events.size() > 0) {

        	EWSEventDTO event = connector.getEventFull(((EWSEventDTO)events.get(0)).getId());

        	EWSEventDTO event2update = new EWSEventDTO();
        	event2update.setId(event.getId());
        	event2update.setChangeKey(event.getChangeKey());


        	// Paris timezone; DayOfWeekIndex: First; Second; Third; Fourth; Last
            /*
        	String timezoneStr =
            			"<t:MeetingTimeZone>" +
    						"<t:BaseOffset>-PT1H</t:BaseOffset>" +
    						"<t:Standard>" +
    							"<t:Offset>P0D</t:Offset>" +
    							"<t:RelativeYearlyRecurrence>" +
    								"<t:DaysOfWeek>Sunday</t:DaysOfWeek>" +
    								"<t:DayOfWeekIndex>Last</t:DayOfWeekIndex>" +
    								"<t:Month>October</t:Month>" +
    							"</t:RelativeYearlyRecurrence>" +
    							"<t:Time>03:00:00</t:Time>" +
    						"</t:Standard>" +
    						"<t:Daylight>" +
    							"<t:Offset>-PT1H</t:Offset>" +
    							"<t:RelativeYearlyRecurrence>" +
    								"<t:DaysOfWeek>Sunday</t:DaysOfWeek>" +
    								"<t:DayOfWeekIndex>Last</t:DayOfWeekIndex>" +
    								"<t:Month>March</t:Month>" +
    							"</t:RelativeYearlyRecurrence>" +
    							"<t:Time>02:00:00</t:Time>" +
    						"</t:Daylight>" +
    					"</t:MeetingTimeZone>";
    				
        	event2update.setTimezoneStr(timezoneStr);
			*/


        	// its possible to use this instead the above 2 lines.
        	// This example use the original event startDate as the reference date, the reference date effects the daylight saving generation.
        	event2update.setTimeZoneStrUsingTimeZonFullXMLGenerator(event.getStartDate());




        	try {
        		String[] idChangeKey = connector.updateEvent(event2update);
        		System.out.println("Id: " + idChangeKey[0] + " ChangeKey: " + idChangeKey[1]);

        	} catch (ExchangeGeneralException e) {
        		// TODO Auto-generated catch block
        		e.printStackTrace();
        	}
        }


    }

    // this can be applyed to all handlers (contacts, calendar, tasks etc)
    public static void updateItemFieldToNull() throws ExchangeGeneralException {
    	EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);

        ArrayList contacts = connector.getContacts();

        // setting the first contact middle name to null
        if (contacts.size() > 0) {
        	String id = (((EWSContactShallowDTO) contacts.get(0)).getId());
        	String changeKey = (((EWSContactShallowDTO) contacts.get(0)).getChangeKey());
        	connector.updateItemRemoveField(id, changeKey, "<t:FieldURI FieldURI=\"contacts:MiddleName\"/>");
        }

    }


    public static void getDeletedEventsFilterExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);

        connector.setFolder(ExchangeConstants.FOLDER_ENUM_deleteditems);

        // Text Expression that get unread emails from a specific date:
        String searchXmlStr ="<Restriction>"

             +"<t:IsEqualTo>"
             +"<t:FieldURI FieldURI=\"item:ItemClass\"/>"
             +"<t:FieldURIOrConstant>"
             +"<t:Constant Value=\"IPM.Appointment\"/>"
             +"</t:FieldURIOrConstant>"
             +"</t:IsEqualTo>"

            +"</Restriction>";

        EWSSearchExpression searchExpression = new EWSSearchExpression(searchXmlStr);

        ArrayList emails = connector.getEmailsShallow(searchExpression);
        for (int i = 0; i < emails.size(); i++) {
        	System.out.println(((ExchangeEmailShallowDTO) emails.get(i)).getId());
            System.out.println(((ExchangeEmailShallowDTO) emails.get(i)).getSubject());
            System.out.println(((ExchangeEmailShallowDTO) emails.get(i)).getTo());
            System.out.println(((ExchangeEmailShallowDTO) emails.get(i)).getCc());
            System.out.println(((ExchangeEmailShallowDTO) emails.get(i)).getDateReceived());
            System.out.println(((ExchangeEmailShallowDTO) emails.get(i)).getItemClass());
            System.out.println("");
        }
    }


    public static void getContactExtendedFieldExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);

        ArrayList contacts = connector.getContacts();
        if (contacts.size() > 0) {
        	//EWSContactDTO contact = connector.getFullContact("AQARAHRlc3QxQGRvbWFpbjEuY29tAEYAAAPdLVY/NA2aSINCNie04dgcBwADPlm9F8rTSLOUCPXcUKs0AAADOgAAAAM+Wb0XytNIs5QI9dxQqzQARgq4cHkAAAA=");
        	EWSContactShallowDTO contactShallow =  (EWSContactShallowDTO)contacts.get(0);
        	// userfield1 = 32847; userfield2 = 32848; userfield3 = 32849; userfield4 = 32850
        	String field = connector.getContactExtendedField(contactShallow.getId(), "32899");

        	System.out.println("field: " + field);

        }
    }


    public static void getContactTitleUsingExtendedFieldExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);

        ArrayList contacts = connector.getContacts();
        if (contacts.size() > 0) {

        	EWSContactShallowDTO contactShallow =  (EWSContactShallowDTO)contacts.get(0);
        	// The MAPI of title is: 14917
        	String field = connector.getContactExtendedField(contactShallow.getId(), "14917");

        	System.out.println("field: " + field);

        }
    }




    /**
     * You need to make sure you have sufficient access rights for this operations.
     * to give access rights you can use the following Exchange PowerShell command:
     * add-mailboxpermission test1 -user test2 -accessright fullaccess
     * @throws ExchangeGeneralException
     */
    public static void updateContactWithAccessRightsSharingExample() throws ExchangeGeneralException {

    	EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               "test2",
                                               _password,
                                               _prefix, _useSSL, "test1");

        connector.setMailboxSharingType(ExchangeConstants.MAILBOX_SHARING_TYPE_ACCESS_RIGHTS);
        connector.setDomain(_domain);

        ArrayList contacts = connector.getContacts();
        if (contacts.size() > 0){
        	// update the fist name of the first contact
        	EWSContactDTO contact = new EWSContactDTO();

        	contact.setId(((EWSContactShallowDTO)contacts.get(0)).getId());
        	contact.setChangeKey(((EWSContactShallowDTO)contacts.get(0)).getChangeKey());
        	contact.setFirstName(((EWSContactShallowDTO)contacts.get(0)).getFirstName() + " u");
        	contact.setEmailAddress1(((EWSContactShallowDTO)contacts.get(0)).getEmailAddress1() + "u");
        	contact.setEmailAddress2(((EWSContactShallowDTO)contacts.get(0)).getEmailAddress2() + "u");
        	contact.setEmailAddress3(((EWSContactShallowDTO)contacts.get(0)).getEmailAddress3() + "u");
        	contact.setFileAs(((EWSContactDTO)contacts.get(0)).getFileAs() + " u");
        	contact.setSurname(((EWSContactShallowDTO)contacts.get(0)).getSurname() + " u");

        	contact.setBusinessPhone(((EWSContactShallowDTO)contacts.get(0)).getBusinessPhone() + "u");
        	contact.setMobilePhone(((EWSContactShallowDTO)contacts.get(0)).getMobilePhone() + "u");
            contact.setPostalAddressIndex(EWSContactDTO.POSTAL_ADDRESS_INDEX_BUSINESS);


        	String[] IdAndChangeKey = connector.updateContact(contact);
        	System.out.println("contact: " + IdAndChangeKey[0]  + " changeKey: " + IdAndChangeKey[1] + "updated.");
        }
        else {
        	System.out.println("No Contacts found.");
        }

    }


    public static void setContactExtendedFieldExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);

        ArrayList contacts = connector.getContacts();
        if (contacts.size() > 0) {
        	 EWSContactShallowDTO contactShallow =  (EWSContactShallowDTO)contacts.get(0);
        	// Example MAPI properties: userfield1 = 32847; userfield2 = 32848; userfield3 = 32849; userfield4 = 32850; emailAddress1 = 32899
        	connector.setContactExtendedField(contactShallow.getId(),contactShallow.getChangeKey(), "32899", "testMAPI@domain1.com");

        }
    }


    public static void setContactTitleUsingExtendedFieldExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);

        ArrayList contacts = connector.getContacts();
        if (contacts.size() > 0) {
        	 EWSContactShallowDTO contactShallow =  (EWSContactShallowDTO)contacts.get(0);
        	// The MAPI of title is: 14917
        	connector.setContactExtendedField(contactShallow.getId(),contactShallow.getChangeKey(), "14917", "Mr.");

        }
    }


    public static void additionalSoapHeaderExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);

        // this request will not work with EWS, this is just an example.
        // a valid EWS request can be a SAML token.
        String additionalSoapHeadersStr = "<soap:Header><m:Trans xmlns:m=\"http://www.w3schools.com/transaction/\" soap:mustUnderstand=\"1\">234</m:Trans></soap:Header>";
        connector.setAdditionalSoapHeaders(additionalSoapHeadersStr);

        SimpleDateFormat dateFormat = new SimpleDateFormat(
                "yyyy-MM-dd HH:mm:ss");
        Date startDate = null;
        Date endDate = null;
        try {
            startDate = dateFormat.parse("2009-01-11 06:00:00");
            endDate = dateFormat.parse("2009-01-13 23:00:00");
        } catch (ParseException ex) {
            ex.printStackTrace();
        }

        ArrayList events = connector.getEvents(startDate, endDate);
        System.out.println("Number of Events: " + events.size() );
        for (int i = 0; i < events.size(); i++) {
        	System.out.println(((EWSEventDTO) events.get(i)).getId());
        	System.out.println(((EWSEventDTO) events.get(i)).getChangeKey());
            System.out.println(((EWSEventDTO) events.get(i)).getSubject());
            System.out.println("");
        }
    }


    public static void getFullEmailUsingSearchSubject() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);

        // un-commnent to change the default folder (inbox)
        connector.setFolder(ExchangeConstants.FOLDER_ENUM_drafts);


        EWSSearchExpression searchExpression = new EWSSearchExpression.Contains(EWSSearchExpression.Contains.ContainmentMode.Substring,
        		EWSSearchExpression.Contains.ContainmentComparison.IgnoreCaseAndNonSpacingCharacters,
        		EWSSearchExpression.Constants.General.Subject, "example categories subject");

        ArrayList emails = connector.getEmailsShallow(searchExpression);
        for (int i = 0; i < emails.size(); i++) {
        	if (i == 1) {
        		System.out.println(((ExchangeEmailShallowDTO) emails.get(i)).getId());
        		System.out.println(((ExchangeEmailShallowDTO) emails.get(i)).getSubject());

        		String id = ((ExchangeEmailShallowDTO) emails.get(i)).getId();
        		String changeKey = ((ExchangeEmailShallowDTO) emails.get(i)).getChangeKey();
        		System.out.println("getting full email: " + id + " changeKey: " + changeKey);

        		// if you don't have to get the email mime content, use this method for better performance.
        		//EWSEmailDTO email = connector.getFullEmail(id, changeKey);

        		// setting the includeMimeContent flag to true, will get also the mime content of the email,
        		// use the EWSEmailDTO getMimeContent() to get the base64 encoded mime content of the email.
        		EWSEmailDTO email = connector.getFullEmail(id, changeKey, true);

        		//EWSEmailDTO email = connector.getFullEmail(id, changeKey);



        		System.out.println(((EWSEmailDTO) email).getId());
        		System.out.println(((EWSEmailDTO) email).getChangeKey());
        		System.out.println("getSubject: " + ((EWSEmailDTO) email).getSubject());
        		System.out.println("getImportance: " + ((EWSEmailDTO) email).getImportance());
        		System.out.println("getItemClass: " + ((EWSEmailDTO) email).getItemClass());
        		System.out.println("getItemClass: " + ((EWSEmailDTO) email).getCategoriesStr());


        		System.out.println("");
        	}
        }

    }


    /**
     * This example needs and event with the subject: "test attendees don't remove"
     * possible values: Unknown; Organizer; Tentative; Accept; Decline; NoResponseReceived
     * @throws ExchangeGeneralException
     */
    public static void getEventAttendeesResponseTypeExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);
        String subject2find = "test attendees don't remove";
        EWSSearchExpression searchExpression = new EWSSearchExpression.Contains(EWSSearchExpression.Contains.ContainmentMode.Substring,
        		EWSSearchExpression.Contains.ContainmentComparison.IgnoreCaseAndNonSpacingCharacters,
        		EWSSearchExpression.Constants.General.Subject, subject2find);
        ArrayList events = connector.getEvents(searchExpression);
        if (events != null && events.size() > 0) {
        	EWSEventDTO eventShallow = (EWSEventDTO)events.get(0);
        	EWSEventDTO event = connector.getEventFull(eventShallow.getId());



        	//////////////////////////////getting event attendees response type ///////////////////////////
    		if ( event.getTo()!= null) {
    			System.out.println(" number of attendees: " + event.getTo().size());

    			for (int j = 0; j < (event).getTo().size(); j++) {
    				ExchangeEventAttendeeDTO attendee = ((ExchangeEventAttendeeDTO)(event).getTo().get(j));
    				System.out.println("attendee " + j + ":" + attendee.getDisplayName() +
    						" " + attendee.getEmailAddr() + " responseType: " + attendee.getResponseType()  );

    				if (attendee.getType() == ExchangeEventAttendeeDTO.ATTENDEE_TYPE_REQUIRED) {
    					System.out.println("REQUIRED");
    				}
    				else if (attendee.getType() == ExchangeEventAttendeeDTO.ATTENDEE_TYPE_OPTIONAL) {
    					System.out.println("OPTIONAL");
    				}
    				System.out.println("");
    			}
    		}
    		////////////////////////////////////////////////////////////////////////////////////////////////

        }
    }



    public static void sendEmailUsingImpersonationExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;
        connector = factory.createEWSConnector(_exchangeHost,
                "test2",
                _password,
                _prefix, _useSSL, "test1");

        connector.setForcedSharingAddress("test1@domain1.com");
        connector.setMailboxSharingType(ExchangeConstants.MAILBOX_SHARING_TYPE_IMPERSONATION);
        // make sure you set the domain, in this case the domain is needed.
        connector.setDomain(_domain);

        EWSEmailDTO email = new EWSEmailDTO();

        email.setBody("example body");
        email.setSubject("test send using impersonation");

        //email.setBody("&lt;b&gt;updated body&lt;b&gt;");
        //email.setIsHtmlBody(true);

        EmailAddressDTO[] to = new EmailAddressDTO[2];
        EmailAddressDTO to1 = new EmailAddressDTO();
        to1.setEmailAddress("test2@domain1.com");
        EmailAddressDTO to2 = new EmailAddressDTO();
        to2.setEmailAddress("test1@domain1.com");
        to[0] = to1;
        to[1] = to2;
        email.setTo(to);

        EmailAddressDTO[] cc = new EmailAddressDTO[2];
        EmailAddressDTO cc1 = new EmailAddressDTO();
        cc1.setEmailAddress("test2@domain1.com");
        EmailAddressDTO cc2 = new EmailAddressDTO();
        cc2.setEmailAddress("test1@domain1.com");
        cc[0] = cc1;
        cc[1] = cc2;
        email.setCc(cc);


        EmailAddressDTO[] bcc = new EmailAddressDTO[2];
        EmailAddressDTO bcc1 = new EmailAddressDTO();
        bcc1.setEmailAddress("test2@domain1.com");
        EmailAddressDTO bcc2 = new EmailAddressDTO();
        bcc2.setEmailAddress("test1@domain1.com");
        bcc[0] = bcc1;
        bcc[1] = bcc2;
        email.setBcc(bcc);

        //============ send & save a copy to drafts ========
        connector.sendEmail(email);
        //==================================================



    }


    public static void sendEmailUsingAccessRightsExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;
        connector = factory.createEWSConnector(_exchangeHost,
                "administrator",
                "nasich11",
                _prefix, _useSSL, "test1");

        connector.setForcedSharingAddress("test1@domain1.com");
        connector.setMailboxSharingType(ExchangeConstants.MAILBOX_SHARING_TYPE_ACCESS_RIGHTS);
        // make sure you set the domain, in this case the domain is needed.
        connector.setDomain(_domain);

        EWSEmailDTO email = new EWSEmailDTO();

        email.setBody("example body");
        email.setSubject("Test send on behalf2");

        EmailAddressDTO from = new EmailAddressDTO();
        from.setEmailAddress("test1@domain1.com");
        email.setFrom(from);

        //email.setBody("&lt;b&gt;updated body&lt;b&gt;");
        //email.setIsHtmlBody(true);

        EmailAddressDTO[] to = new EmailAddressDTO[2];
        EmailAddressDTO to1 = new EmailAddressDTO();
        to1.setEmailAddress("test2@domain1.com");
        EmailAddressDTO to2 = new EmailAddressDTO();
        to2.setEmailAddress("test1@domain1.com");
        to[0] = to1;
        to[1] = to2;
        email.setTo(to);

        EmailAddressDTO[] cc = new EmailAddressDTO[2];
        EmailAddressDTO cc1 = new EmailAddressDTO();
        cc1.setEmailAddress("test2@domain1.com");
        EmailAddressDTO cc2 = new EmailAddressDTO();
        cc2.setEmailAddress("test1@domain1.com");
        cc[0] = cc1;
        cc[1] = cc2;
        email.setCc(cc);


        EmailAddressDTO[] bcc = new EmailAddressDTO[2];
        EmailAddressDTO bcc1 = new EmailAddressDTO();
        bcc1.setEmailAddress("test2@domain1.com");
        EmailAddressDTO bcc2 = new EmailAddressDTO();
        bcc2.setEmailAddress("test1@domain1.com");
        bcc[0] = bcc1;
        bcc[1] = bcc2;
        email.setBcc(bcc);

        //============ send & save a copy to drafts ========
        connector.sendEmail(email, "inbox");
        //==================================================



    }


    public static void getFullEventUsingIDExample() throws ExchangeGeneralException {

    	EWSConnectorFactory factory = new EWSConnectorFactory();
    	EWSConnectorInterface connector = null;

    	connector = factory.createEWSConnector(_exchangeHost,
    			_userName,
    			_password,
    			_prefix, _useSSL, _accountName);
    	String id = "AQARAHRlc3QxQGRvbWFpbjEuY29tAVEACIjLP349JcAARgAAAt0tVj80DZpIg0I2J7Th2BwHAAM+Wb0XytNIs5QI9dxQqzQAAAM5AAAAAz5ZvRfK00izlAj13FCrNABGCrhQLAAAABA=";
    	EWSEventDTO event = connector.getEventFull(id);
    	System.out.println(event.getSubject());
    	System.out.println(event.getStartDate());
    	System.out.println(event.getEndDate());
    	System.out.println("isReminderIsSet: " + event.isReminderIsSet());
    	System.out.println("getReminderMinutesBeforeStart: " + event.getReminderMinutesBeforeStart());
    	System.out.println("event.getDescription(): " + event.getDescription());
    	System.out.println("event.isHtmlDescription(): " + event.isHtmlDescription());
    	System.out.println("Organizer: " + event.getOrganizer());
    	System.out.println("isAllDayEvent: " + event.isAllDayEvent());
    	System.out.println("getCategoriesStr: " + event.getCategoriesStr());
    	System.out.println("getOrganizer: " + event.getOrganizer());
    	System.out.println("getDateTimeCreated: " + event.getDateTimeCreated());
    	System.out.println("event.getDateTimeSent(): " + event.getDateTimeSent());

    }


    // this method can be used to retrive also the Recurrence Exceptions, just replace the type
    public static void getRecurrentOccurrencesEventsExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);

        SimpleDateFormat dateFormat = new SimpleDateFormat(
                "yyyy-MM-dd HH:mm:ss");
        Date startDate = null;
        Date endDate = null;
        try {
            startDate = dateFormat.parse("2009-01-02 06:00:00");
            endDate = dateFormat.parse("2009-01-29 23:00:00");
        } catch (ParseException ex) {
            ex.printStackTrace();
        }

        // use this method to get the recurrent events in the date range (subject filtering is currently not supported).
        ArrayList events = connector.getRecurrentEvents(startDate, endDate, 100 /*maxEntriesReturned use -1 for no limit*/,
        		/* type */ EWSEventDTO._calendarItemType_OCCURRENCE /*EWSEventDTO._calendarItemType_EXCEPTION */ );

        System.out.println("Number of Events: " + events.size() );
        for (int i = 0; i < events.size(); i++) {
        	System.out.println(((EWSEventDTO) events.get(i)).getId());
        	System.out.println(((EWSEventDTO) events.get(i)).getChangeKey());
            System.out.println(((EWSEventDTO) events.get(i)).getSubject());
            System.out.println(((EWSEventDTO) events.get(i)).isRecurrenceMasterRecord());
            System.out.println("");
            if (i == 0) {
            	EWSEventDTO eventFull = connector.getEventFull( ((EWSEventDTO) events.get(i)).getId());
            	System.out.println("=============Getting full event information (for the first event)============");
            	System.out.println(((EWSEventDTO) events.get(i)).getId());
            	System.out.println(((EWSEventDTO) events.get(i)).getChangeKey());
                System.out.println(((EWSEventDTO) events.get(i)).getSubject());
                System.out.println(((EWSEventDTO) events.get(i)).isRecurrenceMasterRecord());
            	System.out.println(eventFull.getDescription());
            	System.out.println(eventFull.getCalendarItemType());


         	    // this field is not changing even if the event occurrence is updated, it is a common value for all the recurrence series.
         		System.out.println("event.getDateTimeSent(): " + eventFull.getDateTimeSent());
            	System.out.println("=============================================================================");
            }
        }
    }





    public static void getDeletedOccurrencesExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);

        SimpleDateFormat dateFormat = new SimpleDateFormat(
                "yyyy-MM-dd HH:mm:ss");
        Date startDate = null;
        Date endDate = null;
        try {
            startDate = dateFormat.parse("2009-01-01 06:00:00");
            endDate = dateFormat.parse("2009-01-15 23:00:00");
        } catch (ParseException ex) {
            ex.printStackTrace();
        }

        // this will bring all the recurrence events masters that have in their subject "Daily recurrence"
        //ArrayList events = connector.getRecurrentEvents(startDate, endDate, "Daily recurrence");

        // use this method to get the recurrent events masters in the date range (no subject filtering).
        ArrayList events = connector.getRecurrentMastersEvents(startDate, endDate);

        System.out.println("Number of Events: " + events.size() );
        for (int i = 0; i < events.size(); i++) {
        	System.out.println(((EWSEventDTO) events.get(i)).getId());
        	System.out.println(((EWSEventDTO) events.get(i)).getChangeKey());
            System.out.println(((EWSEventDTO) events.get(i)).getSubject());
            System.out.println(((EWSEventDTO) events.get(i)).isRecurrenceMasterRecord());
            System.out.println("");
            if (((EWSEventDTO) events.get(i)).isRecurrenceMasterRecord() ) {
            	
            	try {
					ArrayList deletedOccurrences = connector.getDeletedOccurrencesUsingMasterRecord( ((EWSEventDTO) events.get(i)).getId(), ((EWSEventDTO) events.get(i)).getChangeKey());
					for (int j = 0; j < deletedOccurrences.size(); j++) {
						EWSOccurrenceDTO deletedOccurrence = (EWSOccurrenceDTO)deletedOccurrences.get(j);
						System.out.println(" Type: " + deletedOccurrence.getType());
						System.out.println(" start: " + deletedOccurrence.getStart());
					}
				} catch (ExchangeGeneralException e) {
					System.out.println("No Deleted Occurrences? " + e.getMessage());
				}
            	
            }
        }
    }


    public static void getModifiedOccurrencesUsingMasterExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);

        SimpleDateFormat dateFormat = new SimpleDateFormat(
                "yyyy-MM-dd HH:mm:ss");
        Date startDate = null;
        Date endDate = null;
        try {
            startDate = dateFormat.parse("2009-01-02 06:00:00");
            endDate = dateFormat.parse("2009-01-15 23:00:00");
        } catch (ParseException ex) {
            ex.printStackTrace();
        }

        // this will bring all the recurrence events masters that have in their subject "Daily recurrence"
        //ArrayList events = connector.getRecurrentEvents(startDate, endDate, "Daily recurrence");

        // use this method to get the recurrent events masters in the date range (no subject filtering).
        ArrayList events = connector.getRecurrentMastersEvents(startDate, endDate);

        System.out.println("Number of Events: " + events.size() );
        for (int i = 0; i < events.size(); i++) {
        	System.out.println(((EWSEventDTO) events.get(i)).getId());
        	System.out.println(((EWSEventDTO) events.get(i)).getChangeKey());
            System.out.println(((EWSEventDTO) events.get(i)).getSubject());
            System.out.println(((EWSEventDTO) events.get(i)).isRecurrenceMasterRecord());
            System.out.println("");
            if (((EWSEventDTO) events.get(i)).isRecurrenceMasterRecord() ) {
            	ArrayList modifiedOccurrences = connector.getModifiedOccurrencesUsingMasterRecord( ((EWSEventDTO) events.get(i)).getId(), ((EWSEventDTO) events.get(i)).getChangeKey());
            	for (int j = 0; j < modifiedOccurrences.size(); j++) {
            		EWSOccurrenceDTO modifiedOccurrence = (EWSOccurrenceDTO)modifiedOccurrences.get(j);
            		System.out.println(" id: " + modifiedOccurrence.getId());
            		System.out.println(" changeKey: " + modifiedOccurrence.getChangeKey());
            		System.out.println(" Type: " + modifiedOccurrence.getType());
            		System.out.println(" Start: " + modifiedOccurrence.getStart());
            	}
            }
        }
    }



    public static void getRecurrentMastersAllPropsAndUDFieldsExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);

        SimpleDateFormat dateFormat = new SimpleDateFormat(
                "yyyy-MM-dd HH:mm:ss");
        Date startDate = null;
        Date endDate = null;
        try {
            startDate = dateFormat.parse("2009-01-02 06:00:00");
            endDate = dateFormat.parse("2009-01-15 23:00:00");
        } catch (ParseException ex) {
            ex.printStackTrace();
        }

        EWSUDProp[] propNameTypeArr = {new EWSUDProp("udtest1", "String", null), new EWSUDProp("udtest2", "String", null)};
        ArrayList events = connector.getRecurrentMastersAllPropsAndUDProps(startDate, endDate, null, propNameTypeArr);

        System.out.println("Number of Events: " + events.size() );
        for (int i = 0; i < events.size(); i++) {
        	System.out.println(((EWSEventDTO) events.get(i)).getId());
        	System.out.println(((EWSEventDTO) events.get(i)).getChangeKey());
            System.out.println(((EWSEventDTO) events.get(i)).getSubject());
            System.out.println(((EWSEventDTO) events.get(i)).isRecurrenceMasterRecord());
            System.out.println(((EWSEventDTO) events.get(i)).getLocation());
            ArrayList props = ((EWSEventDTO) events.get(i)).getUDProps();
            if (props != null) {
            	for (int j = 0; j < props.size(); j++) {
            		EWSUDProp prop = (EWSUDProp)props.get(j);
            		System.out.println("prop" + j + " Name: " + prop.getName());
            		System.out.println("prop" + j + " Value: " + prop.getValue());
            	}
            }
            System.out.println("");
         }
    }


    public static void getFirstLastOccurrencesUsingMasterExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);

        SimpleDateFormat dateFormat = new SimpleDateFormat(
                "yyyy-MM-dd HH:mm:ss");
        Date startDate = null;
        Date endDate = null;
        try {
            startDate = dateFormat.parse("2009-01-02 06:00:00");
            endDate = dateFormat.parse("2009-01-15 23:00:00");
        } catch (ParseException ex) {
            ex.printStackTrace();
        }

        // this will bring all the recurrence events masters that have in their subject "Daily recurrence"
        //ArrayList events = connector.getRecurrentEvents(startDate, endDate, "Daily recurrence");

        // use this method to get the recurrent events masters in the date range (no subject filtering).
        ArrayList events = connector.getRecurrentMastersEvents(startDate, endDate);

        System.out.println("Number of Events: " + events.size() );
        for (int i = 0; i < events.size(); i++) {
        	System.out.println(((EWSEventDTO) events.get(i)).getId());
        	System.out.println(((EWSEventDTO) events.get(i)).getChangeKey());
            System.out.println(((EWSEventDTO) events.get(i)).getSubject());
            System.out.println(((EWSEventDTO) events.get(i)).isRecurrenceMasterRecord());
            System.out.println("");
            if (((EWSEventDTO) events.get(i)).isRecurrenceMasterRecord() ) {
            	ArrayList firstLastOccurrences = connector.getFirstLastOccurrencesUsingMasterRecord( ((EWSEventDTO) events.get(i)).getId(), ((EWSEventDTO) events.get(i)).getChangeKey());
            	for (int j = 0; j < firstLastOccurrences.size(); j++) {
            		EWSOccurrenceDTO firstLastOccurrence = (EWSOccurrenceDTO)firstLastOccurrences.get(j);
            		System.out.println("");
            		System.out.println(" firstLastOccurrence.getId: " + firstLastOccurrence.getId());
            		System.out.println(" firstLastOccurrence.getChangeKey: " + firstLastOccurrence.getChangeKey());
            		System.out.println(" Type: " + firstLastOccurrence.getType());
            		System.out.println(" firstLastOccurrence.getStart: " + firstLastOccurrence.getStart());
            		System.out.println(" firstLastOccurrence.getEnd: " + firstLastOccurrence.getEnd());
            		System.out.println(" firstLastOccurrence.getOriginalStart: " + firstLastOccurrence.getOriginalStart());
            	}
            }
        }
    }



    public static void getMasterUsingOccurrenceExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);

        SimpleDateFormat dateFormat = new SimpleDateFormat(
                "yyyy-MM-dd HH:mm:ss");
        Date startDate = null;
        Date endDate = null;
        try {
            startDate = dateFormat.parse("2009-01-02 06:00:00");
            endDate = dateFormat.parse("2009-01-25 23:00:00");
        } catch (ParseException ex) {
            ex.printStackTrace();
        }

        // this will bring all the recurrence events masters that have in their subject "Daily recurrence"
        //ArrayList events = connector.getRecurrentEvents(startDate, endDate, "Daily recurrence");

        // use this method to get the recurrent events occurences in the date range (no subject filtering).
        ArrayList events = connector.getRecurrentEvents(startDate, endDate, 100 /*maxEntriesReturned use -1 for no limit*/,
        		/* type */ EWSEventDTO._calendarItemType_OCCURRENCE  );

        System.out.println("Number of Events: " + events.size() );
        // get the first one
        if (events != null && events.size() > 0) {
            	EWSEventDTO event = connector.getEventFull( ((EWSEventDTO) events.get(0)).getId(), ((EWSEventDTO) events.get(0)).getChangeKey());


        }


    }

    /**
     * Example for getting the number if items in a view, it can be used to get the total number of items for paging operation.
     * @throws ExchangeGeneralException
     */
    public static void getItemsNumberExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);


        // set this xml according the Restriction xml documentation.
        // http://msdn.microsoft.com/en-us/library/aa563791(EXCHG.80).aspx
        String searchXmlStr = "<Restriction>"
            + "<t:IsGreaterThanOrEqualTo>"
            + "<t:FieldURI FieldURI=\"item:DateTimeSent\"/>"
            + "<t:FieldURIOrConstant>"
            + "<t:Constant Value=\"" +  "2009-01-05T03:42:44.701Z"
            + "\"/>"
            + "</t:FieldURIOrConstant>"
            + "</t:IsGreaterThanOrEqualTo>"
            + "</Restriction>";
        EWSSearchExpression searchExpression = new EWSSearchExpression(searchXmlStr);

        //EWSSorter sorter = new EWSSorter(EWSSorter.ORDER_ASCENDING, EWSSorter.FIELD_ORDER_ITEM_DateTimeReceived);
        //ArrayList emails = connector.getItemsIds("inbox", searchExpression, sorter);

        // without sorter
        ArrayList items = connector.getItemsIds("drafts", searchExpression, null);
        //ArrayList items = connector.getItemsIds("drafts", null, null);


        System.out.println("Number of items: " + items.size());
        //for (int i = 0; i < items.size(); i++)
        //    System.out.println(((EWSDTO) items.get(i)).getId());


    }

    /**
     * Pagination example with search expression.
     * @throws ExchangeGeneralException
     */
    public static void getEmailsWithPagingExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'hh:mm:ss.S'Z'");
        sdf.setTimeZone(TimeZone.getTimeZone("GMT+0"));
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.MONTH, 0);
        Date date = cal.getTime();

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);

        // un-commnent to change the default folder (inbox)
        connector.setFolder(ExchangeConstants.FOLDER_ENUM_drafts);

        // set this xml according the Restriction xml documentation.
        // http://msdn.microsoft.com/en-us/library/aa563791(EXCHG.80).aspx
        int pageNo = 3;
        String searchXmlStr = "<IndexedPageItemView MaxEntriesReturned=\"20\" Offset=\""
            + (pageNo - 1) * 20 + "\" BasePoint=\"Beginning\"/>"
        	+ "<Restriction>"
            + "<t:IsGreaterThanOrEqualTo>"
            + "<t:FieldURI FieldURI=\"item:DateTimeSent\"/>"
            + "<t:FieldURIOrConstant>"
            + "<t:Constant Value=\"" + /*sdf.format(date)*/ "2009-01-05T03:42:44.701Z"
            + "\"/>"
            + "</t:FieldURIOrConstant>"
            + "</t:IsGreaterThanOrEqualTo>"
            + "</Restriction>";
        EWSSearchExpression searchExpression = new EWSSearchExpression(searchXmlStr);

        EWSSorter sorter = new EWSSorter(EWSSorter.ORDER_ASCENDING, EWSSorter.FIELD_ORDER_ITEM_DateTimeReceived);

        ArrayList emails = connector.getEmailsShallow(searchExpression, sorter);

        // without sorter
        //ArrayList emails = connector.getEmailsShallow(searchExpression);

        for (int i = 0; i < emails.size(); i++) {
            System.out.println(((ExchangeEmailShallowDTO) emails.get(i)).getSubject());
            System.out.println(((ExchangeEmailShallowDTO) emails.get(i)).getTo());
            System.out.println(((ExchangeEmailShallowDTO) emails.get(i)).getCc());
            System.out.println(((ExchangeEmailShallowDTO) emails.get(i)).getDateReceived());
            System.out.println("");
        }

    }
    
    
    public static void getEmailsWithPagingExample2() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'hh:mm:ss.S'Z'");
        sdf.setTimeZone(TimeZone.getTimeZone("GMT+0"));
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.MONTH, 0);
        Date date = cal.getTime();

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);

        // un-commnent to change the default folder (inbox)
        //connector.setFolder(ExchangeConstants.FOLDER_ENUM_drafts);

        int pageNo = -1;
        int maxEntriesReturned = 3;
        for (int j = 0; j <= 3; j++) {
        	pageNo = j;
        	String searchXmlStr = "<IndexedPageItemView MaxEntriesReturned=\"" + maxEntriesReturned + "\" Offset=\""
        			+ (pageNo * maxEntriesReturned) + "\" BasePoint=\"Beginning\"/>"
        			+ "<Restriction>"
        			+ "<t:IsGreaterThanOrEqualTo>"
        			+ "<t:FieldURI FieldURI=\"item:DateTimeSent\"/>"
        			+ "<t:FieldURIOrConstant>"
        			+ "<t:Constant Value=\"" + /*sdf.format(date)*/ "2009-01-01T03:42:44.701Z"
        			+ "\"/>"
        			+ "</t:FieldURIOrConstant>"
        			+ "</t:IsGreaterThanOrEqualTo>"
        			+ "</Restriction>";
        	EWSSearchExpression searchExpression = new EWSSearchExpression(searchXmlStr);

        	EWSSorter sorter = new EWSSorter(EWSSorter.ORDER_ASCENDING, EWSSorter.FIELD_ORDER_ITEM_DateTimeReceived);

        	ArrayList emails = connector.getEmailsShallow(searchExpression, sorter);
        	System.out.println("=========== Page: " + pageNo + "========================");
        	for (int i = 0; i < emails.size(); i++) {
        		System.out.println(((ExchangeEmailShallowDTO) emails.get(i)).getSubject());
        		System.out.println(((ExchangeEmailShallowDTO) emails.get(i)).getDateReceived());
        		System.out.println("");
        	}
        }

    }


    // in case you see the event span on more then one day, please see this artical from MS:
    // http://support.microsoft.com/kb/262451
    public static void addAllDayEventExchange2010Example() throws ExchangeGeneralException {

    	System.out.println("addAllDayEventExchange2010Example");
        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);

        //connector.setUseNTLMAuthentication(false);
        SimpleDateFormat dateFormat = new SimpleDateFormat(
                "yyyy-MM-dd HH:mm:ss");
        Date startDate = null;
        Date endDate = null;
        try {
        	// The start / end date are set according to your current timezone and not selected in event.setTimezoneStr,
        	// If you want the time in the selected timezone you need to shift it accordingly.
            startDate = dateFormat.parse("2011-06-23 00:00:00");
            endDate = dateFormat.parse("2011-06-23 02:00:00");
        } catch (ParseException ex) {
            ex.printStackTrace();
        }

        System.out.println("startDate: " + startDate + " endDate: " + endDate);

        EWSEventDTO event = new EWSEventDTO();

        event.setSubject("test event");
        event.setDescription("my test event");
        event.setStartDate(startDate);
        event.setEndDate(endDate);
        event.setLocation("test location");





        // Exchange 2010sp1 and up :
        EWSGeneralConfiguration.setExchangeVersion(EWSGeneralConfiguration.EXCHANGE_VERSION_2010SP1);
        event.setTimezoneStr( EWSGeneralConfiguration.TIMEZONE_ID_ISRAEL);

        // Its also possible to set the String manually, to get your correct Timezone Id find it via regedit,  search "Eastern Standard Time", and find your timezone ID:
        //event.setTimezoneStr("Pacific Standard Time");

        //event.setTimezoneStr(EWSGeneralConfiguration.TIMEZONE_ID_EST);
        //event.setTimezoneStr(EWSGeneralConfiguration.TIMEZONE_ID_CET);
        //event.setTimezoneStr(EWSGeneralConfiguration.TIMEZONE_ID_PACIFIC);
        //event.setTimezoneStr(EWSGeneralConfiguration.TIMEZONE_ID_CENTRAL_EUROPE);
        //event.setTimezoneStr("E. Australia Standard Time");

        event.setAllDayEvent(true);


        String[] result = null;
		try {
			result = connector.createEvent(event);
			System.out.println("id: " + result[0]);
	        System.out.println("changeKey: " + result[1]);
		} catch (ExchangeGeneralException e) {
			//
			e.printStackTrace();
		}


    }



    public static void setOOFReplyExample() throws ExchangeGeneralException {


        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);

        //connector.setUseNTLMAuthentication(false);
        SimpleDateFormat dateFormat = new SimpleDateFormat(
                "yyyy-MM-dd HH:mm:ss");
        Date startDate = null;
        Date endDate = null;
        try {
            startDate = dateFormat.parse("2012-06-23 00:00:00");
            endDate = dateFormat.parse("2012-06-23 02:00:00");
        } catch (ParseException ex) {
            ex.printStackTrace();
        }

        System.out.println("startDate: " + startDate + " endDate: " + endDate);

        // set regular OOF reply
        connector.setOOFReply(null, null, "test1", "test1@domain1.com", "Internal reply", "external reply", ExchangeConstants.OOF_STATE_ENABLED);

        // set scheduled reply
        //connector.setOOFReply(startDate, endDate, "test1", "test1@domain1.com", "Internal reply", "external reply", ExchangeConstants.OOF_STATE_SCHEDULED);

        // disable OOF reply
        //connector.setOOFReply(null, null, "test1", "test1@domain1.com", "Internal reply", "external reply", ExchangeConstants.OOF_STATE_DISABLED);
    }


    public static void getEmailsFromEmailSubFolderExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);

        
        ArrayList folders = connector.getAllSubFoldersByParentFolderName(ExchangeConstants.FOLDER_ENUM_inbox, true);
        String sub_inbox_id = null;
        for (int i = 0; i < folders.size(); i++) {
            System.out.println(((EWSFolderDTO) folders.get(i)).getId());
            System.out.println(((EWSFolderDTO) folders.get(i)).getChangeKey());
            System.out.println(((EWSFolderDTO) folders.get(i)).getDisplayName());
            System.out.println("");
            if (((EWSFolderDTO) folders.get(i)).getDisplayName().equals("sub_inbox")) {
            	sub_inbox_id = ((EWSFolderDTO) folders.get(i)).getId();
            	break;
            }
        }
        connector.setFolder(sub_inbox_id);
        ArrayList emails = connector.getEmailsShallow();
        for (int i = 0; i < emails.size(); i++) {
            System.out.println(((ExchangeEmailShallowDTO) emails.get(i)).getSubject());
            System.out.println(((ExchangeEmailShallowDTO) emails.get(i)).getTo());
            System.out.println(((ExchangeEmailShallowDTO) emails.get(i)).getCc());
            System.out.println(((ExchangeEmailShallowDTO) emails.get(i)).getDateReceived());
            System.out.println("");
        }
    }

    public static void updateEventTimeZone2010sp1WithMailBoxSharingExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        // test2 access test1 mailbox (account)
        connector = factory.createEWSConnector(_exchangeHost,
                "test2",
                _password,
                _prefix, _useSSL, "test1");

        connector.setMailboxSharingType(ExchangeConstants.MAILBOX_SHARING_TYPE_ACCESS_RIGHTS);
        connector.setDomain("test.exch2k10.msg");

        String subject2update = "test event to update";
        EWSSearchExpression searchExpression = new EWSSearchExpression.Contains(EWSSearchExpression.Contains.ContainmentMode.Substring,
        		EWSSearchExpression.Contains.ContainmentComparison.IgnoreCaseAndNonSpacingCharacters,
        		EWSSearchExpression.Constants.General.Subject, subject2update);
        ArrayList events = connector.getEvents(searchExpression);
        if (events.size() > 0) {

        	EWSEventDTO event = connector.getEventFull(((EWSEventDTO)events.get(0)).getId());

        	EWSEventDTO event2update = new EWSEventDTO();
        	event2update.setId(event.getId());
        	event2update.setChangeKey(event.getChangeKey());

        	// Exchange 2010sp1 and up :
            EWSGeneralConfiguration.setExchangeVersion(EWSGeneralConfiguration.EXCHANGE_VERSION_2010SP1);
            // its possible to set the Timezone Id String manually, find it via the registry, run the regedit command, then,
            // search for "Time Zones", then find your spesific timezone, e.g "Eastern Standard Time":
            event2update.setTimezoneStr(EWSGeneralConfiguration.TIMEZONE_ID_CENTRAL_EUROPE);

        	try {
        		String[] idChangeKey = connector.updateEvent(event2update);
        		System.out.println("Id: " + idChangeKey[0] + " ChangeKey: " + idChangeKey[1]);

        	} catch (ExchangeGeneralException e) {
        		// TODO Auto-generated catch block
        		e.printStackTrace();
        	}
        }


    }


    public static void updateEventTimeZone2010sp1Example() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                _userName,
                _password,
                _prefix, _useSSL, _accountName);



        String subject2update = "test event to update";
        EWSSearchExpression searchExpression = new EWSSearchExpression.Contains(EWSSearchExpression.Contains.ContainmentMode.Substring,
        		EWSSearchExpression.Contains.ContainmentComparison.IgnoreCaseAndNonSpacingCharacters,
        		EWSSearchExpression.Constants.General.Subject, subject2update);
        ArrayList events = connector.getEvents(searchExpression);
        if (events.size() > 0) {

        	EWSEventDTO event = connector.getEventFull(((EWSEventDTO)events.get(0)).getId());

        	EWSEventDTO event2update = new EWSEventDTO();
        	event2update.setId(event.getId());
        	event2update.setChangeKey(event.getChangeKey());

        	// Exchange 2010sp1 and up :
            EWSGeneralConfiguration.setExchangeVersion(EWSGeneralConfiguration.EXCHANGE_VERSION_2010SP1);
            // its possible to set the Timezone Id String manually, find it via the registry, run the regedit command, then,
            // search for "Time Zones", then find your spesific timezone, e.g "Eastern Standard Time":
            event2update.setTimezoneStr(EWSGeneralConfiguration.TIMEZONE_ID_CANADA_CENTRAL);

        	try {
        		String[] idChangeKey = connector.updateEvent(event2update);
        		System.out.println("Id: " + idChangeKey[0] + " ChangeKey: " + idChangeKey[1]);

        	} catch (ExchangeGeneralException e) {
        		// TODO Auto-generated catch block
        		e.printStackTrace();
        	}
        }


    }


    public static void getRecurrentMastersAllPropsAndUDFieldsFromUserDefinedCalendarExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);

        ArrayList folders = connector.getAllFolders();
        String calendarFolderId = null;
        for (int i = 0; i < folders.size(); i++) {

        	String displayName = ((EWSFolderDTO) folders.get(i)).getDisplayName();
        	if (displayName.equals("myCalendar")) {
        		calendarFolderId = ((EWSFolderDTO) folders.get(i)).getId();
        	}
        }


        connector.setFolder(calendarFolderId);


        SimpleDateFormat dateFormat = new SimpleDateFormat(
                "yyyy-MM-dd HH:mm:ss");
        Date startDate = null;
        Date endDate = null;
        try {
            startDate = dateFormat.parse("2009-01-02 06:00:00");
            endDate = dateFormat.parse("2009-01-15 23:00:00");
        } catch (ParseException ex) {
            ex.printStackTrace();
        }

        EWSUDProp[] propNameTypeArr = {new EWSUDProp("udtest1", "String", null), new EWSUDProp("udtest2", "String", null)};
        ArrayList events = connector.getRecurrentMastersAllPropsAndUDProps(startDate, endDate, null, propNameTypeArr);

        System.out.println("Number of Events: " + events.size() );
        for (int i = 0; i < events.size(); i++) {
        	System.out.println(((EWSEventDTO) events.get(i)).getId());
        	System.out.println(((EWSEventDTO) events.get(i)).getChangeKey());
            System.out.println(((EWSEventDTO) events.get(i)).getSubject());
            System.out.println(((EWSEventDTO) events.get(i)).isRecurrenceMasterRecord());
            System.out.println(((EWSEventDTO) events.get(i)).getLocation());
            ArrayList props = ((EWSEventDTO) events.get(i)).getUDProps();
            if (props != null) {
            	for (int j = 0; j < props.size(); j++) {
            		EWSUDProp prop = (EWSUDProp)props.get(j);
            		System.out.println("prop" + j + " Name: " + prop.getName());
            		System.out.println("prop" + j + " Value: " + prop.getValue());
            	}
            }
            System.out.println("");
         }
    }


    public static void convertEmailIdToOwaIdExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);

        // un-commnent to change the default folder (inbox)
        connector.setFolder(ExchangeConstants.FOLDER_ENUM_drafts);
        connector.setDomain(_domain);

        ArrayList emails = connector.getEmailsShallow();
        if (emails.size() > 0) {
        	System.out.println(((ExchangeEmailShallowDTO) emails.get(0)).getId());
            System.out.println(((ExchangeEmailShallowDTO) emails.get(0)).getSubject());
            System.out.println("");
            String OwaId = connector.ConvertId(((ExchangeEmailShallowDTO) emails.get(0)).getId(), "OwaId");
            System.out.println("OwaId: " + OwaId);
        }

    }


    public static void getExchangeVersionExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);

        EWSExchangeVersionDTO version = connector.getExchangeVersion();
        System.out.println("version: " + version.getVersion());

    }

    public static void settingPrivateKeyStrorePasswordExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();

        // you can load it from any location you want, you can also set its location via JVM flag:
        // -Djavax.net.ssl.trustStore=.\lib\privkeystore
        //factory.setPrivkeystoreFullPath("c:/temp/privkeystore");

        factory.setPrivkeystorePassword("foobar2");
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);

        ArrayList contacts = connector.getContacts();
        System.out.println("");

    }


    public static void getFullEventsExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);

        SimpleDateFormat dateFormat = new SimpleDateFormat(
                "yyyy-MM-dd HH:mm:ss");
        Date startDate = null;
        Date endDate = null;
        try {
        	startDate = dateFormat.parse("2009-01-01 06:00:00");
            endDate = dateFormat.parse("2009-01-02 23:00:00");
        } catch (ParseException ex) {
            ex.printStackTrace();
        }

        ArrayList events = connector.getEvents(startDate, endDate);

        // creating the ids array for the full events retrival
        EWSDTO[] ids = new EWSDTO[2];
        ids[0] = new EWSDTO();
        ids[1] = new EWSDTO();
        if (events.size() >= 2) {
        	ids[0].setId(((EWSEventDTO)events.get(0)).getId());
        	ids[0].setChangeKey(((EWSEventDTO)events.get(0)).getChangeKey());

        	ids[1].setId(((EWSEventDTO)events.get(1)).getId());
        	ids[1].setChangeKey(((EWSEventDTO)events.get(1)).getChangeKey());
        	
        	 ArrayList fullEvents = connector.getEventsFull(ids);
             for (int i = 0; i < fullEvents.size(); i++) {
             	EWSEventDTO fullEvent = (EWSEventDTO) fullEvents.get(i);
             	System.out.println(fullEvent.getId());
             	System.out.println(fullEvent.getChangeKey());
                 System.out.println(fullEvent.getSubject());
                 if (fullEvent.getAttachments() != null) {
         			for (int j = 0 ; j < fullEvent.getAttachments().length; j++ ) {
         				String attachmentId = fullEvent.getAttachments()[j].getId();
         				String attachmentName = fullEvent.getAttachments()[j].getName();
         				System.out.println("  attachmentName: " + attachmentName);
         				System.out.println("  attachmentId: " + attachmentId);
         			}
                 }

                 System.out.println("");
        }

       
        }

    }


    public static void isItemExistExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);

        SimpleDateFormat dateFormat = new SimpleDateFormat(
                "yyyy-MM-dd HH:mm:ss");
        Date startDate = null;
        Date endDate = null;
        try {
        	startDate = dateFormat.parse("2009-01-01 06:00:00");
            endDate = dateFormat.parse("2009-01-02 23:00:00");
        } catch (ParseException ex) {
            ex.printStackTrace();
        }

        ArrayList events = connector.getEvents(startDate, endDate);
        if (events.size() > 0) {
        	EWSEventDTO event = (EWSEventDTO)events.get(0);
        	boolean isExists = connector.isItemExists(event.getId(), event.getChangeKey());
        	System.out.print("Item exists: "  + isExists);
        }
    }


    public static void notifications2CallsExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);

        // setting the folder using named folder
        connector.setFolder(ExchangeConstants.FOLDER_ENUM_calendar);

        EWSNotificationsSubscriptionDTO notificationsSubscriptionDTO = connector.pullSubscriptionRequest(EWSNotificationsSubscriptionDTO.EVENT_TYPE_CreatedEvent, 10);
        System.out.println("notificationsSubscriptionDTO.getSubscriptionId(): " + notificationsSubscriptionDTO.getSubscriptionId());
        System.out.println("notificationsSubscriptionDTO.getWatermark(): " + notificationsSubscriptionDTO.getWatermark());


        /// create event to test the notification.
        SimpleDateFormat dateFormat = new SimpleDateFormat(
        "yyyy-MM-dd HH:mm:ss");
        Date startDate = null;
        Date endDate = null;
        try {
        	startDate = dateFormat.parse("2009-01-11 11:00:00");
        	endDate = dateFormat.parse("2009-01-11 12:00:00");
        } catch (ParseException ex) {
        	ex.printStackTrace();
        }

        EWSEventDTO event = new EWSEventDTO();

        event.setSubject("test event (for notification)");
        event.setStartDate(startDate);
        event.setEndDate(endDate);

        String[] result = null;
        result = connector.createEvent(event);
        System.out.println("id: " + result[0]);
        System.out.println("changeKey: " + result[1]);
        // sleep till the calendar meeting is created.
        try {
        	Thread.sleep(5000);
        } catch (InterruptedException e) {
        	//
        	e.printStackTrace();
        }
        ////////////////////////////////////////////////


        ArrayList notifications = connector.getNotificationEvents(notificationsSubscriptionDTO);

        if (notifications.size() > 1) {
        	System.out.println("================== First Call:");
        	System.out.println("notifications.size(): " + notifications.size());
        	EWSNotificationEventDTO notification = (EWSNotificationEventDTO)notifications.get(1);
        	System.out.println("notification.getNotificationType(): " + notification.getNotificationType());
        	System.out.println("notification.getItemId(): " + notification.getItemId());
        	System.out.println("notification.getItemChangeKey(): " + notification.getItemChangeKey());
        	System.out.println("notification.getTimeStamp(): " + notification.getTimeStamp());
        	System.out.println("notification.getWatermark(): " + notification.getWatermark());
        	System.out.println("notification.getParentFolderId(): " + notification.getParentFolderId());
        	System.out.println("notification.getParentFolderChangeKey(): " + notification.getParentFolderChangeKey());

        	// getting the new calendar event
        	if (notification.getItemId() != null) {
        		EWSEventDTO newCalendarEvent = connector.getEventFull(notification.getItemId());
        		if (newCalendarEvent != null)
        			System.out.println("newCalendarEvent.getSubject(): " + newCalendarEvent.getSubject());
        	}

        	// last notification
        	EWSNotificationEventDTO lastNotification = (EWSNotificationEventDTO)notifications.get(notifications.size() - 1);
        	// setting the watermark for the next call
        	notificationsSubscriptionDTO.setWatermark(lastNotification.getWatermark());


        	event.setSubject("test event2 (for notification)");
            event.setStartDate(startDate);
            event.setEndDate(endDate);

            result = null;
            result = connector.createEvent(event);
            System.out.println("id: " + result[0]);
            System.out.println("changeKey: " + result[1]);
            // sleep till the calendar meeting is created.
            try {Thread.sleep(5000);} catch (InterruptedException e) {}


        	// second call with the new watermark
        	notifications = connector.getNotificationEvents(notificationsSubscriptionDTO);
        	System.out.println("Second call notifications size: " + notifications.size());
        	for (int i = 0; i < notifications.size(); i++ ) {
        		notification = (EWSNotificationEventDTO)notifications.get(i);
            	System.out.println("notification.getNotificationType(): " + notification.getNotificationType());
            	System.out.println("notification.getItemId(): " + notification.getItemId());
            	System.out.println("notification.getItemChangeKey(): " + notification.getItemChangeKey());
            	System.out.println("notification.getTimeStamp(): " + notification.getTimeStamp());
            	System.out.println("notification.getWatermark(): " + notification.getWatermark());
            	System.out.println("notification.getParentFolderId(): " + notification.getParentFolderId());
            	System.out.println("notification.getParentFolderChangeKey(): " + notification.getParentFolderChangeKey());

            	// getting the new calendar event

            	if (notification.getItemId() != null) {
            		EWSEventDTO newCalendarEvent = null;
					try {
						newCalendarEvent = connector.getEventFull(notification
								.getItemId());
					} catch (jec.ItemNotFoundException e) {
						System.out.println("Item: " + i + " not found");
					}
            		if (newCalendarEvent != null)
            			System.out.println("newCalendarEvent.getSubject(): " + newCalendarEvent.getSubject());
            	}
        	}

        }
        else {
        	System.out.println("Didn't find the notification");
        }



        // remove the subscription
        connector.unSubscriptionRequest(notificationsSubscriptionDTO);

    }


    /**
     * You will need to add "send mail on behalf" the group permission to the specified sending account (_accountName).
     * @throws ExchangeGeneralException
     */
    public static void sendEmailFromGroupExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;
        connector = factory.createEWSConnector(_exchangeHost,
                _userName,
                _password,
                _prefix, _useSSL, _accountName);

        EWSEmailDTO email = new EWSEmailDTO();
        email.setSubject("create email example3");
        //email.setBody("example body");

        email.setBody("test body");
        email.setIsHtmlBody(false);

        EmailAddressDTO[] to = new EmailAddressDTO[2];
        EmailAddressDTO to1 = new EmailAddressDTO();
        to1.setEmailAddress("test2@domain1.com");
        EmailAddressDTO to2 = new EmailAddressDTO();
        to2.setEmailAddress("test1@domain1.com");
        to[0] = to1;
        to[1] = to2;
        email.setTo(to);

        EmailAddressDTO[] cc = new EmailAddressDTO[2];
        EmailAddressDTO cc1 = new EmailAddressDTO();
        cc1.setEmailAddress("test2@domain1.com");
        EmailAddressDTO cc2 = new EmailAddressDTO();
        cc2.setEmailAddress("test1@domain1.com");
        cc[0] = cc1;
        cc[1] = cc2;
        email.setCc(cc);


        EmailAddressDTO[] bcc = new EmailAddressDTO[2];
        EmailAddressDTO bcc1 = new EmailAddressDTO();
        bcc1.setEmailAddress("test2@domain1.com");
        EmailAddressDTO bcc2 = new EmailAddressDTO();
        bcc2.setEmailAddress("test1@domain1.com");
        bcc[0] = bcc1;
        bcc[1] = bcc2;
        email.setBcc(bcc);

        // its possible to set set the from as a group
        EmailAddressDTO from = new EmailAddressDTO();
        from.setEmailAddress("group@domain1.com");
        email.setFrom(from);
        connector.sendEmail(email);
    }


    public static void getOofReplayExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;
        connector = factory.createEWSConnector(_exchangeHost,
                _userName,
                _password,
                _prefix, _useSSL, _accountName);
        EWSOofDTO oofreply =  connector.getOOFReply("test1@domain1.com");
        System.out.println(oofreply);
    }

    public static void replyOrForwardEmailExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);
        
        // drafts folder
        connector.setFolder(ExchangeConstants.FOLDER_ENUM_drafts);

        ArrayList emails = connector.getEmailsShallow();
        ExchangeEmailShallowDTO email = (ExchangeEmailShallowDTO)emails.get(0);
        System.out.println(email.getId());
        System.out.println(email.getChangeKey());
        System.out.println(email.getSubject());
        System.out.println(email.getTo());
        System.out.println(email.getCc());

        EmailAddressDTO[] to = new EmailAddressDTO[2];
        EmailAddressDTO to1 = new EmailAddressDTO();
        to1.setEmailAddress("test2@domain1.com");
        EmailAddressDTO to2 = new EmailAddressDTO();
        to2.setEmailAddress("test1@domain1.com");
        to[0] = to1;
        to[1] = to2;

        EmailAddressDTO[] cc = new EmailAddressDTO[2];
        EmailAddressDTO cc1 = new EmailAddressDTO();
        cc1.setEmailAddress("test2@domain1.com");
        EmailAddressDTO cc2 = new EmailAddressDTO();
        cc2.setEmailAddress("test1@domain1.com");
        cc[0] = cc1;
        cc[1] = cc2;


        EWSEmailDTO reply = new EWSEmailDTO();
        reply.setId(email.getId());
        reply.setChangeKey(email.getChangeKey());
        reply.setTo(to);
        //reply.setBody("This is body");
        reply.setNewBodyContent("This is the reply body");

        EWSEmailDTO replyall = new EWSEmailDTO();
        replyall.setId(email.getId());
        replyall.setChangeKey(email.getChangeKey());
        //replyall.setTo(to);
        //reply.setBody("This is body");
        replyall.setNewBodyContent("This is the reply all body");

        EWSEmailDTO forward = new EWSEmailDTO();
        forward.setId(email.getId());
        forward.setChangeKey(email.getChangeKey());
        forward.setTo(to);
        forward.setCc(cc);
        forward.setNewBodyContent("This is the forward body");
        forward.setSubject("fw: new subject");

        //connector.replyOrForwardEmail(reply, "sentitems", EWSEmailDTO.OPERATION_reply);

        // in case of reply all the to
        //connector.replyOrForwardEmail(replyall, "sentitems", EWSEmailDTO.OPERATION_replyAll);

        connector.replyOrForwardEmail(forward, "sentitems", EWSEmailDTO.OPERATION_forward);

    }

    // This example shows how to use http session persistance.
    // this will speedup the connector operation in case of multiply operations on the same Exchange server.
    // This will greatly speed-up MS 365 service operations.
    public static void addEventWithSessionPersistanceExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        EWSGeneralConfiguration.setPersistHttpSession(true);

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);


        SimpleDateFormat dateFormat = new SimpleDateFormat(
                "yyyy-MM-dd HH:mm:ss");
        Date startDate = null;
        Date endDate = null;
        try {
            startDate = dateFormat.parse("2012-06-13 11:00:00");
            endDate = dateFormat.parse("2012-06-13 12:00:00");
        } catch (ParseException ex) {
            ex.printStackTrace();
        }

        EWSEventDTO event = new EWSEventDTO();

        event.setSubject("test event");
        event.setDescription("my test event");
        event.setStartDate(startDate);
        event.setEndDate(endDate);
        event.setLocation("test location");

        String[] result = null;
		try {
			result = connector.createEvent(event);
			System.out.println("id: " + result[0]);
	        System.out.println("changeKey: " + result[1]);

	        result = connector.createEvent(event);
			System.out.println("id: " + result[0]);
	        System.out.println("changeKey: " + result[1]);
		} catch (ExchangeGeneralException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


    }
    
    // This can work also on contacts tasks or emails
    public static void deleteEventAttachmentExample() throws ExchangeGeneralException {

    	 EWSConnectorFactory factory = new EWSConnectorFactory();
         EWSConnectorInterface connector = null;

         connector = factory.createEWSConnector(_exchangeHost,
                                                _userName,
                                                _password,
                                                _prefix, _useSSL, _accountName);

         SimpleDateFormat dateFormat = new SimpleDateFormat(
                 "yyyy-MM-dd HH:mm:ss");
         Date startDate = null;
         Date endDate = null;
         try {
         	startDate = dateFormat.parse("2009-01-01 06:00:00");
             endDate = dateFormat.parse("2009-01-01 23:00:00");
         } catch (ParseException ex) {
             ex.printStackTrace();
         }

         ArrayList events = connector.getEvents(startDate, endDate);
         System.out.print("Num of events:" + events.size());
         if (events.size() > 0) {
         	for (int i = 0; i < events.size(); i++) {
         		String id = ((EWSEventDTO)events.get(i)).getId();
         		String changeKey = ((EWSEventDTO)events.get(i)).getChangeKey();
         		System.out.println("===== Getting EventFull for Id: " + id + " changeKey:" + changeKey +" =====");

         		EWSEventDTO event = connector.getEventFull(id, changeKey);
         		
         		System.out.println(event.getSubject());
         		

         		//////////////////////////////getting event attachments ///////////////////////////
         		if (((EWSEventDTO) event).getAttachments() != null) {
         			System.out.println("Event contains attachments");
         			for (int j=0 ; j < ((EWSEventDTO) event).getAttachments().length; j++ ) {
         				String attachmentId = ((EWSEventDTO) event).getAttachments()[j].getId();
         				String attachmentName = ((EWSEventDTO) event).getAttachments()[j].getName();
         				System.out.println("attachmentId: " + attachmentId);
         				System.out.println("attachmentName: " + attachmentName);
         				System.out.println("contentType: " + ((EWSEventDTO) event).getAttachments()[j].getContentType());
         				System.out.println("");
         				System.out.println("");

         				// for this example we delete the first attachment
         				if (j == 0) {
         					
         					try {
								connector.deleteAttachment(attachmentId);
								System.out.println("============ Deleted event attachment: " + attachmentName );
							} catch (Exception e) {
								System.out.println("============ Failed to delete event attachment: " + attachmentName + "reason: " +  e.getMessage() );
							}
         				}
         			}
         		}
 
         	}
         }
    }
    
    public static void exchangeServiceCustomPostFixExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        EWSGeneralConfiguration.setExchangeVersion(EWSGeneralConfiguration.EXCHANGE_VERSION_2010SP1);
        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);
        
        //EWSGeneralConfiguration.setEXCHANGE_URL_POSTFIX("ews/Exchange.asmx");
        EWSGeneralConfiguration.setEXCHANGE_URL_POSTFIX("ews/Services.wsdl");
        
        
        ArrayList emailIds = connector.getEmailIds(null, null);
        for (int i = 0; i < emailIds.size(); i++) {
        	System.out.println(((EWSDTO) emailIds.get(i)).getId());
        	System.out.println(((EWSDTO) emailIds.get(i)).getChangeKey());

            System.out.println("");
        }

    }
    
    // move the privkeystore file from the lib directory to the ewsj.jar root.
    // ewsj.jar must be in the classpath
    public static void runWithKeyStoreInJarExample() throws ExchangeGeneralException {

    	EWSGeneralConfiguration.setPrivateKeyStoreInJar(true);
     	EWSConnectorFactory factory = new EWSConnectorFactory();
    	
        EWSConnectorInterface connector = null;
 
        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);

       
        ArrayList contacts = connector.getContacts();
        
        System.out.println(contacts.size());
        //EWSGeneralConfiguration.setPrivateKeyStoreInJar(false);	
        

    }
    
    
    public static void expandDLExample() throws ExchangeGeneralException {

    	System.out.println("expandDistributionListExample");
        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);
 
        ArrayList mailBoxes = null;
		mailBoxes = connector.expandDLUsingEmail("test_dl@NetCompsLTD3.onmicrosoft.com");
		
         // ArrayList mailBoxes = connector.expandDLUsingId(id, changeKey);
        
        
        
        for (int i = 0; i < mailBoxes.size(); i++) {
        	EWSMailBoxDTO mailBox = (EWSMailBoxDTO)mailBoxes.get(i);
        	System.out.println("mailBox.getName(): " + mailBox.getName());
        	System.out.println("mailBox.getEmailAddress(): " + mailBox.getEmailAddress());
        	System.out.println("mailBox.getRoutingType(): " + mailBox.getRoutingType());
        	System.out.println("mailBox.getMailboxType(): " + mailBox.getMailboxType());
        }
    }
    
    
    public static void sendEmail365Example() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;
        connector = factory.createEWSConnector(_exchangeHost,
                _userName,
                _password,
                _prefix, _useSSL, _accountName);

        EWSEmailDTO email = new EWSEmailDTO();
        email.setSubject("example categories subject");
        //email.setBody("example body");


        email.setBody("&lt;b&gt;updated body&lt;b&gt;");
        email.setIsHtmlBody(true);

        
        
        // works on Exchange 2010 and up
        //email.setReplyTo("<t:ReplyTo><t:Mailbox><t:EmailAddress>test@test.com</t:EmailAddress></t:Mailbox></t:ReplyTo>");

        EmailAddressDTO[] to = new EmailAddressDTO[2];
        EmailAddressDTO to1 = new EmailAddressDTO();
        to1.setEmailAddress("aaron.hedly@netcompss6.onmicrosoft.com");
        EmailAddressDTO to2 = new EmailAddressDTO();
        to2.setEmailAddress("aaron.hedly@netcompss6.onmicrosoft.com");
        to[0] = to1;
        to[1] = to2;
        email.setTo(to);

        EmailAddressDTO[] cc = new EmailAddressDTO[2];
        EmailAddressDTO cc1 = new EmailAddressDTO();
        cc1.setEmailAddress("aaron.hedly@netcompss6.onmicrosoft.com");
        EmailAddressDTO cc2 = new EmailAddressDTO();
        cc2.setEmailAddress("aaron.hedly@netcompss6.onmicrosoft.com");
        cc[0] = cc1;
        cc[1] = cc2;
        email.setCc(cc);


        

        //============ send & save a copy to drafts ========
        //connector.sendEmail(email);
        //==================================================



        //====== sends and save a copy to "Sent Items" =========
        connector.sendEmail(email, ExchangeConstants.FOLDER_ENUM_sentitems);
        //======================================================


    }
    
    
    
    public static void sendEmailWithAttachments365Example() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;
        connector = factory.createEWSConnector(_exchangeHost,
                _userName,
                _password,
                _prefix, _useSSL, _accountName);

        EWSEmailDTO email = new EWSEmailDTO();
        email.setSubject("example subject");
        email.setBody("example body");

        EmailAddressDTO[] to = new EmailAddressDTO[2];
        EmailAddressDTO to1 = new EmailAddressDTO();
        to1.setEmailAddress("aaron.hedly@netcompss6.onmicrosoft.com");
        EmailAddressDTO to2 = new EmailAddressDTO();
        to2.setEmailAddress("aaron.hedly@netcompss6.onmicrosoft.com");
        to[0] = to1;
        to[1] = to2;
        email.setTo(to);

        EmailAddressDTO[] cc = new EmailAddressDTO[2];
        EmailAddressDTO cc1 = new EmailAddressDTO();
        cc1.setEmailAddress("aaron.hedly@netcompss6.onmicrosoft.com");
        EmailAddressDTO cc2 = new EmailAddressDTO();
        cc2.setEmailAddress("aaron.hedly@netcompss6.onmicrosoft.com");
        cc[0] = cc1;
        cc[1] = cc2;
        email.setCc(cc);


        /////////// add attachments ///////////////////////////////////

        AttachmentDTO attach1 = new AttachmentDTO();
        attach1.setName("attachment 1.png");


        AttachmentDTO attach2 = new AttachmentDTO();
        attach2.setName("attachment 2.png");
        byte[] filebuffer = null;
		try {
			FileInputStream fis = new FileInputStream("c:/temp/1.png");
			int size = fis.available();
			filebuffer = new byte[size];
			fis.read(filebuffer);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
        attach1.setByteData(filebuffer);
        attach2.setByteData(filebuffer);

        AttachmentDTO[] attachArr = new AttachmentDTO[2];
        attachArr[0] = attach1;
        attachArr[1] = attach2;
        email.setAttachments(attachArr);
        ////////////////////////////////////////////////////////////////



        //============ send & save a copy to sentItems ========
        connector.sendEmail(email, ExchangeConstants.FOLDER_ENUM_sentitems);
        //==================================================


    }


    
    public static void proxyExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;


        EWSGeneralConfiguration.setProxyHost("127.0.0.1");
        EWSGeneralConfiguration.setProxyPort(8080);
        
        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);
        
        SimpleDateFormat dateFormat = new SimpleDateFormat(
                "yyyy-MM-dd HH:mm:ss");
        Date startDate = null;
        Date endDate = null;
        try {
            startDate = dateFormat.parse("2016-02-20 06:00:00");
            endDate = dateFormat.parse("2016-02-22 23:00:00");
        } catch (ParseException ex) {
            ex.printStackTrace();
        }

        ArrayList events = connector.getEvents(startDate, endDate);
        System.out.println("Number of Events: " + events.size() );
        for (int i = 0; i < events.size(); i++) {
        	System.out.println(((EWSEventDTO) events.get(i)).getId());
        	System.out.println(((EWSEventDTO) events.get(i)).getChangeKey());
            System.out.println(((EWSEventDTO) events.get(i)).getSubject());
        }

        /*
        ArrayList contacts = connector.getContacts();
        for (int i = 0; i < contacts.size(); i++) {
        	System.out.println(((EWSContactShallowDTO) contacts.get(i)).getId());
        	System.out.println(((EWSContactShallowDTO) contacts.get(i)).getChangeKey());
            System.out.println(((EWSContactShallowDTO) contacts.get(i)).getFirstName());
            System.out.println(((EWSContactShallowDTO) contacts.get(i)).getSurname());
            System.out.println("");
        }
        */
        
        // reseting the proxy host to null (the next run it will not use proxy)
        EWSGeneralConfiguration.setProxyHost(null);

    }




}

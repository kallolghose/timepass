//import java.io.BufferedReader;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.TimeZone;

import jec.EWSConnectorFactory;
import jec.EWSSearchExpression;
import jec.ExchangeConstants;
import jec.ExchangeGeneralException;
import jec.dto.EWSEventDTO;
import jec.EWSConnectorInterface;

import java.util.Date;
import java.text.SimpleDateFormat;
import java.text.ParseException;

import jec.dto.AttachmentDTO;
import jec.dto.AttachmentInfoDTO;
import jec.dto.EWSContactDTO;
import jec.dto.EWSContactShallowDTO;
import jec.dto.EWSDTO;
import jec.dto.EWSEmailDTO;
import jec.dto.EWSFolderDTO;
import jec.dto.EWSGeneralConfiguration;
import jec.dto.EWSRecurrence;
import jec.dto.EWSSorter;
import jec.dto.EWSTaskShallowDTO;
import jec.dto.EWSUpdateEventConfiguration;
import jec.dto.EmailAddressDTO;
import jec.dto.ExchangeAddressDTO;
import jec.dto.EWSTaskDTO;
import jec.dto.ExchangeEmailDTO;
import jec.dto.ExchangeEmailShallowDTO;
import jec.dto.ExchangeEventAttendeeDTO;
import jec.utils.AppLogger;


public class KerioExamples {

    //=============================================================

	    static String _exchangeHost = "kerio.host.com";
	    static String _userName = "test@testdomain.dk";
	    static String _password = "xxxxxx";
	    static String _prefix = "Exchange";
	    static String _accountName = "test@testdomain.dk";
	    static String _domain = "testdomain.dk";
	    static boolean _useSSL = true;
	    static String _email = "test1@domain1.com";

    // =============================================================


    public static void main(String[] args) {
        try {
            BufferedReader in = new BufferedReader(new InputStreamReader(System.
                    in));
            String str = null;
            System.out.println("Welcome to EWSJ example!");
            System.out.println(
                    "To use the main default values just press <Enter>");
            System.out.println("");
            System.out.println("Please insert Exchange IP or host name: ");
            try {
                str = in.readLine();
            } catch (IOException ex1) {
                ex1.printStackTrace();
            }
            if ((str != null) && (!str.equals("")))
                _exchangeHost = str;
            System.out.println("Exchange Host:" + _exchangeHost);
            System.out.println("");

            System.out.println("Please insert Exchange user name: ");
            try {
                str = in.readLine();
            } catch (IOException ex1) {
                ex1.printStackTrace();
            }
            if ((str != null) && (!str.equals("")))
                _userName = str;
            System.out.println("");
            System.out.println("Application User Account Name:" +
                               _userName);

            System.out.print("Please insert Exchange password: ");
            try {
                str = in.readLine();
            } catch (IOException ex1) {
                ex1.printStackTrace();
            }
            if ((str != null) && (!str.equals("")))
                _password = str;
            System.out.println("");
            System.out.println("Application User Password:" +
                               _password);

            System.out.print(
                    "Please insert mailbox name (in most cases its the same as the user name): ");
            try {
                str = in.readLine();
            } catch (IOException ex1) {
                ex1.printStackTrace();
            }
            if ((str != null) && (!str.equals("")))
                _accountName = str;
            System.out.println("");
            System.out.println("Mailbox Name:" + _accountName);

            System.out.print(
                    "If your exchange is configured to use SSL/HTTPS write true, if not write false:");
            try {
                str = in.readLine();
            } catch (IOException ex1) {
                ex1.printStackTrace();
            }
            if ((str != null) && (!str.equals(""))) {
                if ((str.equals("true") || str.equals("True"))) {
                    _useSSL = true;
                } else if ((str.equals("false") || str.equals("False"))) {
                    _useSSL = false;
                }
            }
            System.out.println("");
            System.out.println("useSSL:" + _useSSL);

            //=========================================================================
 
            //TODO
            // verified on Kerio
            
            createContactExample();
            getContactsAndGetFullContactKerioExample();
            getPublicContactsExample();
            updateContactExample();
            deleteContactExample();
            
            createFolderExample();
            getAllFoldersExample();

            allBasicTaskOperationsExample();
            getTasksAndFullTaskExample();
            
            getEventsAndFullEventExample();
            addEventExample();
            updateEventExample();
            
            deleteItemExample();
            createEmailExample();
            getEmailsExample();
            
            getContactsFromUserDefinedFolderExample();
            resolveNameExample();

            //=========================================================================

        } catch (ExchangeGeneralException ex) {
            ex.printStackTrace();
        }
    }



    public static void createContactExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);
        EWSContactDTO contact = new EWSContactDTO();

        contact.setFileAs("FileAs5");
        contact.setFirstName("First5");
        contact.setSurname("Last5");


        contact.setMiddleName("Middle");
        contact.setJobTitle("jobTitle");
        contact.setCompanyName("company");

        contact.setEmailAddress1("test_email1@domain1.com");
        contact.setEmailAddress2("test_email2@domain1.com");
        contact.setEmailAddress3("test_email3@domain1.com");

        contact.setBusinessPhone("test telBusiness");
        contact.setHomePhone("telHome");
        contact.setMobilePhone("Mobile phone");
        contact.setHomePhone2("telHome2");
        contact.setBusinessPhone2("telBusiness2");
        contact.setBusinessFax("business fax");
        contact.setHomeFax("homeFax");
        contact.setImAddress1("test imAddress1");
        contact.setImAddress2("test imAddress2");
        contact.setImAddress3("test imAddress3");


        ExchangeAddressDTO businessAddress = new ExchangeAddressDTO();
        businessAddress.setStreet("test bu street");
        businessAddress.setCity("test bu city");
        businessAddress.setCountryOrRegion("test bu country");
        // province or state
        businessAddress.setProvinceOrState("test bu province or state");
        businessAddress.setPostcode("bu postcode");
        contact.setBusinessAddress(businessAddress);

        ExchangeAddressDTO homeAddress = new ExchangeAddressDTO();
        homeAddress.setStreet("test ho street");
        homeAddress.setCity("test ho city");
        homeAddress.setCountryOrRegion("test ho country");
        homeAddress.setProvinceOrState("test ho province or state");
        homeAddress.setPostcode("ho postcode");
        contact.setHomeAddress(homeAddress);

        ExchangeAddressDTO otherAddress = new ExchangeAddressDTO();
        otherAddress.setStreet("test ot street");
        otherAddress.setCity("test ot city");
        otherAddress.setCountryOrRegion("test ot country");
        otherAddress.setProvinceOrState("test ot province or state");
        otherAddress.setPostcode("ot postcode");
        contact.setOtherAddress(otherAddress);




        String[] IdAndChangeKey = connector.createContact(contact);


    }



    public static void getContactsAndGetFullContactKerioExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);


        EWSGeneralConfiguration.setServerType(EWSGeneralConfiguration.SERVER_TYPE_KERIO);
        int pageNo = 1;
        String searchXmlStr ="<IndexedPageItemView MaxEntriesReturned=\"20\" Offset=\""
            + (pageNo - 1) * 20 + "\" BasePoint=\"Beginning\"/>";

        EWSSearchExpression searchExpression = new EWSSearchExpression(searchXmlStr);

        // this is the only sorter allowed for Kerio
        EWSSorter sorter = new EWSSorter(EWSSorter.ORDER_ASCENDING, EWSSorter.FIELD_ORDER_ITEM_DateTimeReceived);

        ArrayList contacts = connector.getContacts(searchExpression, sorter);

        // getting the first one
        if (contacts.size() > 0) {
        	String id = ((EWSContactShallowDTO) contacts.get(0)).getId();
        	System.out.println("id: " + id);
        	System.out.println("ChangeKey: " + ((EWSContactShallowDTO) contacts.get(0)).getChangeKey());

        	  // only changeKey id and type are supported with shalow request for Kerio
//            System.out.println(((EWSContactShallowDTO) contacts.get(i)).getFirstName());
//            System.out.println(((EWSContactShallowDTO) contacts.get(i)).getSurname());
//            System.out.println(((EWSContactShallowDTO) contacts.get(i)).getEmailAddress1());
//            System.out.println(((EWSContactShallowDTO) contacts.get(i)).getBusinessPhone());
//            System.out.println(((EWSContactShallowDTO) contacts.get(i)).getHomePhone());
//            System.out.println(((EWSContactShallowDTO) contacts.get(i)).getMobilePhone());

        	EWSContactDTO contact =  connector.getFullContact(id);
        	System.out.println("contact.getId(): " + contact.getId());
        	System.out.println("contact.getChangeKey(): " + contact.getChangeKey());
        	System.out.println("contact.getFirstName(): " + contact.getFirstName());
        	System.out.println("contact.getSurname(): " + contact.getSurname());
        	System.out.println("contact.getFileAs(): " + contact.getFileAs());
        	System.out.println("contact.getJobTitle(): " + contact.getJobTitle());
        	System.out.println("contact.getCompanyName(): " + contact.getCompanyName());
        	System.out.println("contact.getEmailAddress1(): " + contact.getEmailAddress1());
        	System.out.println("contact.getEmailAddress2(): " + contact.getEmailAddress2());
        	System.out.println("contact.getEmailAddress3(): " + contact.getEmailAddress3());
        	System.out.println("contact.getImAddress1(): " + contact.getImAddress1());

        	System.out.println("contact.getBusinessPhone(): " + contact.getBusinessPhone());
        	System.out.println("contact.getHomePhone(): " + contact.getHomePhone());
        	System.out.println("contact.getMobilePhone(): " + contact.getMobilePhone());

        	if (contact.getBusinessAddress() != null) {
            	ExchangeAddressDTO business = contact.getBusinessAddress();
            	System.out.println("BusinessAddress:");
            	System.out.println(business.getStreet());
            	System.out.println(business.getCity());
            	System.out.println(business.getProvinceOrState());
            	System.out.println(business.getCountryOrRegion());
            	System.out.println(business.getPostcode());
            	System.out.println("");
            }
        	if (contact.getHomeAddress() != null) {
            	ExchangeAddressDTO home = contact.getHomeAddress();
            	System.out.println("HomeAddress:");
            	System.out.println(home.getStreet());
            	System.out.println(home.getCity());
            	System.out.println(home.getProvinceOrState());
            	System.out.println(home.getCountryOrRegion());
            	System.out.println(home.getPostcode());
            	System.out.println("");
            }
        	if (contact.getOtherAddress() != null) {
            	ExchangeAddressDTO other = contact.getOtherAddress();
            	System.out.println("OtherAddress:");
            	System.out.println(other.getStreet());
            	System.out.println(other.getCity());
            	System.out.println(other.getProvinceOrState());
            	System.out.println(other.getCountryOrRegion());
            	System.out.println(other.getPostcode());
            	System.out.println("");
            }

        	//System.out.println("contact.getItemClass(): " + contact.getItemClass());
            System.out.println("");
        }

    }



    public static void getPublicContactsExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);

        EWSGeneralConfiguration.setServerType(EWSGeneralConfiguration.SERVER_TYPE_KERIO);
        ArrayList contacts = connector.getPublicContacts();
        System.out.println("Public contacts size: " + contacts.size() );
        String id = ((EWSContactShallowDTO)contacts.get(0)).getId();
        System.out.println("getting the first public contact full info: " + id );

        EWSContactDTO contact =  connector.getFullContact(id);
    	System.out.println("contact.getId(): " + contact.getId());
    	System.out.println("contact.getChangeKey(): " + contact.getChangeKey());
    	System.out.println("contact.getFileAs(): " + contact.getFileAs());
    	System.out.println("contact.getJobTitle(): " + contact.getJobTitle());
    	System.out.println("contact.getCompanyName(): " + contact.getCompanyName());
    	System.out.println("contact.getEmailAddress1(): " + contact.getEmailAddress1());
    	System.out.println("contact.getEmailAddress2(): " + contact.getEmailAddress2());
    	System.out.println("contact.getEmailAddress3(): " + contact.getEmailAddress3());
    	System.out.println("contact.getImAddress1(): " + contact.getImAddress1());

    	System.out.println("contact.getBusinessPhone(): " + contact.getBusinessPhone());
    	System.out.println("contact.getHomePhone(): " + contact.getHomePhone());
    	System.out.println("contact.getMobilePhone(): " + contact.getMobilePhone());



    }


    public static void updateContactExample() throws ExchangeGeneralException {

    	EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);

        EWSGeneralConfiguration.setServerType(EWSGeneralConfiguration.SERVER_TYPE_KERIO);
        int pageNo = 1;
        String searchXmlStr ="<IndexedPageItemView MaxEntriesReturned=\"20\" Offset=\""
            + (pageNo - 1) * 20 + "\" BasePoint=\"Beginning\"/>";

        EWSSearchExpression searchExpression = new EWSSearchExpression(searchXmlStr);

        ArrayList contacts = connector.getContacts(searchExpression);

        if (contacts.size() > 0){
        	// updating the first contact
        	EWSContactDTO contact = new EWSContactDTO();
        	contact.setId(((EWSContactShallowDTO)contacts.get(0)).getId());

        	contact.setChangeKey(((EWSContactShallowDTO)contacts.get(0)).getChangeKey());

        	///// works, but does not updated in the list
        	contact.setFirstName("First-updated-1");
        	contact.setSurname("Last-updated-1");
        	contact.setMiddleName("middle-u1");
        	//////////


        	ExchangeAddressDTO businessAddress = new ExchangeAddressDTO();
            businessAddress.setStreet("test bu street up");
            businessAddress.setCity("test bu city u");
            businessAddress.setCountryOrRegion("test bu country u");
            businessAddress.setProvinceOrState("test bu province or state u");
            businessAddress.setPostcode("bu postcode u");
            contact.setBusinessAddress(businessAddress);


        	contact.setEmailAddress1("Email-u1");
        	contact.setCompanyName("Company-updated");
        	contact.setJobTitle("Title updated");
        	contact.setBusinessPhone("businessPhone updated");
        	contact.setBusinessFax("businessFax updated");
        	contact.setHomePhone("homePhone updated");
        	contact.setMobilePhone("mobilePhone updated");
        	contact.setImAddress1("imAddress1 updated");



        	String[] IdAndChangeKey = connector.updateContact(contact);
        	System.out.println("contact: " + IdAndChangeKey[0]  + " changeKey: " + IdAndChangeKey[1] + " updated.");
        }
        else {
        	System.out.println("No Contacts found.");
        }

    }


    public static void deleteContactExample() throws ExchangeGeneralException {


    	EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);

        EWSGeneralConfiguration.setServerType(EWSGeneralConfiguration.SERVER_TYPE_KERIO);
        int pageNo = 1;
        String searchXmlStr ="<IndexedPageItemView MaxEntriesReturned=\"20\" Offset=\""
            + (pageNo - 1) * 20 + "\" BasePoint=\"Beginning\"/>";

        EWSSearchExpression searchExpression = new EWSSearchExpression(searchXmlStr);

        ArrayList contacts = connector.getContacts(searchExpression);

        if (contacts.size() > 0){
        	System.out.println("Deleting the first contact");
        	String id = ((EWSContactShallowDTO)contacts.get(0)).getId();
        	String changeKey = ((EWSContactShallowDTO)contacts.get(0)).getChangeKey();
        	// delete(id, changeKey)
        	//connector.deleteItem(id , changeKey);
        	//connector.deleteItem(id , changeKey, ExchangeConstants.DELETE_TYPE_HARD_DELETE);
        	connector.deleteItem(id , changeKey, ExchangeConstants.DELETE_TYPE_MOVE_TO_DELETED_ITEMS);
        }
    }


    public static void createFolderExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);
        EWSGeneralConfiguration.setServerType(EWSGeneralConfiguration.SERVER_TYPE_KERIO);

        // creating a folder under root
        //String[] result = connector.createFolder(EWSFolderDTO.FOLDER_TYPE_CalendarFolder, "myCalendar");

        // creating a folder under calendar folder
        //String[] result = connector.createFolder("contacts", EWSFolderDTO.FOLDER_TYPE_ContactsFolder, "myContacts");
        String[] result = connector.createFolder("contacts", EWSFolderDTO.FOLDER_TYPE_ContactsFolder, "Clients(ERP)");
        if (result != null)
        	System.out.println("Folder id: " + result[0] + " Folder ChangeKey: " + result[1]);
    }


    public static void getAllFoldersExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);
        EWSGeneralConfiguration.setServerType(EWSGeneralConfiguration.SERVER_TYPE_KERIO);

        ArrayList folders = connector.getAllSubFoldersByParentFolderName("contacts", false);
        for (int i = 0; i < folders.size(); i++) {
            System.out.println(((EWSFolderDTO) folders.get(i)).getId());
            System.out.println(((EWSFolderDTO) folders.get(i)).getChangeKey());
            System.out.println(((EWSFolderDTO) folders.get(i)).getDisplayName());
            System.out.println(((EWSFolderDTO) folders.get(i)).getChildFolderCount());
            System.out.println(((EWSFolderDTO) folders.get(i)).getTotalCount());
            System.out.println(((EWSFolderDTO) folders.get(i)).getUnreadCount());
            System.out.println(((EWSFolderDTO) folders.get(i)).getFolderClass());
            System.out.println("");
        }

    }
    
    
    
    public static void getTasksAndFullTaskExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);
       
        EWSGeneralConfiguration.setServerType(EWSGeneralConfiguration.SERVER_TYPE_KERIO);
        
        int pageNo = 1;
        String searchXmlStr ="<IndexedPageItemView MaxEntriesReturned=\"20\" Offset=\""
            + (pageNo - 1) * 20 + "\" BasePoint=\"Beginning\"/>";
        
        EWSSearchExpression searchExpression = new EWSSearchExpression(searchXmlStr);

        // this is the only sorter allowed for Kerio
        EWSSorter sorter = new EWSSorter(EWSSorter.ORDER_ASCENDING, EWSSorter.FIELD_ORDER_ITEM_DateTimeReceived);

        ArrayList tasks = connector.getTasks(searchExpression, sorter);

        for (int i = 0; i < tasks.size(); i++) {
        	String id = ((EWSTaskShallowDTO) tasks.get(i)).getId();
        	String changeKey = ((EWSTaskShallowDTO) tasks.get(i)).getChangeKey();
        	System.out.println("Id: " + id);
        	System.out.println("changeKey: " + changeKey);
        	
        	if (i == 0) {
        		EWSTaskDTO task =  connector.getFullTask(id, changeKey);
        		System.out.println("task.getSubject(): " + task.getSubject());
        		System.out.println("task.getDueDate(): " + task.getDueDate());
        		System.out.println("task.getPercentComplete(): " + task.getPercentComplete());
        		System.out.println("task.getStatus(): " + task.getStatus());
        		System.out.println("task.getStartDate(): " + task.getStartDate());
        		System.out.println("task.getBody(): " + task.getBody());
    			

        	}
        }

    }




    public static void allBasicTaskOperationsExample() throws ExchangeGeneralException {

    	EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;
        EWSGeneralConfiguration.setServerType(EWSGeneralConfiguration.SERVER_TYPE_KERIO);

        connector = factory.createEWSConnector(_exchangeHost,
                _userName,
                _password,
                _prefix, _useSSL, _accountName);


        EWSTaskDTO task = new EWSTaskDTO();
        task.setSubject("test subject3");

        // EWS support only text body for Tasks, so, no HTML option here.
        task.setBody("Text Body");

        Date now = new Date();

        // now + one day
        Date due = new Date(now.getTime() + (1* 24 * 3600 * 1000));
        task.setDueDate(due);
        task.setStartDate(now);

        // due - 15min for the reminder
        task.setReminderDueBy(new Date(due.getTime() - (15 * 60 * 1000)));

        // a number between 0-100
        task.setPercentComplete("0");

        //  NotStarted
        // InProgress
        // Completed
        // WaitingOnOthers
        // Deferred
        task.setStatus(task.STATUS_NotStarted);

        // if more then 0% then the status need to change accordingly.
        //task.setPercentComplete("30");
        //task.setStatus("InProgress");

        task.setImportance(task.IMPORTANCE_High);

        String[] IdAndChangeKey = connector.createTask(task);

        System.out.println("ID: " + IdAndChangeKey[0] + " ChangeKey: " +   IdAndChangeKey[1]);



        /// update task ////////////////////////////////////////////////////////////////

        task.setId(IdAndChangeKey[0]);
        task.setChangeKey(IdAndChangeKey[1]);
        task.setBody(task.getBody() + " u");
        task.setSubject(task.getSubject() + " u");
        Date newStart = new Date(now.getTime() + (1 * 3600 * 1000));
        task.setStartDate(newStart);

        // now + 2 days
        Date newDue = new Date(now.getTime() + (2* 24 * 3600 * 1000));
        task.setDueDate(newDue);

        // due - 15min for the reminder
        task.setReminderDueBy(new Date(newDue.getTime() - (15 * 60 * 1000)));

        task.setPercentComplete("55");
        task.setStatus(task.STATUS_Deferred);
        // complete the task
        //task.setIsCompleted(true);

        task.setImportance(task.IMPORTANCE_Low);

        String[] result = connector.updateTask(task);
        System.out.println("ID: " + result[0] + " ChangeKey: " +   result[1]);

        /////////////////////////////////////////////////////////////////////////////////

        connector.deleteTask(result[0], result[1], ExchangeConstants.DELETE_TYPE_HARD_DELETE, ExchangeConstants.SEND_MEETING_CANCELLATIONS_ALL_AND_SAVE_COPY);

    }


    public static void getEventsAndFullEventExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);
        EWSGeneralConfiguration.setServerType(EWSGeneralConfiguration.SERVER_TYPE_KERIO);

        /*
        SimpleDateFormat dateFormat = new SimpleDateFormat(
        "yyyy-MM-dd HH:mm:ss");
        Date startDate = null;
        Date endDate = null;
        try {
        	startDate = dateFormat.parse("2011-02-07 06:00:00");
        	endDate = dateFormat.parse("2011-02-13 23:00:00");
        } catch (ParseException ex) {
        	ex.printStackTrace();
        }

        ArrayList events = connector.getEvents(startDate, endDate);
        */


        EWSGeneralConfiguration.setServerType(EWSGeneralConfiguration.SERVER_TYPE_KERIO);

        int pageNo = 1;
        String searchXmlStr ="<IndexedPageItemView MaxEntriesReturned=\"20\" Offset=\""
            + (pageNo - 1) * 20 + "\" BasePoint=\"Beginning\"/>";

        EWSSearchExpression searchExpression = new EWSSearchExpression(searchXmlStr);

        // this is the only sorter allowed for Kerio
        EWSSorter sorter = new EWSSorter(EWSSorter.ORDER_ASCENDING, EWSSorter.FIELD_ORDER_ITEM_DateTimeReceived);

        ArrayList events = connector.getEvents(searchExpression, sorter);



        System.out.println("Number of Events: " + events.size() );
        for (int i = 0; i < events.size(); i++) {
        	System.out.println(((EWSEventDTO) events.get(i)).getId());
        	System.out.println(((EWSEventDTO) events.get(i)).getChangeKey());
            System.out.println("");

            String id = ((EWSEventDTO)events.get(i)).getId();
    		String changeKey = ((EWSEventDTO)events.get(i)).getChangeKey();
    		System.out.println("===== Getting EventFull for Id: " + id + " changeKey:" + changeKey +" =====");

    		EWSEventDTO event = connector.getEventFull(id, changeKey);
    		System.out.println("event.getSubject(): " + event.getSubject());
    		System.out.println("getDescription (Body) " + event.getDescription());
    		System.out.println("isHtmlDescription (is HTML Body): " + event.isHtmlDescription());
    		System.out.println("event.getStartDate(): " + event.getStartDate());
    		System.out.println("event.getEndDate(): " + event.getEndDate());
    		System.out.println("event.getLocation(): " + event.getLocation());
    		System.out.println("event.getBusyStatus(): " + event.getBusyStatus());
    		System.out.println("event.getReminderMinutesBeforeStart(): " + event.getReminderMinutesBeforeStart());
    		System.out.println("event.isReminderIsSet(): " + event.isReminderIsSet());
    		System.out.println("event.getSensitivity(): " + event.getSensitivity());
    		
			//////////////////////////////getting event attendees ///////////////////////////
			if ( event.getTo()!= null) {
			System.out.println(" number of attendees: " + event.getTo().size());
			
				for (int j = 0; j < (event).getTo().size(); j++) {
					System.out.println("attendee " + j + ":" + ((ExchangeEventAttendeeDTO)(event).getTo().get(j)).getDisplayName() +
							" " + ((ExchangeEventAttendeeDTO)(event).getTo().get(j)).getEmailAddr()   );
				
					if (((ExchangeEventAttendeeDTO)(event).getTo().get(j)).getType() == 1) {
						System.out.println("REQUIRED");
					}
					else if (((ExchangeEventAttendeeDTO)(event).getTo().get(j)).getType() == 3) {
						System.out.println("OPTIONAL");
					}
					System.out.println("");
				}
			}
			////////////////////////////////////////////////////////////////////////////////////////////////

        }
    }


    public static void addEventExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);

        EWSGeneralConfiguration.setServerType(EWSGeneralConfiguration.SERVER_TYPE_KERIO);


        SimpleDateFormat dateFormat = new SimpleDateFormat(
                "yyyy-MM-dd HH:mm:ss");
        Date startDate = null;
        Date endDate = null;
        try {
        	startDate = dateFormat.parse("2013-02-14 12:00:00");
            endDate = dateFormat.parse("2013-02-14 13:00:00");
        } catch (ParseException ex) {
            ex.printStackTrace();
        }

        EWSEventDTO event = new EWSEventDTO();

        event.setSubject("test event5");

        //event.setDescription("my test event");
        event.setHtmlDescription(true);
        event.setDescription("&lt;b&gt;updated body&lt;b&gt;");
        //event.setCategoriesStr("<t:Categories><t:String>Business</t:String><t:String>School</t:String></t:Categories>");

        // setting a body that contain an html tag (using double encoding)
        //event.setDescription("&lt;b&gt;updated body &amp;lt;b&amp;gt;  &lt;b&gt;");


        event.setStartDate(startDate);
        event.setEndDate(endDate);
        event.setLocation("test location");
        //event.setReminderIsSet(true);
        //event.setReminderMinutesBeforeStart(10);

        String[] result = null;
		try {
			result = connector.createEvent(event);

			System.out.println("id: " + result[0]);
	        System.out.println("changeKey: " + result[1]);
		} catch (ExchangeGeneralException e) {

			e.printStackTrace();
		}


    }



    public static void updateEventExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);
        EWSGeneralConfiguration.setServerType(EWSGeneralConfiguration.SERVER_TYPE_KERIO);

        EWSGeneralConfiguration.setServerType(EWSGeneralConfiguration.SERVER_TYPE_KERIO);

        int pageNo = 1;
        String searchXmlStr ="<IndexedPageItemView MaxEntriesReturned=\"20\" Offset=\""
            + (pageNo - 1) * 20 + "\" BasePoint=\"Beginning\"/>";

        EWSSearchExpression searchExpression = new EWSSearchExpression(searchXmlStr);

        // this is the only sorter allowed for Kerio
        EWSSorter sorter = new EWSSorter(EWSSorter.ORDER_ASCENDING, EWSSorter.FIELD_ORDER_ITEM_DateTimeReceived);

        ArrayList events = connector.getEvents(searchExpression, sorter);



        System.out.println("Number of Events: " + events.size() );
        for (int i = 0; i < events.size(); i++) {
        	System.out.println(((EWSEventDTO) events.get(i)).getId());
        	System.out.println(((EWSEventDTO) events.get(i)).getChangeKey());
            System.out.println("");

            String id = ((EWSEventDTO)events.get(i)).getId();
    		String changeKey = ((EWSEventDTO)events.get(i)).getChangeKey();
    		System.out.println("===== Getting EventFull for Id: " + id + " changeKey:" + changeKey +" =====");

    		EWSEventDTO event = connector.getEventFull(id, changeKey);
    		System.out.println("event.getSubject(): " + event.getSubject());
    		System.out.println("getDescription (Body) " + event.getDescription());
    		System.out.println("isHtmlDescription (is HTML Body): " + event.isHtmlDescription());
    		System.out.println("event.getStartDate(): " + event.getStartDate());
    		System.out.println("event.getEndDate(): " + event.getEndDate());
    		System.out.println("event.getLocation(): " + event.getLocation());
    		System.out.println("event.getBusyStatus(): " + event.getBusyStatus());
    		System.out.println("event.getReminderMinutesBeforeStart(): " + event.getReminderMinutesBeforeStart());
    		System.out.println("event.isReminderIsSet(): " + event.isReminderIsSet());
    		System.out.println("event.getSensitivity(): " + event.getSensitivity());




    		if (i == events.size() - 1) {
    			System.out.println("Updating the last event...");
    			EWSEventDTO event2update = new EWSEventDTO();
    			event2update.setId(event.getId());
    			event2update.setChangeKey(event.getChangeKey());
    			//event2update.setSensitivity("Private");
    			event2update.setSubject(event.getSubject() + " updated");


    			// use this flag to append to the previous description (in some cases of HTML EWS will fail to append,
    			// in this cases you should use event.setAppendDescription(false) )
    			//event2update.setAppendDescription(true);

    			event2update.setDescription(" updated");

    			event2update.setLocation("Location updated2");


    			SimpleDateFormat dateFormat = new SimpleDateFormat(
    			"yyyy-MM-dd HH:mm:ss");
    			Date startDate1 = null;
    			Date endDate1 = null;
    			try {
    				startDate1 = dateFormat.parse("2013-02-14 14:00:00");
    				endDate1 = dateFormat.parse("2013-02-14 15:00:00");
    			} catch (ParseException ex) {
    				ex.printStackTrace();
    			}
    			event2update.setStartDate(startDate1);
    			event2update.setEndDate(endDate1);




    			try {
    				String[] idChangeKey = connector.updateEvent(event2update);
    				System.out.println("Id: " + idChangeKey[0] + " ChangeKey: " + idChangeKey[1]);

    			} catch (ExchangeGeneralException e) {
    				//
    				e.printStackTrace();
    			}
    		}

        }
    }



    public static void deleteItemExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);

        EWSGeneralConfiguration.setServerType(EWSGeneralConfiguration.SERVER_TYPE_KERIO);

        int pageNo = 1;
        String searchXmlStr ="<IndexedPageItemView MaxEntriesReturned=\"20\" Offset=\""
            + (pageNo - 1) * 20 + "\" BasePoint=\"Beginning\"/>";

        EWSSearchExpression searchExpression = new EWSSearchExpression(searchXmlStr);

        // this is the only sorter allowed for Kerio
        EWSSorter sorter = new EWSSorter(EWSSorter.ORDER_ASCENDING, EWSSorter.FIELD_ORDER_ITEM_DateTimeReceived);

        ArrayList events = connector.getEvents(searchExpression, sorter);



        System.out.println("Number of Events: " + events.size() );
        for (int i = 0; i < events.size(); i++) {


            String id = ((EWSEventDTO)events.get(i)).getId();
    		String changeKey = ((EWSEventDTO)events.get(i)).getChangeKey();





    		if (i == events.size() - 1) {
    			System.out.println("Deleting the last event...");
     	        //connector.deleteItem(id, changeKey);
    	        //connector.deleteItem(id, changeKey, ExchangeConstants.DELETE_TYPE_HARD_DELETE);
    	        connector.deleteItem(id, changeKey, ExchangeConstants.DELETE_TYPE_MOVE_TO_DELETED_ITEMS);




    		}

        }



    }


    /**
     * You can send email by setting the base64 mime content of the email with the to, cc, subject, body, 
     * And call the send.
     * You should set the attachments in the email using the regular way (not using mime).
     * @throws ExchangeGeneralException
     */
    public static void createEmailExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;
        connector = factory.createEWSConnector(_exchangeHost,
                _userName,
                _password,
                _prefix, _useSSL, _accountName);

        EWSGeneralConfiguration.setServerType(EWSGeneralConfiguration.SERVER_TYPE_KERIO);

        EWSEmailDTO email = new EWSEmailDTO();
        
        // Not in use, use Base64 Mime
        //email.setSubject("create email example3");
        //email.setBody("example body");
        
        email.setMimeContent("<Base64 mime content>");

        

        email.setImportance(email.IMPORTANCE_low);


        EmailAddressDTO[] bcc = new EmailAddressDTO[2];
        EmailAddressDTO bcc1 = new EmailAddressDTO();
        bcc1.setEmailAddress("test@testdomain.dk");
        EmailAddressDTO bcc2 = new EmailAddressDTO();
        bcc2.setEmailAddress("test@testdomain.dk");
        bcc[0] = bcc1;
        bcc[1] = bcc2;
        email.setBcc(bcc);


        //============ creates in drafts ========
        String[] idChangeKey = connector.createEmailInDrafts(email);
        System.out.println("Id: " + idChangeKey[0]);
        System.out.println("changeKey: " + idChangeKey[1]);
        //==================================================

        //  working only if using mime
        //connector.sendItem(idChangeKey, "sentitems", false);



    }


    public static void getEmailsExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);

        EWSGeneralConfiguration.setServerType(EWSGeneralConfiguration.SERVER_TYPE_KERIO);

        int pageNo = 1;
        String searchXmlStr ="<IndexedPageItemView MaxEntriesReturned=\"20\" Offset=\""
            + (pageNo - 1) * 20 + "\" BasePoint=\"Beginning\"/>";

        EWSSearchExpression searchExpression = new EWSSearchExpression(searchXmlStr);

        // this is the only sorter allowed for Kerio
        EWSSorter sorter = new EWSSorter(EWSSorter.ORDER_ASCENDING, EWSSorter.FIELD_ORDER_ITEM_DateTimeReceived);

        // un-commnent to change the default folder (inbox)
        //connector.setFolder("drafts");
        //connector.setFolder("sentitems");

        ArrayList emails = connector.getEmailsShallow(searchExpression, sorter);
        for (int i = 0; i < emails.size(); i++) {
        	String id = ((ExchangeEmailShallowDTO) emails.get(i)).getId();
        	String changeKey = ((ExchangeEmailShallowDTO) emails.get(i)).getChangeKey();
        	System.out.println("id: " + id);
        	System.out.println("changeKey: " + changeKey);
        	System.out.println(((ExchangeEmailShallowDTO) emails.get(i)).getChangeKey());
            System.out.println(((ExchangeEmailShallowDTO) emails.get(i)).getDateReceived());
            System.out.println(((ExchangeEmailShallowDTO) emails.get(i)).isRead());
            System.out.println("");
            
            // get the last email full info
            if (i == emails.size() -1 ) {
            	// no mime (faster)
            	//EWSEmailDTO email = connector.getFullEmail(id, changeKey);

            	// full mime content (base64), use JavaMail to parse it.
            	EWSEmailDTO email = connector.getFullEmail(id, changeKey, true);
        		System.out.println("id: " + ((EWSEmailDTO) email).getId());
        		System.out.println("changeKey: " + ((EWSEmailDTO) email).getChangeKey());
        		System.out.println("getSubject: " + ((EWSEmailDTO) email).getSubject());
        		System.out.println("getImportance: " + ((EWSEmailDTO) email).getImportance());
        		System.out.println("getItemClass: " + ((EWSEmailDTO) email).getItemClass());
        		System.out.println("getSensitivity: " + ((EWSEmailDTO) email).getSensitivity());
        		System.out.println("isRead: " + ((ExchangeEmailShallowDTO) emails.get(i)).isRead());
        		if ( email.getMimeContent() != null ) {
        			System.out.println("\n mime content (base64), use JavaMail to parse it.");
        			System.out.println("getMimeContent().length(): " + ((EWSEmailDTO) email).getMimeContent().length());
        		}
            }
        }

    }


    /**
     * possible values for the folder name
     * <xs:enumeration value="calendar" />
     * <xs:enumeration value="contacts" />
     * <xs:enumeration value="deleteditems" />
     * <xs:enumeration value="drafts" />
     * <xs:enumeration value="inbox" />
     * <xs:enumeration value="journal" />
     * <xs:enumeration value="notes" />
     * <xs:enumeration value="outbox" />
     * <xs:enumeration value="sentitems" />
     * <xs:enumeration value="tasks" />
     * <xs:enumeration value="msgfolderroot" />
     * <xs:enumeration value="publicfoldersroot" />
     * <xs:enumeration value="root" />
     * <xs:enumeration value="junkemail" />
     * <xs:enumeration value="searchfolders" />
     * <xs:enumeration value="voicemail" />
     */
    public static void getContactsFromUserDefinedFolderExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);


        EWSGeneralConfiguration.setServerType(EWSGeneralConfiguration.SERVER_TYPE_KERIO);


        ArrayList folders = connector.getAllFolders();
        //ArrayList folders = connector.getAllSubFoldersByParentFolderName("contacts", true);
        String folderId = null;

        /////////////////// find the Contacts folder Id /////
        for (int i = 0; i < folders.size(); i++) {
        	String displayName = ((EWSFolderDTO) folders.get(i)).getDisplayName();
        	System.out.println("displayName: " + displayName);
        	if (displayName.equals("test1")) {
        		folderId = ((EWSFolderDTO) folders.get(i)).getId();
        	}
        }
        //////////////////////////////////////////////////
        // the contacts will be retrieved from this Contacts folder,
        //this method can be used to retrieve contacts from any contacts sub-folder.
        connector.setFolder(folderId);
        //////////////////////////////////////////////////


        int pageNo = 1;
        String searchXmlStr ="<IndexedPageItemView MaxEntriesReturned=\"20\" Offset=\""
            + (pageNo - 1) * 20 + "\" BasePoint=\"Beginning\"/>";

        EWSSearchExpression searchExpression = new EWSSearchExpression(searchXmlStr);

        // this is the only sorter allowed for Kerio
        EWSSorter sorter = new EWSSorter(EWSSorter.ORDER_ASCENDING, EWSSorter.FIELD_ORDER_ITEM_DateTimeReceived);

        ArrayList contacts = connector.getContacts(searchExpression, sorter);

        // getting the first one
        if (contacts.size() > 0) {
        	String id = ((EWSContactShallowDTO) contacts.get(0)).getId();
        	System.out.println("id: " + id);
        	System.out.println("ChangeKey: " + ((EWSContactShallowDTO) contacts.get(0)).getChangeKey());



        	EWSContactDTO contact =  connector.getFullContact(id);
        	System.out.println("contact.getId(): " + contact.getId());
        	System.out.println("contact.getChangeKey(): " + contact.getChangeKey());
        	System.out.println("contact.getFirstName(): " + contact.getFirstName());
        	System.out.println("contact.getSurname(): " + contact.getSurname());
        	System.out.println("contact.getFileAs(): " + contact.getFileAs());
        	System.out.println("contact.getJobTitle(): " + contact.getJobTitle());
        	System.out.println("contact.getCompanyName(): " + contact.getCompanyName());
        	System.out.println("contact.getEmailAddress1(): " + contact.getEmailAddress1());
        	System.out.println("contact.getEmailAddress2(): " + contact.getEmailAddress2());
        	System.out.println("contact.getEmailAddress3(): " + contact.getEmailAddress3());
        	System.out.println("contact.getImAddress1(): " + contact.getImAddress1());

        	System.out.println("contact.getBusinessPhone(): " + contact.getBusinessPhone());
        	System.out.println("contact.getHomePhone(): " + contact.getHomePhone());
        	System.out.println("contact.getMobilePhone(): " + contact.getMobilePhone());

        	if (contact.getBusinessAddress() != null) {
            	ExchangeAddressDTO business = contact.getBusinessAddress();
            	System.out.println("BusinessAddress:");
            	System.out.println(business.getStreet());
            	System.out.println(business.getCity());
            	System.out.println(business.getProvinceOrState());
            	System.out.println(business.getCountryOrRegion());
            	System.out.println(business.getPostcode());
            	System.out.println("");
            }
        	if (contact.getHomeAddress() != null) {
            	ExchangeAddressDTO home = contact.getHomeAddress();
            	System.out.println("HomeAddress:");
            	System.out.println(home.getStreet());
            	System.out.println(home.getCity());
            	System.out.println(home.getProvinceOrState());
            	System.out.println(home.getCountryOrRegion());
            	System.out.println(home.getPostcode());
            	System.out.println("");
            }
        	if (contact.getOtherAddress() != null) {
            	ExchangeAddressDTO other = contact.getOtherAddress();
            	System.out.println("OtherAddress:");
            	System.out.println(other.getStreet());
            	System.out.println(other.getCity());
            	System.out.println(other.getProvinceOrState());
            	System.out.println(other.getCountryOrRegion());
            	System.out.println(other.getPostcode());
            	System.out.println("");
            }

        	//System.out.println("contact.getItemClass(): " + contact.getItemClass());
            System.out.println("");

        }



    }
    
    
    public static void resolveNameExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);
        // partial match
//        ArrayList resolvedNames = connector.resolveNames("tet");

        // exact match
        ArrayList resolvedNames = null;
		try {
			//resolvedNames = connector.resolveNames("test@domain.com");
			resolvedNames = connector.resolveNames("test@domain.com", ExchangeConstants.RESOLUTION_TYPE_CONTACT);
		} catch (Exception e) {
			AppLogger.getLogger().error(e.getMessage(), e);
		}
		
		
		EWSContactDTO contact = null;
        if (resolvedNames != null && resolvedNames.size() > 0 ) {
        	System.out.println("resolvedNames.size(): " + resolvedNames.size());
        	contact = (EWSContactDTO)resolvedNames.get(0);
        }
        else
        	return;

        System.out.println("contact.getFirstName(): " + contact.getFirstName());
        System.out.println("contact.getSurname(): " + contact.getSurname());
        System.out.println("contact.getDisplayName(): " + contact.getDisplayName());
        System.out.println("contact.getEmailAddress1(): " + contact.getEmailAddress1());
        System.out.println("contact.getEmailAddress1DisplayName(): " + contact.getEmailAddress1DisplayName());

        System.out.println("contact.getEmailAddress2(): " + contact.getEmailAddress2());
        System.out.println("contact.getBusinessPhone(): " + contact.getBusinessPhone());

        // Gal mailbox information
        System.out.println("contact.getGalUserId(): " + contact.getGalUserId());
        System.out.println("contact.getGalMailboxName(): " + contact.getGalMailboxName());
        System.out.println("contact.getGalMailboxEmailAddress(): " + contact.getGalMailboxEmailAddress());
        System.out.println("contact.getGalMailboxMailboxType(): " + contact.getGalMailboxMailboxType());
        System.out.println("contact.getGalMailboxRoutingType(): " + contact.getGalMailboxRoutingType());


        if (contact.getBusinessAddress() != null) {
        	ExchangeAddressDTO business = contact.getBusinessAddress();
        	System.out.println("BusinessAddress:");
        	System.out.println(business.getStreet());
        	System.out.println(business.getCity());
        	System.out.println(business.getProvinceOrState());
        	System.out.println(business.getCountryOrRegion());
        	System.out.println("");
        }


    }


}


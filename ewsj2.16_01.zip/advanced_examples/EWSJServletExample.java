import java.io.IOException;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jec.EWSConnectorInterface;
import jec.EWSConnectorFactory;
import jec.ExchangeConnectorFactory;
import jec.ExchangeConnectorInterface;
import jec.ExchangeGeneralException;


public class EWSJServletExample extends HttpServlet {
	public void doGet(HttpServletRequest request,
			HttpServletResponse response)
	throws ServletException, IOException {
		response.setContentType("text/html");
		System.out.println("EWSJ servlet is up!");
		response.getWriter().println("EWSJ servlet is up!");

		/*
		String _exchangeHost = "192.168.0.102";
		String _applicationUserAccountName = "test1";
		String _applicationUserPassword = "Kikaha58";
		String _prefix = "Exchange";
		String _mailboxName = "test1";
		boolean _useSSL = true;
		*/
		
		/*
		 String _exchangeHost = "owa.dsi.com";
		 // server.accountName = spddom\\oncwirecal
		 // server.password = qwerty.1
	     //String _applicationUserAccountName = "spddom\\ewirecal";
		 String _applicationUserAccountName = "spddom\\oncwirecal";
	     String _applicationUserPassword = "qwerty.1";
	     String _prefix = "Exchange";
	     String _mailboxName = "spddom\\ewirecal";
	     String _domain = "domain1.com";
	     boolean _useSSL = true;
	     String _email = "test1@domain1.com";
	     
	     
		 String _exchangeHost = "outlook.sfp-net.com";
	     String _applicationUserAccountName = "jf@cater�ngportal.dk";
	     String _applicationUserPassword = "jeppe���";
	     String _prefix = "Exchange";
	     String _mailboxName = "jf";
	     String _domain = "cater�ngportal.dk";
	     boolean _useSSL = true;
	     String _email = "test1@domain1.com";
	     
	     */
	     
	      String _exchangeHost = "remote.narcosia.com.au";
	      String _userName = "ros";
	      String _password = "Riverbend1.";
	      String _prefix = "Exchange";
	      String _accountName = "ros";
	      String _domain = "";
	      boolean _useSSL = true;
	      String _email = "test1@domain1.com";
	     
	     




		System.out.println("========================CLASSPATH============== ");
		System.out.println(getClasspathString());
		System.out.println("========================CLASSPATH============== ");
		EWSConnectorFactory factory = new EWSConnectorFactory("c:/projects/JEC/jec/lib");

		factory.setPrivkeystoreFullPath("c:/projects/JEC/jec/lib/privkeystore");


		response.getWriter().println("trying to init connector...");
		EWSConnectorInterface connector = null;

		connector = factory.createEWSConnector(_exchangeHost,
				_userName,
				_password,
				_prefix, _useSSL, _accountName);
		response.getWriter().println("connector created.");
		response.getWriter().println("username: " + _userName);
		connector.setUseNTLMAuthentication(true);

		try {
			ArrayList contacts = connector.getContacts();
			response.getWriter().println("contacts.size(): " + contacts.size());
			System.out.println("contacts.size(): " + contacts.size());
		} catch (ExchangeGeneralException ex) {
			ex.printStackTrace();
		}

	}
	
	private String getClasspathString() {
	     StringBuffer classpath = new StringBuffer();
	     ClassLoader applicationClassLoader = this.getClass().getClassLoader();
	     if (applicationClassLoader == null) {
	         applicationClassLoader = ClassLoader.getSystemClassLoader();
	     }
	     URL[] urls = ((URLClassLoader)applicationClassLoader).getURLs();
	      for(int i=0; i < urls.length; i++) {
	          classpath.append(urls[i].getFile()).append("\r\n");
	      }

	      return classpath.toString();
	  }


}

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import jec.EWSConnectorFactory;
import jec.EWSConnectorInterface;
import jec.EWSSearchExpression;
import jec.ExchangeConstants;
import jec.ExchangeGeneralException;
import jec.ZimbraConstants;
import jec.dto.AttachmentDTO;
import jec.dto.EWSContactDTO;
import jec.dto.EWSContactShallowDTO;
import jec.dto.EWSDTO;
import jec.dto.EWSEmailDTO;
import jec.dto.EWSEventDTO;
import jec.dto.EWSFolderDTO;
import jec.dto.EWSGeneralConfiguration;
import jec.dto.EWSNotificationEventDTO;
import jec.dto.EWSNotificationsSubscriptionDTO;
import jec.dto.EWSRecurrence;
import jec.dto.EWSTaskDTO;
import jec.dto.EWSTaskShallowDTO;
import jec.dto.EmailAddressDTO;
import jec.dto.ExchangeAddressDTO;
import jec.dto.ExchangeEmailShallowDTO;
import jec.dto.ExchangeEventAttendeeDTO;
import jec.utils.AppLogger;


public class ZimbraExamples {
	
	
	static String _prefix = "Exchange";
    static boolean _useSSL = true;
    static String _exchangeHost = "zimbra8.notify.net";
    static String _userName = "jectest1";
    static String _password = "jectest1";
    static String _accountName = "jectest1";
    static String _domain = "";
    static String _email = "";
    
    
    public static void main(String[] args) {
        try {
            BufferedReader in = new BufferedReader(new InputStreamReader(System.
                    in));
            String str = null;
            System.out.println("Welcome to EWSJ example!");
            System.out.println(
                    "To use the main default values just press <Enter>");
            System.out.println("");
            System.out.println("Please insert Exchange IP or host name: ");
            try {
                str = in.readLine();
            } catch (IOException ex1) {
                ex1.printStackTrace();
            }
            if ((str != null) && (!str.equals("")))
                _exchangeHost = str;
            System.out.println("Exchange Host:" + _exchangeHost);
            System.out.println("");

            System.out.println("Please insert Exchange user name: ");
            try {
                str = in.readLine();
            } catch (IOException ex1) {
                ex1.printStackTrace();
            }
            if ((str != null) && (!str.equals("")))
                _userName = str;
            System.out.println("");
            System.out.println("Application User Account Name:" +
                               _userName);

            System.out.print("Please insert Exchange password: ");
            try {
                str = in.readLine();
            } catch (IOException ex1) {
                ex1.printStackTrace();
            }
            if ((str != null) && (!str.equals("")))
                _password = str;
            System.out.println("");
            System.out.println("Application User Password:" +
                               _password);

            System.out.print(
                    "Please insert mailbox name (in most cases its the same as the user name): ");
            try {
                str = in.readLine();
            } catch (IOException ex1) {
                ex1.printStackTrace();
            }
            if ((str != null) && (!str.equals("")))
                _accountName = str;
            System.out.println("");
            System.out.println("Mailbox Name:" + _accountName);

            System.out.print(
                    "If your exchange is configured to use SSL/HTTPS write true, if not write false:");
            try {
                str = in.readLine();
            } catch (IOException ex1) {
                ex1.printStackTrace();
            }
            if ((str != null) && (!str.equals(""))) {
                if ((str.equals("true") || str.equals("True"))) {
                    _useSSL = true;
                } else if ((str.equals("false") || str.equals("False"))) {
                    _useSSL = false;
                }
            }
            System.out.println("");
            System.out.println("useSSL:" + _useSSL);

            //=========================================================================

            // General
            //getAllFoldersExample();
            //getFolderIdsExample();
            //deleteItemExample();
            //moveItemExample();
            //getPublicFoldersExample();
            //getFolderIdsWithMaxChangesReturnedExample();
            
            //contacts
            //createContactExample();
            //getContactFullExample();
            //updateContactExample();
            // not working
            //getContactWithFilterExample();
            //resolveNameExample();
            //getContactsExample();
            
            
            // Email
            // accept meeting issue since the is no meeting:AssociatedCalendarItemId
            //getEmailFullExample();
            //sendEmailExample();
            //updateEmailReadFlagExample();
            // not working
            //emailForwardOrReplyExample();
            //getEmailsShallowExample();
            //createEmailInDraftsExample();
            
            
            // Calendar Events
            //getEventFullExample();
            //updateEventExample();
            //createEventExample();
            //getRecurentEventExample();
            //createRecurrentEventExample();
            //updateEventTimezoneExample();
            //createAllDayEventExample();
            //createEventWithAttendeesExample();
            //acceptMeetingReqExample();
            //updateEventSingleItemExample();
            //getEventsExample();
            
            
            //Tasks
            //createTaskExample();
            //getTaskFullExample();
            //updateTaskExample();
            //getTasksExample();
            
            notificationsExample();
            
            //TODO
            //sendEmailExample();
            //deleteItemExample();
            
            
            
            //=========================================================================

        } catch (ExchangeGeneralException ex) {
            ex.printStackTrace();
        }
    }
    
    
    public static void getAllFoldersExample() throws ExchangeGeneralException {

        EWSConnectorFactory factory = new EWSConnectorFactory();
        EWSConnectorInterface connector = null;

        connector = factory.createEWSConnector(_exchangeHost,
                                               _userName,
                                               _password,
                                               _prefix, _useSSL, _accountName);

        ArrayList folders = connector.getAllFolders();
        for (int i = 0; i < folders.size(); i++) {
            System.out.println("Id: " + ((EWSFolderDTO) folders.get(i)).getId());
            System.out.println("ChangeKey: " + ((EWSFolderDTO) folders.get(i)).getChangeKey());
            System.out.println("DisplayName: " + ((EWSFolderDTO) folders.get(i)).getDisplayName());
            System.out.println("ChildFolderCount: " + ((EWSFolderDTO) folders.get(i)).getChildFolderCount());
            System.out.println("TotalCount: " + ((EWSFolderDTO) folders.get(i)).getTotalCount());
            System.out.println("UnreadCount: " + ((EWSFolderDTO) folders.get(i)).getUnreadCount());
            System.out.println("");
        }

    }

	
	
	
	
	 public static void getContactFullExample() throws ExchangeGeneralException {

	        EWSConnectorFactory factory = new EWSConnectorFactory();
	        EWSConnectorInterface connector = null;
	        
	        EWSGeneralConfiguration.setServerType(EWSGeneralConfiguration.SERVER_TYPE_ZIMBRA);

	        connector = factory.createEWSConnector(_exchangeHost,
	                                               _userName,
	                                               _password,
	                                               _prefix, _useSSL, _accountName);
	        
	        ArrayList items = connector.getItemsIds(ZimbraConstants.contactsFolderId);
	        for (int i = 0; i < items.size(); i++) {
	        	System.out.println("Id: " + ((EWSDTO) items.get(i)).getId());
	        	System.out.println("ChangeKey: " + ((EWSDTO) items.get(i)).getChangeKey());
	            System.out.println("");
	        }
	        
	        if (items.size() > 0) {
	        	
	        	EWSDTO item =  (EWSDTO)items.get(0);
	        	EWSContactDTO contact = connector.getFullContact(item.getId());

	        	System.out.println("getId: " + contact.getId());
	        	System.out.println("getChangeKey: " + contact.getChangeKey());
	        	System.out.println("getItemClass: " + contact.getItemClass());

	            System.out.println("getFirstName: " + contact.getFirstName());
	            System.out.println("getSurname: " + contact.getSurname());
	            System.out.println("getMiddleName: " + contact.getMiddleName());
	            System.out.println("getNickName: " + contact.getNickName());
	            System.out.println("getBirthday: " + contact.getBirthday());

	            System.out.println("getCompanyName: " + contact.getCompanyName());
	            System.out.println("getDepartment: " + contact.getDepartment());
	            System.out.println("getAssistantName: " + contact.getAssistantName());
	            System.out.println("getManager: " + contact.getManager());

	            System.out.println("getEmailAddress1: " + contact.getEmailAddress1());
	            System.out.println("getBusinessPhone: " + contact.getBusinessPhone());
	            System.out.println("getHomePhone: " + contact.getHomePhone());
	            System.out.println("getMobilePhone: " + contact.getMobilePhone());
	            System.out.println("getPrimaryPhone: " + contact.getPrimaryPhone());
	            System.out.println("getBody: " + contact.getBody());
	            if (contact.getBusinessAddress() != null) {
	            	ExchangeAddressDTO business = contact.getBusinessAddress();
	            	System.out.println("BusinessAddress:");
	            	System.out.println(business.getStreet());
	            	System.out.println(business.getCity());
	            	System.out.println(business.getProvinceOrState());
	            	System.out.println(business.getCountryOrRegion());
	            	System.out.println(business.getPostcode());
	            	System.out.println("");
	            }
	            if (contact.getHomeAddress() != null) {
	            	ExchangeAddressDTO home = contact.getHomeAddress();
	            	System.out.println("HomeAddress:");
	            	System.out.println(home.getStreet());
	            	System.out.println(home.getCity());
	            	System.out.println(home.getProvinceOrState());
	            	System.out.println(home.getCountryOrRegion());
	            	System.out.println(home.getPostcode());
	            	System.out.println("");
	            }
	            if (contact.getOtherAddress() != null) {
	            	ExchangeAddressDTO other = contact.getOtherAddress();
	            	System.out.println("OtherAddress:");
	            	System.out.println(other.getStreet());
	            	System.out.println(other.getCity());
	            	System.out.println(other.getProvinceOrState());
	            	System.out.println(other.getCountryOrRegion());
	            	System.out.println(other.getPostcode());
	            	System.out.println("");
	            }
	            System.out.println(contact.getImAddress1());
	            System.out.println(contact.getImAddress2());
	            System.out.println(contact.getImAddress3());
	            				
	            System.out.println("");
	 		}



	        else {
	        	System.out.println("No Contacts found");
	        }


	    }
	 
	 
	    public static void createContactExample() throws ExchangeGeneralException {

	        EWSConnectorFactory factory = new EWSConnectorFactory();
	        EWSConnectorInterface connector = null;

	        EWSGeneralConfiguration.setServerType(EWSGeneralConfiguration.SERVER_TYPE_ZIMBRA);

	        connector = factory.createEWSConnector(_exchangeHost,
	                                               _userName,
	                                               _password,
	                                               _prefix, _useSSL, _accountName);

	        ////// Setting contacts folder Id
	        connector.setFolder(ZimbraConstants.contactsFolderId);
	        /////////////////////////////////
	        
	        EWSContactDTO contact = new EWSContactDTO();
	        // set company name AT&T (& is a special character).
	        contact.setCompanyName("Company");
	        contact.setJobTitle("title");

	        contact.setManager("Manager");
	        contact.setDepartment("Department");
	        
	        // not working
	        //contact.setBirthday("2003-07-03T00:00:00.000-04:00");

	        contact.setAssistantName("assistantName");

	        contact.setEmailAddress1("test_email1@domain1.com");
	        contact.setEmailAddress2("test_email2@domain1.com");
	        contact.setEmailAddress3("test_email3@domain1.com");

//	        contact.setFileAs("test11 FileAs");
	        contact.setFirstName("firstName");
	        contact.setMiddleName("Middle");

	        contact.setSurname("lastName");
	        contact.setNickName("Nick");
	        
	        contact.setBusinessPhone("4234234232");
	        
	        ExchangeAddressDTO businessAddress = new ExchangeAddressDTO();
	        businessAddress.setStreet("test bu street");
	        businessAddress.setCity("test bu city");
	        businessAddress.setCountryOrRegion("test bu country");
	        // province or state
	        businessAddress.setProvinceOrState("test bu province or state");
	        businessAddress.setPostcode("bu postcode");
	        contact.setBusinessAddress(businessAddress);
	        
	        ExchangeAddressDTO homeAddress = new ExchangeAddressDTO();
	        homeAddress.setStreet("test ho street");
	        homeAddress.setCity("test ho city");
	        homeAddress.setCountryOrRegion("test ho country");
	        homeAddress.setProvinceOrState("test ho province or state");
	        homeAddress.setPostcode("ho postcode");
	        contact.setHomeAddress(homeAddress);
	        
	        ExchangeAddressDTO otherAddress = new ExchangeAddressDTO();
	        otherAddress.setStreet("test ot street");
	        otherAddress.setCity("test ot city");
	        otherAddress.setCountryOrRegion("test ot country");
	        otherAddress.setProvinceOrState("test ot province or state");
	        otherAddress.setPostcode("ot postcode");
	        contact.setOtherAddress(otherAddress);
	        
	        contact.setHomePhone("telHome");
	        contact.setMobilePhone("Mobile phone");
	        contact.setHomePhone2("telHome2");
	        contact.setBusinessPhone2("telBusiness2");
	        contact.setBusinessFax("business fax");
	        contact.setHomeFax("homeFax");
	        contact.setImAddress1("test imAddress1");
	        contact.setImAddress2("test imAddress2");
	        contact.setImAddress3("test imAddress3");
	        
	        contact.setBody("&lt;b&gt;bold body&lt;b&gt;");
	        contact.setBodyType(EWSContactDTO.BODY_TYPE_HTML);

	        String[] IdAndChangeKey = connector.createContact(contact);


	    }
	    
	    
	    
	    
	    
	    public static void getFolderIdsExample() throws ExchangeGeneralException {

	        EWSConnectorFactory factory = new EWSConnectorFactory();
	        EWSConnectorInterface connector = null;

	        EWSGeneralConfiguration.setServerType(EWSGeneralConfiguration.SERVER_TYPE_ZIMBRA);
	        EWSGeneralConfiguration.setUserAgent("MacOutlook");

	        connector = factory.createEWSConnector(_exchangeHost,
	                                               _userName,
	                                               _password,
	                                               _prefix, _useSSL, _accountName);
            
	        
	        ArrayList folderIds = connector.getItemsIds(ZimbraConstants.tasksFolderId);
	        
	        
	        for (int i = 0; i < folderIds.size(); i++) {
	        	System.out.println(((EWSDTO) folderIds.get(i)).getId());
	        	System.out.println(((EWSDTO) folderIds.get(i)).getChangeKey());

	            System.out.println("");
	        }

	    }
	    
	    
	    public static void getFolderIdsWithMaxChangesReturnedExample() throws ExchangeGeneralException {

	        EWSConnectorFactory factory = new EWSConnectorFactory();
	        EWSConnectorInterface connector = null;

	        EWSGeneralConfiguration.setServerType(EWSGeneralConfiguration.SERVER_TYPE_ZIMBRA);
	        EWSGeneralConfiguration.setUserAgent("MacOutlook");

	        connector = factory.createEWSConnector(_exchangeHost,
	                                               _userName,
	                                               _password,
	                                               _prefix, _useSSL, _accountName);
	        
	        
            
	        
	        ArrayList folderIds = connector.getItemsIds(ZimbraConstants.tasksFolderId, 20);
	        
	        
	        for (int i = 0; i < folderIds.size(); i++) {
	        	System.out.println(((EWSDTO) folderIds.get(i)).getId());
	        	System.out.println(((EWSDTO) folderIds.get(i)).getChangeKey());

	            System.out.println("");
	        }

	    }
	    
	    
	    public static void getEmailFullExample() throws ExchangeGeneralException {

	        EWSConnectorFactory factory = new EWSConnectorFactory();
	        EWSConnectorInterface connector = null;
	        
	        EWSGeneralConfiguration.setExchangeVersion(EWSGeneralConfiguration.EXCHANGE_VERSION_2010SP2);
	        
	        EWSGeneralConfiguration.setServerType(EWSGeneralConfiguration.SERVER_TYPE_ZIMBRA);

	        connector = factory.createEWSConnector(_exchangeHost,
	                                               _userName,
	                                               _password,
	                                               _prefix, _useSSL, _accountName);

	        
	        
	        
	        ArrayList items = connector.getItemsIds(ZimbraConstants.inboxFolderId);
	        for (int i = 0; i < items.size(); i++) {
	        	System.out.println("Id: " + ((EWSDTO) items.get(i)).getId());
	        	System.out.println("ChangeKey: " + ((EWSDTO) items.get(i)).getChangeKey());
	            System.out.println("");
	        }
	        
	        if (items.size() > 0) {
	        	
	        	EWSDTO item =  (EWSDTO)items.get(0);
	        	EWSEmailDTO email = connector.getFullEmail(item.getId(), item.getChangeKey(), true);
	        	
	        	System.out.println("getId: " + ((EWSEmailDTO) email).getId());
        		System.out.println("getChangeKey: " + ((EWSEmailDTO) email).getChangeKey());
        		System.out.println("getSubject: " + ((EWSEmailDTO) email).getSubject());
        		System.out.println("getDateCreated: " + ((EWSEmailDTO) email).getDateCreated());
        		System.out.println("getDateTimeReceived: " + ((EWSEmailDTO) email).getDateTimeReceived());
        		System.out.println("getDateTimeSent: " + ((EWSEmailDTO) email).getDateSent());	
        		System.out.println("getSensitivity: " + ((EWSEmailDTO) email).getSensitivity());
        		System.out.println("getSizeInBytes: " + ((EWSEmailDTO) email).getSizeInBytes());
        		System.out.println("getImportance: " + ((EWSEmailDTO) email).getImportance());
        		System.out.println("getItemClass: " + ((EWSEmailDTO) email).getItemClass());
        		System.out.println("isRead: " + ((EWSEmailDTO) email).isRead());
        		System.out.println("getBody: " + ((EWSEmailDTO) email).getBody());
        		System.out.println("isHtmlBody: " + ((EWSEmailDTO) email).isHtmlBody());
        		
        		        		
        		if (((EWSEmailDTO) email).getFrom() != null) {
        			EmailAddressDTO from = ((EWSEmailDTO) email).getFrom();
        			System.out.println("From (address, name): " +from.getEmailAddress() + " " + from.getName());
        		}
        		
        		if (((EWSEmailDTO) email).getTo() != null) {
        			EmailAddressDTO firstTo = ((EWSEmailDTO) email).getTo()[0];
        			System.out.println("To (name, address): " + firstTo.getName() +  ", "  + firstTo.getEmailAddress() );
        		}
        		
        		if (((EWSEmailDTO) email).getCc() != null) {
        			EmailAddressDTO firstCc = ((EWSEmailDTO) email).getCc()[0];
        			System.out.println("CC (address, name): " + firstCc.getEmailAddress() + " " + firstCc.getName());
        		}
        		if (((EWSEmailDTO) email).getBcc() != null) {
        			EmailAddressDTO firstBcc = ((EWSEmailDTO) email).getBcc()[0];
        			System.out.println("BCC (address, name): " + firstBcc.getEmailAddress() + " " + firstBcc.getName());
        		}
        		
        		System.out.println("");
        		System.out.println("getMimeContentCharacterSet: " + ((EWSEmailDTO) email).getMimeContentCharacterSet());
        		System.out.println("getMimeContent: " + ((EWSEmailDTO) email).getMimeContent());
        		System.out.println("");
	        	
	        }
	    }


	    
	    public static void getEventFullExample() throws ExchangeGeneralException {

	        EWSConnectorFactory factory = new EWSConnectorFactory();
	        EWSConnectorInterface connector = null;
	        
	        EWSGeneralConfiguration.setServerType(EWSGeneralConfiguration.SERVER_TYPE_ZIMBRA);

	        connector = factory.createEWSConnector(_exchangeHost,
	                                               _userName,
	                                               _password,
	                                               _prefix, _useSSL, _accountName);

	        
	        ArrayList items = connector.getItemsIds(ZimbraConstants.calendarFolderId);
	        for (int i = 0; i < items.size(); i++) {
	        	System.out.println("Id: " + ((EWSDTO) items.get(i)).getId());
	        	System.out.println("ChangeKey: " + ((EWSDTO) items.get(i)).getChangeKey());
	            System.out.println("");
	        }
	        
	        if (items.size() >= 0) {
	        	// getting the last created event
	        	EWSDTO item =  (EWSDTO)items.get(items.size() -1 );
	        	EWSEventDTO event = connector.getEventFull(item.getId(), item.getChangeKey());
	        	
	        	System.out.println("getId: " + event.getId());
	        	System.out.println("getChangeKey: " + event.getChangeKey());
	        	System.out.println("getSubject: " + event.getSubject());
	        	System.out.println("getSensitivity: " + event.getSensitivity());
	        	System.out.println("getItemClass: " + event.getItemClass());
	        	System.out.println("getMyResponseType: " + event.getMyResponseType());
	        	System.out.println("getDescription (Body): " + event.getDescription());
	        	if (!event.isAllDayEvent()) {
	        		System.out.println("getStartDate: " + event.getStartDate());
	        		System.out.println("getEndDate: " + event.getEndDate());
	        	}
	        	System.out.println("isReminderIsSet: " + event.isReminderIsSet());
	        	System.out.println("getReminderMinutesBeforeStart: " + event.getReminderMinutesBeforeStart());
	        	
	        	System.out.println("isAllDayEvent: " + event.isAllDayEvent());
//	        	if (event.isAllDayEvent()) {
//	        		System.out.println("getStartDateStr: " + event.getStartDateStr());
//	        		System.out.println("getEndDateStr: " + event.getEndDateStr());
//	        	}
	        	
	        	System.out.println("getBusyStatus: " + event.getBusyStatus());
	        	
	        	System.out.println("getOrganizer: " + event.getOrganizer());
	        	
		        //////////////////////////////getting event attendees ///////////////////////////
				if ( event.getTo()!= null) {
					System.out.println(" number of attendees: " + event.getTo().size());
		
					for (int j = 0; j < (event).getTo().
					size(); j++) {
						System.out.println("attendee " + j + ":" + ((ExchangeEventAttendeeDTO)(event).getTo().get(j)).getDisplayName() +
								" " + ((ExchangeEventAttendeeDTO)(event).getTo().get(j)).getEmailAddr()   );
		
						if (((ExchangeEventAttendeeDTO)(event).getTo().get(j)).getType() == 1) {
							System.out.println("REQUIRED");
						}
						else if (((ExchangeEventAttendeeDTO)(event).getTo().get(j)).getType() == 3) {
							System.out.println("OPTIONAL");
						}
						System.out.println("");
					}
				}
				////////////////////////////////////////////////////////////////////////////////////////////////
        		
	        }
	        
	    }
	    
	    
	    public static void updateContactExample() throws ExchangeGeneralException {

	    	EWSConnectorFactory factory = new EWSConnectorFactory();
	        EWSConnectorInterface connector = null;

	        EWSGeneralConfiguration.setServerType(EWSGeneralConfiguration.SERVER_TYPE_ZIMBRA);

	        connector = factory.createEWSConnector(_exchangeHost,
	                                               _userName,
	                                               _password,
	                                               _prefix, _useSSL, _accountName);

	        

	        ArrayList items = connector.getItemsIds(ZimbraConstants.contactsFolderId);
	        for (int i = 0; i < items.size(); i++) {
	        	System.out.println("Id: " + ((EWSDTO) items.get(i)).getId());
	        	System.out.println("ChangeKey: " + ((EWSDTO) items.get(i)).getChangeKey());
	            System.out.println("");
	        }
	        
	        if (items.size() > 0) {
	        	EWSDTO item =  (EWSDTO)items.get(0);
            	EWSContactDTO contact = new EWSContactDTO();
            	contact.setId(item.getId());
            	contact.setChangeKey(item.getChangeKey());
            	contact.setFirstName("first u");
            	contact.setMiddleName("middle u");
            	contact.setNickName("nick u");
            	
            	contact.setEmailAddress1("test1u@domain1.com");
            	contact.setEmailAddress1DisplayName("test1u disp");
            	contact.setEmailAddress2("test2u@domain1.com");
            	contact.setEmailAddress2DisplayName("addr2 disp");
            	contact.setCompanyName("company" + " u");
            	contact.setSurname("last u");
            	
            	contact.setBusinessPhone("23232323u");
            	contact.setBusinessPhone2("23232323u");
            	contact.setBusinessFax("23232323u");
            	contact.setHomePhone("23232323u");
            	contact.setHomePhone2("23232323u");
            	contact.setHomeFax("23232323u");
            	contact.setMobilePhone("23232323u");
            	
            	// Notes
            	contact.setBody("&lt;b&gt;updated body&lt;b&gt;");
            	contact.setBodyType(contact.BODY_TYPE_HTML);
            	
            	String[] IdAndChangeKey = connector.updateContact(contact);
            	System.out.println("contact: " + IdAndChangeKey[0]  + " changeKey: " + IdAndChangeKey[1] + " updated.");
            }
        }
	    
	    
	    public static void updateEventExample() throws ExchangeGeneralException {

	    	EWSConnectorFactory factory = new EWSConnectorFactory();
	        EWSConnectorInterface connector = null;

	        EWSGeneralConfiguration.setServerType(EWSGeneralConfiguration.SERVER_TYPE_ZIMBRA);

	        connector = factory.createEWSConnector(_exchangeHost,
	                                               _userName,
	                                               _password,
	                                               _prefix, _useSSL, _accountName);


	        ArrayList items = connector.getItemsIds(ZimbraConstants.calendarFolderId);
	        for (int i = 0; i < items.size(); i++) {
	        	System.out.println("Id: " + ((EWSDTO) items.get(i)).getId());
	        	System.out.println("ChangeKey: " + ((EWSDTO) items.get(i)).getChangeKey());
	            System.out.println("");
	        }
	        
	        if (items.size() >= 2) {
	        	EWSDTO item =  (EWSDTO)items.get(1);
	        	
	        	EWSEventDTO event = new EWSEventDTO();
	        	event.setId(item.getId());
	        	event.setChangeKey(item.getChangeKey());
	        	
	        	event.setSubject("Test2 updated");
	        	event.setDescription("body updated");
	        	event.setLocation("loc updated");
	        	event.setSensitivity("Private");
	        	
	        	// can use this strings instead of the Java date
	        	//event.setStartDateStr("2017-07-05T00:00:00+03:00");
	        	//event.setEndDateStr("2017-07-05T03:00:00+03:00");
	        	
	        	SimpleDateFormat dateFormat = new SimpleDateFormat(
		                "yyyy-MM-dd HH:mm:ss");
		        Date startDate = null;
		        Date endDate = null;
		        try {
		        	startDate = dateFormat.parse("2017-08-14 11:00:00");
		            endDate = dateFormat.parse("2017-08-14 12:00:00");
		        } catch (ParseException ex) {
		            ex.printStackTrace();
		        }
		        event.setStartDate(startDate);
		        event.setEndDate(endDate);
	        	
	        	// not working
	        	//event.setImportance(event._importance_HIGH);

	        	
	        	try {
	        		String[] idChangeKey = connector.updateEvent(event);
	        		System.out.println("Event Id: " + idChangeKey[0] + " ChangeKey: " + idChangeKey[1] + " updated.");

	        	} catch (ExchangeGeneralException e) {
	        		//
	        		e.printStackTrace();
	        	}
	        }
	    }
        
	    
	    public static void createTaskExample() throws ExchangeGeneralException {

	        EWSConnectorFactory factory = new EWSConnectorFactory();
	        EWSConnectorInterface connector = null;

	        EWSGeneralConfiguration.setServerType(EWSGeneralConfiguration.SERVER_TYPE_ZIMBRA);

	        connector = factory.createEWSConnector(_exchangeHost,
	                                               _userName,
	                                               _password,
	                                               _prefix, _useSSL, _accountName);

	        ////// Setting tasks folder Id
	        connector.setFolder(ZimbraConstants.tasksFolderId);
	        /////////////////////////////////
	        
	        EWSTaskDTO task = new EWSTaskDTO();
	        task.setSubject("test subject11");
	        task.setBody("Text Body");
	        
	        //task.setPercentComplete("10");
	        //task.setStatus(task.STATUS_InProgress);
	        
	        task.setComplete(true);
	        task.setStatus(task.STATUS_Completed);
	        task.setPercentComplete("100");
	        
	        Date now = new Date();
	        // now + one day
	        Date due = new Date(now.getTime() + (1* 24 * 3600 * 1000));
	        task.setDueDate(due);
	        task.setStartDate(now);
	        // due - 15min for the reminder
	        task.setReminderDueBy(new Date(due.getTime() + (15 * 60 * 1000)));
	        
	        
	        String[] IdAndChangeKey = connector.createTask(task);
	        System.out.println("Task Id: " + IdAndChangeKey[0]);
	    }
	    
	    
	    public static void getTaskFullExample() throws ExchangeGeneralException {

	        EWSConnectorFactory factory = new EWSConnectorFactory();
	        EWSConnectorInterface connector = null;
	        
	        EWSGeneralConfiguration.setServerType(EWSGeneralConfiguration.SERVER_TYPE_ZIMBRA);

	        connector = factory.createEWSConnector(_exchangeHost,
	                                               _userName,
	                                               _password,
	                                               _prefix, _useSSL, _accountName);

	        String taskId = "343";
	        
	        EWSTaskDTO task = connector.getFullTask(taskId, null);
	        System.out.println("getId: " + task.getId());
	        System.out.println("getChangeKey: " + task.getChangeKey());
	        
	        System.out.println("getSubject: " + task.getSubject());
	        System.out.println("getSensitivity: " + task.getSensitivity());
	        System.out.println("getImportance: " + task.getImportance());
	        System.out.println("getPercentComplete: " + task.getPercentComplete());
	        System.out.println("isComplete: " + task.isComplete());
			System.out.println("getBody: " + task.getBody());
			
			//System.out.println("getDueDate: " + task.getDueDateStr());
			//System.out.println("getStartDate: " + task.getStartDateStr());
			
			System.out.println("getDueDate: " + task.getDueDate());
			System.out.println("getStartDate: " + task.getStartDate());
			
	    }
	    
	    public static void getTasksExample() throws ExchangeGeneralException {

	    	EWSConnectorFactory factory = new EWSConnectorFactory();
	        EWSConnectorInterface connector = null;

	        EWSGeneralConfiguration.setServerType(EWSGeneralConfiguration.SERVER_TYPE_ZIMBRA);
	        EWSGeneralConfiguration.setUserAgent("MacOutlook");

	        connector = factory.createEWSConnector(_exchangeHost,
	                                               _userName,
	                                               _password,
	                                               _prefix, _useSSL, _accountName);
            
	        
	        ArrayList items = connector.getItemsIds(ZimbraConstants.tasksFolderId);
	        String[] ids = new String[items.size()];
	        for (int i = 0; i < items.size(); i++) {
	        	System.out.println("Id: " + ((EWSDTO) items.get(i)).getId());
	        	System.out.println("ChangeKey: " + ((EWSDTO) items.get(i)).getChangeKey());
	        	ids[i] = ((EWSDTO) items.get(i)).getId();
	            System.out.println("");
	        }

	        
	        ArrayList<EWSTaskDTO> tasks = connector.getFullTasks(ids, true);
	        System.out.println("tasks size: " + tasks.size());
	        
	        for (EWSTaskDTO task:tasks) {
		        System.out.println("getId: " + task.getId());
		        System.out.println("getChangeKey: " + task.getChangeKey());
		        System.out.println("getSubject: " + task.getSubject());
		        System.out.println("getSensitivity: " + task.getSensitivity());
		        System.out.println("getImportance: " + task.getImportance());
		        System.out.println("getPercentComplete: " + task.getPercentComplete());
		        System.out.println("isComplete: " + task.isComplete());
				System.out.println("getBody: " + task.getBody());
				System.out.println("getDueDate: " + task.getDueDate());
				System.out.println("getStartDate: " + task.getStartDate());
				System.out.println("");
	        }
			
			
	    }
	    
	    
	    public static void createEventExample() throws ExchangeGeneralException {

	        EWSConnectorFactory factory = new EWSConnectorFactory();
	        EWSConnectorInterface connector = null;

	        EWSGeneralConfiguration.setServerType(EWSGeneralConfiguration.SERVER_TYPE_ZIMBRA);

	        connector = factory.createEWSConnector(_exchangeHost,
	                                               _userName,
	                                               _password,
	                                               _prefix, _useSSL, _accountName);

	        ////// Setting calendar folder Id
	        connector.setFolder(ZimbraConstants.calendarFolderId);
	        /////////////////////////////////
	        
	        EWSEventDTO event = new EWSEventDTO();
	        event.setSubject("test event7");
	        
	        // You can also use the String format
	        //event.setStartDateStr("2017-07-05T08:00:00.000Z");
	        //event.setEndDateStr  ("2017-07-05T08:30:00.000Z");
	        
	        SimpleDateFormat dateFormat = new SimpleDateFormat(
	                "yyyy-MM-dd HH:mm:ss");
	        Date startDate = null;
	        Date endDate = null;
	        try {
	        	startDate = dateFormat.parse("2017-08-28 11:00:00");
	            endDate = dateFormat.parse("2017-08-28 12:00:00");
	        } catch (ParseException ex) {
	            ex.printStackTrace();
	        }
	        event.setStartDate(startDate);
	        event.setEndDate(endDate);
	        
	        
	        event.setDescription("my test event");
	        event.setLocation("test location");
	        event.setReminderIsSet(true);
	        event.setReminderMinutesBeforeStart(10);
	        
	        
	        String[] result = null;
			try {
				result = connector.createEvent(event);

				System.out.println("id: " + result[0]);
		        System.out.println("changeKey: " + result[1]);
			} catch (ExchangeGeneralException e) {

				e.printStackTrace();
			}
	    }
	    
	    
	    public static void updateTaskExample() throws ExchangeGeneralException {

	        EWSConnectorFactory factory = new EWSConnectorFactory();
	        EWSConnectorInterface connector = null;

	        EWSGeneralConfiguration.setServerType(EWSGeneralConfiguration.SERVER_TYPE_ZIMBRA);

	        connector = factory.createEWSConnector(_exchangeHost,
	                                               _userName,
	                                               _password,
	                                               _prefix, _useSSL, _accountName);

	        ////// Setting tasks folder Id
	        connector.setFolder("15");
	        /////////////////////////////////
	        
	        String taskId = "343";
	        
	        EWSTaskDTO taskF = connector.getFullTask(taskId, null);
	        System.out.println("getId: " + taskF.getId());
	        System.out.println("getChangeKey: " + taskF.getChangeKey());
	        
	        EWSTaskDTO task = new EWSTaskDTO();
	        task.setId("343");
	        task.setChangeKey(taskF.getChangeKey());
	        task.setSubject("test u1");
	        
	        //task.setPercentComplete("50");
	        
	        //task.setComplete(true);
	        task.setStatus(task.STATUS_InProgress);
	        task.setPercentComplete("60");
	        
	        // You can use date strings instead of the java dates below
	        //task.setStartDateStr("2017-07-17T07:33:56.000Z");
	        //task.setDueDateStr("2017-07-19T07:33:56.000Z");
	        //task.setReminderDueByStr("2017-07-19T07:30:56.000Z");
	        
	        Date now = new Date();
	        Date newStart = new Date(now.getTime() + (1 * 3600 * 1000));
	        task.setStartDate(newStart);
	        // now + 2 days
	        Date newDue = new Date(now.getTime() + (2* 24 * 3600 * 1000));
	        task.setDueDate(newDue);
	        // due - 15min for the reminder
	        task.setReminderDueBy(new Date(newDue.getTime() - (15 * 60 * 1000)));
	        
	        
	        task.setImportance(task.IMPORTANCE_High);
	        
	        String[] result = connector.updateTask(task);
	        System.out.println("Id: " + result[0] + " changeKey: " + result[1] );
	    }
	    
	    
	    public static void sendEmailExample() throws ExchangeGeneralException {

	        EWSConnectorFactory factory = new EWSConnectorFactory();
	        EWSConnectorInterface connector = null;
	        
	        EWSGeneralConfiguration.setServerType(EWSGeneralConfiguration.SERVER_TYPE_ZIMBRA);
	        
	        connector = factory.createEWSConnector(_exchangeHost,
	                _userName,
	                _password,
	                _prefix, _useSSL, _accountName);
	        
	        

	        EWSEmailDTO email = new EWSEmailDTO();
	        email.setSubject("test email 2");
	        email.setBody("example body");

	        email.setMimeContent("a1");

	        //email.setBody("&lt;b&gt;updated body&lt;b&gt;");
	        //email.setIsHtmlBody(true);
	        

	        EmailAddressDTO[] to = new EmailAddressDTO[1];
	        EmailAddressDTO to1 = new EmailAddressDTO();
	        to1.setEmailAddress("jectest2@zimbra8.notify.net");
	        to[0] = to1;
	        email.setTo(to);
	        
	        connector.sendEmail(email, ZimbraConstants.draftsFolderId);
	        
	    }
	    
	    
	    public static void deleteItemExample() throws ExchangeGeneralException {

	    	EWSConnectorFactory factory = new EWSConnectorFactory();
	        EWSConnectorInterface connector = null;
	        
	        EWSGeneralConfiguration.setServerType(EWSGeneralConfiguration.SERVER_TYPE_ZIMBRA);

	        connector = factory.createEWSConnector(_exchangeHost,
	                                               _userName,
	                                               _password,
	                                               _prefix, _useSSL, _accountName);

	        ////// Setting inbox folder Id
	        String folderId = "2";
	        /////////////////////////////////
	        
	        
	        ArrayList items = connector.getItemsIds(folderId);
	        if (items.size() >= 1) {
	          EWSDTO item = (EWSDTO)items.get(0);
		      connector.deleteItem(item.getId(), item.getChangeKey(), ExchangeConstants.DELETE_TYPE_MOVE_TO_DELETED_ITEMS);
	          
	        }
	        
	    }
	    
	    
	    public static void updateEmailReadFlagExample() throws ExchangeGeneralException {
	    	EWSConnectorFactory factory = new EWSConnectorFactory();
	        EWSConnectorInterface connector = null;
	        
	        EWSGeneralConfiguration.setServerType(EWSGeneralConfiguration.SERVER_TYPE_ZIMBRA);

	        connector = factory.createEWSConnector(_exchangeHost,
	                                               _userName,
	                                               _password,
	                                               _prefix, _useSSL, _accountName);

	        
	        
	        
	        ArrayList items = connector.getItemsIds(ZimbraConstants.inboxFolderId);
	        for (int i = 0; i < items.size(); i++) {
	        	System.out.println("Id: " + ((EWSDTO) items.get(i)).getId());
	        	System.out.println("ChangeKey: " + ((EWSDTO) items.get(i)).getChangeKey());
	            System.out.println("");
	        }
	        
	        if (items.size() > 0) {
	        	EWSDTO item = (EWSDTO)items.get(0);
	        	
	        	connector.updateEmailReadFlag(item.getId(), item.getChangeKey(), true);
	        	System.out.println("Email: " + item.getId() + " read flag updated");
	        }
	        else {
	        	System.out.println("No Email was found to update, change the subject2search param to find one");
	        }

	    }
	    
	    
	    public static void moveItemExample() throws ExchangeGeneralException {

	    	EWSConnectorFactory factory = new EWSConnectorFactory();
	        EWSConnectorInterface connector = null;
	        
	        EWSGeneralConfiguration.setServerType(EWSGeneralConfiguration.SERVER_TYPE_ZIMBRA);

	        connector = factory.createEWSConnector(_exchangeHost,
	                                               _userName,
	                                               _password,
	                                               _prefix, _useSSL, _accountName);

	        
	        
	        
	        ArrayList items = connector.getItemsIds(ZimbraConstants.inboxFolderId);
	        for (int i = 0; i < items.size(); i++) {
	        	System.out.println("Id: " + ((EWSDTO) items.get(i)).getId());
	        	System.out.println("ChangeKey: " + ((EWSDTO) items.get(i)).getChangeKey());
	            System.out.println("");
	        }
	        
	        if (items.size() > 0) {
	        	// getting the first email
	        	EWSDTO item = (EWSDTO)items.get(0);
	
	        	String[] idChangekey = connector.moveItem(ZimbraConstants.trashFolderId, item.getId(), null);
	        	if (idChangekey != null) {
	        	 System.out.println("Id: " + idChangekey[0]);
	             System.out.println("changeKey: " + idChangekey[1]);
	        	}
	        	
	        }
	        else {
	        	System.out.println("no emails found, you need some emails for this example.");
	        }

	    }
	    
	    // Add a new recurrent event, this method will get the last event added.
	    public static void getRecurentEventExample() throws ExchangeGeneralException {

	        EWSConnectorFactory factory = new EWSConnectorFactory();
	        EWSConnectorInterface connector = null;
	        
	        EWSGeneralConfiguration.setServerType(EWSGeneralConfiguration.SERVER_TYPE_ZIMBRA);

	        connector = factory.createEWSConnector(_exchangeHost,
	                                               _userName,
	                                               _password,
	                                               _prefix, _useSSL, _accountName);

	        
	        ArrayList items = connector.getItemsIds(ZimbraConstants.calendarFolderId);
	        
	        
	        if (items.size() > 0) {
	        	EWSDTO item =  (EWSDTO)items.get(items.size() - 1);
	        	EWSEventDTO event = connector.getEventFull(item.getId(), item.getChangeKey()); 	
	        	System.out.println("getId: " + event.getId());
	        	System.out.println("getChangeKey: " + event.getChangeKey());
	        	System.out.println("getSubject: " + event.getSubject());
	        	System.out.println("getSensitivity: " + event.getSensitivity());
	        	System.out.println("getItemClass: " + event.getItemClass());
	        	System.out.println("getDescription (Body): " + event.getDescription());
	        	System.out.println("getRecurrenceRule: " + event.getRecurrenceRule().getXmlStr());
	        	System.out.println("isRecurrent: " + event.isRecurrent());
	        	System.out.println("getOrganizer: " + event.getOrganizer());
	        	System.out.println("getDeletedOccurrencesStr: " + event.getDeletedOccurrencesStr());
	        	System.out.println("getModifiedOccurrencesStr: " + event.getModifiedOccurrencesStr());
	        }
	        
 	    }
	    
	    
	    public static void createRecurrentEventExample() throws ExchangeGeneralException {

	        EWSConnectorFactory factory = new EWSConnectorFactory();
	        EWSConnectorInterface connector = null;

	        EWSGeneralConfiguration.setServerType(EWSGeneralConfiguration.SERVER_TYPE_ZIMBRA);

	        connector = factory.createEWSConnector(_exchangeHost,
	                                               _userName,
	                                               _password,
	                                               _prefix, _useSSL, _accountName);

	        ////// Setting calendar folder Id
	        connector.setFolder(ZimbraConstants.calendarFolderId);
	        /////////////////////////////////
	        
	        EWSEventDTO event = new EWSEventDTO();
	        event.setSubject("test event5");
	        event.setStartDateStr("2017-07-28T08:00:00.000Z");
	        event.setEndDateStr  ("2017-07-28T08:30:00.000Z");
	        event.setDescription("my test recurrent event");
	        event.setLocation("test location");
	        EWSRecurrence recurrence = new EWSRecurrence("<t:Recurrence><t:DailyRecurrence><t:Interval>1</t:Interval></t:DailyRecurrence><t:NumberedRecurrence><t:StartDate>2017-07-28Z</t:StartDate><t:NumberOfOccurrences>10</t:NumberOfOccurrences></t:NumberedRecurrence></t:Recurrence>");
	        event.setRecurrenceRule(recurrence);
	        event.setReminderIsSet(true);
	        event.setReminderMinutesBeforeStart(10);
	        
	        
	        String[] result = null;
			try {
				result = connector.createEvent(event);

				System.out.println("id: " + result[0]);
		        System.out.println("changeKey: " + result[1]);
			} catch (ExchangeGeneralException e) {

				e.printStackTrace();
			}
	    }
	    
	    
	    public static void emailForwardOrReplyExample() throws ExchangeGeneralException {

	        EWSConnectorFactory factory = new EWSConnectorFactory();
	        EWSConnectorInterface connector = null;
	        
	        EWSGeneralConfiguration.setExchangeVersion(EWSGeneralConfiguration.EXCHANGE_VERSION_2010SP2);
	        
	        EWSGeneralConfiguration.setServerType(EWSGeneralConfiguration.SERVER_TYPE_ZIMBRA);

	        connector = factory.createEWSConnector(_exchangeHost,
	                                               _userName,
	                                               _password,
	                                               _prefix, _useSSL, _accountName);

	        
	        
	        
	        ArrayList items = connector.getItemsIds(ZimbraConstants.inboxFolderId);
	        for (int i = 0; i < items.size(); i++) {
	        	System.out.println("Id: " + ((EWSDTO) items.get(i)).getId());
	        	System.out.println("ChangeKey: " + ((EWSDTO) items.get(i)).getChangeKey());
	            System.out.println("");
	        }
	        
	        if (items.size() > 0) {
	        	
	        	EWSDTO item =  (EWSDTO)items.get(0);
	        	EWSEmailDTO email = connector.getFullEmail(item.getId(), item.getChangeKey(), true);
	        	
	        	EmailAddressDTO from = new EmailAddressDTO();
	        	from.setEmailAddress("jectest1@zimbra8.notify.net");
	        	
	        	EmailAddressDTO[] to = new EmailAddressDTO[2];
	            EmailAddressDTO to1 = new EmailAddressDTO();
	            to1.setEmailAddress("jectest1@zimbra8.notify.net");
	            EmailAddressDTO to2 = new EmailAddressDTO();
	            to2.setEmailAddress("jectest2@zimbra8.notify.net");
	            to[0] = to1;
	            to[1] = to2;

	            EmailAddressDTO[] cc = new EmailAddressDTO[2];
	            EmailAddressDTO cc1 = new EmailAddressDTO();
	            cc1.setEmailAddress("jectest1@zimbra8.notify.net");
	            EmailAddressDTO cc2 = new EmailAddressDTO();
	            cc2.setEmailAddress("jectest2@zimbra8.notify.net");
	            cc[0] = cc1;
	            cc[1] = cc2;
	            
	            
	            EWSEmailDTO forward = new EWSEmailDTO();
	            forward.setId(email.getId());
	            forward.setChangeKey(email.getChangeKey());
	            forward.setFrom(from);
	            forward.setTo(to);
	            forward.setCc(cc);
	            forward.setNewBodyContent("This is the forward body");
	            forward.setSubject("fw: new subject");
	            
	            connector.replyOrForwardEmail(forward, ZimbraConstants.sentFolderId, EWSEmailDTO.OPERATION_forward);
	        	
	        }
	    }
	    
	    
	    public static void updateEventTimezoneExample() throws ExchangeGeneralException {

	    	EWSConnectorFactory factory = new EWSConnectorFactory();
	        EWSConnectorInterface connector = null;

	        EWSGeneralConfiguration.setServerType(EWSGeneralConfiguration.SERVER_TYPE_ZIMBRA);
	       

	        connector = factory.createEWSConnector(_exchangeHost,
	                                               _userName,
	                                               _password,
	                                               _prefix, _useSSL, _accountName);


	        ArrayList items = connector.getItemsIds(ZimbraConstants.calendarFolderId);
	        for (int i = 0; i < items.size(); i++) {
	        	System.out.println("Id: " + ((EWSDTO) items.get(i)).getId());
	        	System.out.println("ChangeKey: " + ((EWSDTO) items.get(i)).getChangeKey());
	            System.out.println("");
	        }
	        
	        if (items.size() >= 1) {
	        	EWSDTO item =  (EWSDTO)items.get(0);
	        	
	        	EWSEventDTO event = new EWSEventDTO();
	        	event.setId(item.getId());
	        	event.setChangeKey(item.getChangeKey());
	        	
	        	// Exchange 2010sp1 and up :
	            EWSGeneralConfiguration.setExchangeVersion(EWSGeneralConfiguration.EXCHANGE_VERSION_2010SP1);
	            // its possible to set the Timezone Id String manually, find it via the registry, run the regedit command, then,
	            // search for "Time Zones", then find your spesific timezone, e.g "Eastern Standard Time":
	            event.setTimezoneStr(EWSGeneralConfiguration.TIMEZONE_ID_CANADA_CENTRAL);   	
	        	
	        	

	        	
	        	try {
	        		String[] idChangeKey = connector.updateEvent(event);
	        		System.out.println("Event Id: " + idChangeKey[0] + " ChangeKey: " + idChangeKey[1] + " updated.");

	        	} catch (ExchangeGeneralException e) {
	        		//
	        		e.printStackTrace();
	        	}
	        }
	    }
	    
	    
	    public static void createAllDayEventExample() throws ExchangeGeneralException {

	        EWSConnectorFactory factory = new EWSConnectorFactory();
	        EWSConnectorInterface connector = null;

	        EWSGeneralConfiguration.setServerType(EWSGeneralConfiguration.SERVER_TYPE_ZIMBRA);
	        EWSGeneralConfiguration.setExchangeVersion(EWSGeneralConfiguration.EXCHANGE_VERSION_2010SP2);

	        connector = factory.createEWSConnector(_exchangeHost,
	                                               _userName,
	                                               _password,
	                                               _prefix, _useSSL, _accountName);

	        ////// Setting calendar folder Id
	        connector.setFolder(ZimbraConstants.calendarFolderId);
	        /////////////////////////////////
	        
	        EWSEventDTO event = new EWSEventDTO();
	        event.setSubject("Allday test event8");
	        
	        SimpleDateFormat dateFormat = new SimpleDateFormat(
	                "yyyy-MM-dd HH:mm:ss");
	        Date startDate = null;
	        Date endDate = null;
	        try {
	        	startDate = dateFormat.parse("2017-09-11 00:00:00");
	            endDate = dateFormat.parse("2017-09-12 00:00:00");
	        } catch (ParseException ex) {
	            ex.printStackTrace();
	        }
	        event.setStartDate(startDate);
	        event.setEndDate(endDate);
	        
	        
	        
	        //event.setStartDateStr("2017-09-08T00:00:00");
	        //event.setEndDateStr("2017-09-09T00:00:00");
	        
	        event.setDescription("my test event");
	        event.setLocation("test location");
	        event.setReminderIsSet(true);
	        event.setReminderMinutesBeforeStart(10);
	        event.setBusyStatus(event._calendarBusyStatus_OUT_OF_OFFICE);
	        
	        event.setTimezoneStr( EWSGeneralConfiguration.TIMEZONE_ID_ISRAEL);
	        event.setAllDayEvent(true);
	        
	        
	        String[] result = null;
			try {
				result = connector.createEvent(event);

				System.out.println("id: " + result[0]);
		        System.out.println("changeKey: " + result[1]);
			} catch (ExchangeGeneralException e) {

				e.printStackTrace();
			}
	    }
	    
	    
	    public static void createEventWithAttendeesExample() throws ExchangeGeneralException {

	        EWSConnectorFactory factory = new EWSConnectorFactory();
	        EWSConnectorInterface connector = null;

	        EWSGeneralConfiguration.setServerType(EWSGeneralConfiguration.SERVER_TYPE_ZIMBRA);

	        connector = factory.createEWSConnector(_exchangeHost,
	                                               _userName,
	                                               _password,
	                                               _prefix, _useSSL, _accountName);

	        ////// Setting calendar folder Id
	        connector.setFolder(ZimbraConstants.calendarFolderId);
	        /////////////////////////////////
	        
	        EWSEventDTO event = new EWSEventDTO();
	        event.setSubject("test event with attendees");
	        event.setStartDateStr("2017-07-10T08:00:00.000Z");
	        event.setEndDateStr  ("2017-07-10T08:30:00.000Z");
	        event.setDescription("my test event");
	        event.setLocation("test location");
	        event.setReminderIsSet(true);
	        event.setReminderMinutesBeforeStart(10);
	        
	        ExchangeEventAttendeeDTO to2 = new ExchangeEventAttendeeDTO();
	        to2.setType(ExchangeEventAttendeeDTO.ATTENDEE_TYPE_REQUIRED);
	        to2.setEmailAddr("jectest1@zimbra8.notify.net");
	        event.addTo(to2);


	        ExchangeEventAttendeeDTO to3 = new ExchangeEventAttendeeDTO();
	        to3.setType(ExchangeEventAttendeeDTO.ATTENDEE_TYPE_OPTIONAL);
	        to3.setEmailAddr("jectest2@zimbra8.notify.net");
	        event.addTo(to3);
	        
	        
	        String[] result = null;
			try {
				result = connector.createEvent(event);

				System.out.println("id: " + result[0]);
		        System.out.println("changeKey: " + result[1]);
			} catch (ExchangeGeneralException e) {

				e.printStackTrace();
			}
	    }
	    
	    
	    public static void getPublicFoldersExample() throws ExchangeGeneralException {

	        EWSConnectorFactory factory = new EWSConnectorFactory();
	        EWSConnectorInterface connector = null;
	        EWSGeneralConfiguration.setServerType(EWSGeneralConfiguration.SERVER_TYPE_ZIMBRA);

	        connector = factory.createEWSConnector(_exchangeHost,
	                                               _userName,
	                                               _password,
	                                               _prefix, _useSSL, _accountName);

	        String xml = connector.findPublicFolders();
	        

	    }
	    
	    
	    public static void getContactWithFilterExample() throws ExchangeGeneralException {

	        EWSConnectorFactory factory = new EWSConnectorFactory();
	        EWSConnectorInterface connector = null;
	        
	        EWSGeneralConfiguration.setServerType(EWSGeneralConfiguration.SERVER_TYPE_ZIMBRA);
	        EWSGeneralConfiguration.setExchangeVersion(EWSGeneralConfiguration.EXCHANGE_VERSION_2010SP2);

	        connector = factory.createEWSConnector(_exchangeHost,
	                                               _userName,
	                                               _password,
	                                               _prefix, _useSSL, _accountName);
	        
	        String searchXmlStr ="<Restriction>"
	                +"<t:And>"
	                + "<t:IsEqualTo>"
	                + "<t:FieldURI FieldURI=\"contacts:GivenName\"/>"
	                 + "<t:FieldURIOrConstant>"
	                 + "<t:Constant Value=\"" + "first u"
	                 + "\"/>"
	                 + "</t:FieldURIOrConstant>"
	                 + "</t:IsEqualTo>"
	                 +"<t:IsEqualTo>"
	                 +"<t:FieldURI FieldURI=\"contacts:Surname\"/>"
	                 +"<t:FieldURIOrConstant>"
	                 +"<t:Constant Value=\"" + "last u" + "\"/>"
	                 +"</t:FieldURIOrConstant>"
	                 +"</t:IsEqualTo>"
	                 +"</t:And>"
	                +"</Restriction>";

	        EWSSearchExpression searchExpression = new EWSSearchExpression(searchXmlStr);

	        connector.setFolder(ZimbraConstants.contactsFolderId);
	        ArrayList contacts = connector.getContacts(searchExpression);
	        //ArrayList contacts = connector.getContacts();
	        for (int i = 0; i < contacts.size(); i++) {
	        	System.out.println("Id: " + ((EWSDTO) contacts.get(i)).getId());
	        	System.out.println("ChangeKey: " + ((EWSDTO) contacts.get(i)).getChangeKey());
	            System.out.println("");
	        }
/*	        
	        if (items.size() > 0) {
	        	
	        	EWSDTO item =  (EWSDTO)items.get(0);
	        	EWSContactDTO contact = connector.getFullContact(item.getId());

	        	System.out.println("getId: " + contact.getId());
	        	System.out.println("getChangeKey: " + contact.getChangeKey());
	        	System.out.println("getItemClass: " + contact.getItemClass());

	            System.out.println("getFirstName: " + contact.getFirstName());
	            System.out.println("getSurname: " + contact.getSurname());
	            	            				
	            System.out.println("");
	 		}
	 		



	        else {
	        	System.out.println("No Contacts found");
	        }
	        */


	    }
	    
	    
	    public static void acceptMeetingReqExample() throws ExchangeGeneralException {

	        EWSConnectorFactory factory = new EWSConnectorFactory();
	        EWSConnectorInterface connector = null;
	        
	        EWSGeneralConfiguration.setExchangeVersion(EWSGeneralConfiguration.EXCHANGE_VERSION_2010SP2);
	        
	        EWSGeneralConfiguration.setServerType(EWSGeneralConfiguration.SERVER_TYPE_ZIMBRA);

	        connector = factory.createEWSConnector(_exchangeHost,
	                                               "jectest2",
	                                               "jectest2",
	                                               _prefix, _useSSL, _accountName);

	        
	        
	        
	        ArrayList items = connector.getItemsIds(ZimbraConstants.inboxFolderId);
	        for (int i = 0; i < items.size(); i++) {
	        	System.out.println("Id: " + ((EWSDTO) items.get(i)).getId());
	        	System.out.println("ChangeKey: " + ((EWSDTO) items.get(i)).getChangeKey());
	            System.out.println("");
	        }
	        
	        if (items.size() > 0) {
	        	
	        	EWSDTO item =  (EWSDTO)items.get(items.size() - 1);
	        	EWSEmailDTO email = connector.getFullEmail(item.getId(), item.getChangeKey(), true);
	        	System.out.println("getId: " + ((EWSEmailDTO) email).getId());
        		System.out.println("getChangeKey: " + ((EWSEmailDTO) email).getChangeKey());
        		System.out.println("getSubject: " + ((EWSEmailDTO) email).getSubject());
        		System.out.println("getItemClass: " + ((EWSEmailDTO) email).getItemClass());
        		System.out.println("");
        		
        		if (((EWSEmailDTO) email).getItemClass().equals("IPM.Schedule.Meeting.Request")) {
        			String id = ((EWSEmailDTO) email).getId();
        			String changeKey = ((EWSEmailDTO) email).getChangeKey();
        			//connector.meetingReqAccept(id, changeKey);
        			connector.meetingReqDecline(id, changeKey);
                	//connector.meetingReqTentativelyAccept(id, changeKey);

        		}
        		else {
        			System.out.println("You need to make sure your first email is a meeting request");
        		}
	        	
	        }
	    }
	    
	    
	    
	    public static void getEmailsShallowExample() throws ExchangeGeneralException {

	        EWSConnectorFactory factory = new EWSConnectorFactory();
	        EWSConnectorInterface connector = null;
	        
	        EWSGeneralConfiguration.setExchangeVersion(EWSGeneralConfiguration.EXCHANGE_VERSION_2010SP2);
	        
	        EWSGeneralConfiguration.setServerType(EWSGeneralConfiguration.SERVER_TYPE_ZIMBRA);

	        connector = factory.createEWSConnector(_exchangeHost,
	                                               _userName,
	                                               _password,
	                                               _prefix, _useSSL, _accountName);

	        
	        
	        
	        ArrayList items = connector.getItemsIds(ZimbraConstants.inboxFolderId);
	        String[] ids = new String[items.size()];
	        for (int i = 0; i < items.size(); i++) {
	        	System.out.println("Id: " + ((EWSDTO) items.get(i)).getId());
	        	System.out.println("ChangeKey: " + ((EWSDTO) items.get(i)).getChangeKey());
	        	ids[i] = ((EWSDTO) items.get(i)).getId();
	            System.out.println("");
	        }
	        
	        if (items.size() > 0) {
	        	ArrayList emails = connector.getEmails(ids, false);
	        	System.out.println("emails size: " + emails.size());
	        	
	        	for (int i = 0; i < emails.size(); i++) {
	        		EWSEmailDTO email = (EWSEmailDTO)emails.get(i);
	        		
	        		System.out.println("getId: " + ((EWSEmailDTO) email).getId());
	        		System.out.println("getChangeKey: " + ((EWSEmailDTO) email).getChangeKey());
	        		System.out.println("getSubject: " + ((EWSEmailDTO) email).getSubject());
	        		System.out.println("getItemClass: " + ((EWSEmailDTO) email).getItemClass());
	        		System.out.println("isRead: " + ((EWSEmailDTO) email).isRead());
	        		System.out.println("isHasAttachment: " + ((EWSEmailDTO) email).isHasAttachment());
	        		
	        		System.out.println("getDateTimeReceived: " + ((EWSEmailDTO) email).getDateTimeReceived());
	        		System.out.println("getDateTimeSent: " + ((EWSEmailDTO) email).getDateSent());	
	        		
	        		System.out.println("getSensitivity: " + ((EWSEmailDTO) email).getSensitivity());
	        		System.out.println("getSizeInBytes: " + ((EWSEmailDTO) email).getSizeInBytes());
	        		System.out.println("getImportance: " + ((EWSEmailDTO) email).getImportance());
	        		System.out.println("getItemClass: " + ((EWSEmailDTO) email).getItemClass());
	        		
	        		if (((EWSEmailDTO) email).getFrom() != null) {
	        			EmailAddressDTO from = ((EWSEmailDTO) email).getFrom();
	        			System.out.println("From (address, name): " +from.getEmailAddress() + " " + from.getName());
	        		}
	        		
	        		if (((EWSEmailDTO) email).getTo() != null) {
	        			EmailAddressDTO firstTo = ((EWSEmailDTO) email).getTo()[0];
	        			System.out.println("To (name, address): " + firstTo.getName() +  ", "  + firstTo.getEmailAddress() );
	        		}
	        		
	        		if (((EWSEmailDTO) email).getCc() != null) {
	        			EmailAddressDTO firstCc = ((EWSEmailDTO) email).getCc()[0];
	        			System.out.println("CC (address, name): " + firstCc.getEmailAddress() + " " + firstCc.getName());
	        		}
	        		if (((EWSEmailDTO) email).getBcc() != null) {
	        			EmailAddressDTO firstBcc = ((EWSEmailDTO) email).getBcc()[0];
	        			System.out.println("BCC (address, name): " + firstBcc.getEmailAddress() + " " + firstBcc.getName());
	        		}
	        		
	        		System.out.println("");
	        	}
	        	
	        	
        		
	        }
	    }
	    
	    
	    public static void createEmailInDraftsExample() throws ExchangeGeneralException {

	        EWSConnectorFactory factory = new EWSConnectorFactory();
	        EWSConnectorInterface connector = null;
	        
	        EWSGeneralConfiguration.setServerType(EWSGeneralConfiguration.SERVER_TYPE_ZIMBRA);
	        
	        connector = factory.createEWSConnector(_exchangeHost,
	                _userName,
	                _password,
	                _prefix, _useSSL, _accountName);

	        EWSEmailDTO email = new EWSEmailDTO();
	        
	        // Works only with mime (as much as I currently know)
	        email.setMimeContent("a1");
	        
	        //email.setSubject("test email 3");
	        //email.setBody("example body");
	        //email.setBody("&lt;b&gt;updated body&lt;b&gt;");
	        //email.setIsHtmlBody(true);
	        //EmailAddressDTO[] to = new EmailAddressDTO[1];
	        //EmailAddressDTO to1 = new EmailAddressDTO();
	        //to1.setEmailAddress("jectest2@zimbra8.notify.net");
	        //to[0] = to1;
	        //email.setTo(to);
	        
	        connector.createEmail(email, ZimbraConstants.draftsFolderId);
	        
	    }
	    
	    
	    public static void resolveNameExample() throws ExchangeGeneralException {

	        EWSConnectorFactory factory = new EWSConnectorFactory();
	        EWSConnectorInterface connector = null;

	        connector = factory.createEWSConnector(_exchangeHost,
	                                               _userName,
	                                               _password,
	                                               _prefix, _useSSL, _accountName);
	        // partial match
	        //ArrayList resolvedNames = connector.resolveNames("test11");

	        // exact match
	        ArrayList resolvedNames = null;
			try {
				resolvedNames = connector.resolveNames("test10@domain1.com");
				//resolvedNames = connector.resolveNames("jectest1@zimbra8.notify.net");
				//resolvedNames = connector.resolveNames("jectest1");
			} catch (Exception e) {
				AppLogger.getLogger().error(e.getMessage(), e);
			}
			
			
			EWSContactDTO contact = null;
	        if (resolvedNames != null && resolvedNames.size() > 0 )
	        	contact = (EWSContactDTO)resolvedNames.get(0);
	        else
	        	return;

	        System.out.println(contact.getFirstName());
	        System.out.println(contact.getSurname());
	        System.out.println(contact.getEmailAddress1());
	        System.out.println(contact.getEmailAddress1DisplayName());

	        System.out.println(contact.getEmailAddress1());
	        System.out.println(contact.getBusinessPhone());

	        // Gal mailbox information
	        System.out.println("contact.getGalUserId(): " + contact.getGalUserId());
	        System.out.println("contact.getGalMailboxName(): " + contact.getGalMailboxName());
	        System.out.println("contact.getGalMailboxEmailAddress(): " + contact.getGalMailboxEmailAddress());
	        System.out.println("contact.getGalMailboxMailboxType(): " + contact.getGalMailboxMailboxType());
	        System.out.println("contact.getGalMailboxRoutingType(): " + contact.getGalMailboxRoutingType());


	        if (contact.getBusinessAddress() != null) {
	        	ExchangeAddressDTO business = contact.getBusinessAddress();
	        	System.out.println("BusinessAddress:");
	        	System.out.println(business.getStreet());
	        	System.out.println(business.getCity());
	        	System.out.println(business.getProvinceOrState());
	        	System.out.println(business.getCountryOrRegion());
	        	System.out.println("");
	        }


	    }
	    
	    
	    public static void updateEventSingleItemExample() throws ExchangeGeneralException {

	    	EWSConnectorFactory factory = new EWSConnectorFactory();
	        EWSConnectorInterface connector = null;

	        EWSGeneralConfiguration.setServerType(EWSGeneralConfiguration.SERVER_TYPE_ZIMBRA);

//	        connector = factory.createEWSConnector(_exchangeHost,
//	                                               _userName,
//	                                               _password,
//	                                               _prefix, _useSSL, _accountName);
	        
	        connector = factory.createEWSConnector(_exchangeHost,
                    "jectest2",
                    "jectest2",
                    _prefix, _useSSL, _accountName);


	        ArrayList items = connector.getItemsIds(ZimbraConstants.calendarFolderId);
	        for (int i = 0; i < items.size(); i++) {
	        	System.out.println("Id: " + ((EWSDTO) items.get(i)).getId());
	        	System.out.println("ChangeKey: " + ((EWSDTO) items.get(i)).getChangeKey());
	            System.out.println("");
	        }
	        
	        // updating the last item
	        if (items.size() > 0) {
	        	EWSDTO item =  (EWSDTO)items.get(items.size() - 1);
	        	
	        	EWSEventDTO event = new EWSEventDTO();
	        	event.setId(item.getId());
	        	event.setChangeKey(item.getChangeKey());
	        	
	        	// not working
	        	//event.updateReminder(true);
	        	//event.setReminderIsSet(false);
	        	
	        	//event.setSubject("test 8");
	        	//event.setSensitivity("Private");
	        	event.setBusyStatus(event._calendarBusyStatus_BUSY);
	        	
	        	try {
	        		String[] idChangeKey = connector.updateEvent(event);
	        		System.out.println("Event Id: " + idChangeKey[0] + " ChangeKey: " + idChangeKey[1] + " updated.");

	        	} catch (ExchangeGeneralException e) {
	        		//
	        		e.printStackTrace();
	        	}
	        }
	    }
	    
	    
	    
	    public static void getEventsExample() throws ExchangeGeneralException {

	        EWSConnectorFactory factory = new EWSConnectorFactory();
	        EWSConnectorInterface connector = null;
	        
	        EWSGeneralConfiguration.setServerType(EWSGeneralConfiguration.SERVER_TYPE_ZIMBRA);

	        connector = factory.createEWSConnector(_exchangeHost,
	                                               _userName,
	                                               _password,
	                                               _prefix, _useSSL, _accountName);

	        
	        ArrayList items = connector.getItemsIds(ZimbraConstants.calendarFolderId);
	        
	        EWSDTO[] ids = new EWSDTO[items.size()];
	        for (int i = 0; i < items.size(); i++) {
	        	System.out.println("Id: " + ((EWSDTO) items.get(i)).getId());
	        	System.out.println("ChangeKey: " + ((EWSDTO) items.get(i)).getChangeKey());
	        	ids[i] = ((EWSDTO) items.get(i));
	            System.out.println("");
	        }
	        
	        if (items.size() >= 0) {
	        	ArrayList<EWSEventDTO> events = connector.getEventsFull(ids);
	        	for (EWSEventDTO event: events) {
		        	System.out.println("getId: " + event.getId());
		        	System.out.println("getChangeKey: " + event.getChangeKey());
		        	System.out.println("getSubject: " + event.getSubject());
		        	System.out.println("getSensitivity: " + event.getSensitivity());
		        	System.out.println("getItemClass: " + event.getItemClass());
		        	System.out.println("getDescription (Body): " + event.getDescription());
		        	if (!event.isAllDayEvent()) {
		        		System.out.println("getStartDate: " + event.getStartDate());
		        		System.out.println("getEndDate: " + event.getEndDate());
		        	}
		        	System.out.println("isReminderIsSet: " + event.isReminderIsSet());
		        	System.out.println("getReminderMinutesBeforeStart: " + event.getReminderMinutesBeforeStart());
		        	
		        	System.out.println("isAllDayEvent: " + event.isAllDayEvent());
		        	
		        	System.out.println("getOrganizer: " + event.getOrganizer());
		        	
		        	if (event.isRecurrent()) {
		        		System.out.println("getRecurrenceRule: " + event.getRecurrenceRule().getXmlStr());
		        		System.out.println("getDeletedOccurrencesStr: " + event.getDeletedOccurrencesStr());
		        		System.out.println("getModifiedOccurrencesStr: " + event.getModifiedOccurrencesStr());
		        	}
		        	
			        //////////////////////////////getting event attendees ///////////////////////////
					if ( event.getTo()!= null) {
						System.out.println(" number of attendees: " + event.getTo().size());
			
						for (int j = 0; j < (event).getTo().
						size(); j++) {
							System.out.println("attendee " + j + ":" + ((ExchangeEventAttendeeDTO)(event).getTo().get(j)).getDisplayName() +
									" " + ((ExchangeEventAttendeeDTO)(event).getTo().get(j)).getEmailAddr()   );
			
							if (((ExchangeEventAttendeeDTO)(event).getTo().get(j)).getType() == 1) {
								System.out.println("REQUIRED");
							}
							else if (((ExchangeEventAttendeeDTO)(event).getTo().get(j)).getType() == 3) {
								System.out.println("OPTIONAL");
							}
							System.out.println("");
						}
					}
					////////////////////////////////////////////////////////////////////////////////////////////////
					
					System.out.println("");
	        	}
        		
	        }
	        
	    }
	    
	    
	    public static void getContactsExample() throws ExchangeGeneralException {

	    	EWSConnectorFactory factory = new EWSConnectorFactory();
	        EWSConnectorInterface connector = null;

	        EWSGeneralConfiguration.setServerType(EWSGeneralConfiguration.SERVER_TYPE_ZIMBRA);
	        
	        connector = factory.createEWSConnector(_exchangeHost,
	                                               _userName,
	                                               _password,
	                                               _prefix, _useSSL, _accountName);
            
	        
	        ArrayList items = connector.getItemsIds(ZimbraConstants.contactsFolderId);
	        String[] ids = new String[items.size()];
	        for (int i = 0; i < items.size(); i++) {
	        	System.out.println("Id: " + ((EWSDTO) items.get(i)).getId());
	        	System.out.println("ChangeKey: " + ((EWSDTO) items.get(i)).getChangeKey());
	        	ids[i] = ((EWSDTO) items.get(i)).getId();
	            System.out.println("");
	        }

	        
	        ArrayList<EWSContactDTO> contacts = connector.getFullContacts(ids, true);
	        System.out.println("contacts size: " + contacts.size());
	        
	        for (EWSContactDTO contact:contacts) {
		        System.out.println("getId: " + contact.getId());
		        System.out.println("getChangeKey: " + contact.getChangeKey());
		        System.out.println("getItemClass: " + contact.getItemClass());
	            System.out.println("getFirstName: " + contact.getFirstName());
	            System.out.println("getSurname: " + contact.getSurname());
	            System.out.println("getMiddleName: " + contact.getMiddleName());
	            System.out.println("getNickName: " + contact.getNickName());
	            System.out.println("getBirthday: " + contact.getBirthday());
	            System.out.println("getCompanyName: " + contact.getCompanyName());
	            System.out.println("getDepartment: " + contact.getDepartment());

				System.out.println("getBody: " + contact.getBody());
				System.out.println("");
	        }
			
			
	    }
	    
	    public static void notificationsExample() throws ExchangeGeneralException {
	    	
	    	EWSConnectorFactory factory = new EWSConnectorFactory();
	        EWSConnectorInterface connector = null;

	        EWSGeneralConfiguration.setServerType(EWSGeneralConfiguration.SERVER_TYPE_ZIMBRA);
	        
	        connector = factory.createEWSConnector(_exchangeHost,
	                                               _userName,
	                                               _password,
	                                               _prefix, _useSSL, _accountName);
            

	        connector.setFolder(ZimbraConstants.inboxFolderId);
	        
	        EWSNotificationsSubscriptionDTO notificationsSubscriptionDTO = connector.pullSubscriptionRequest(EWSNotificationsSubscriptionDTO.EVENT_TYPE_NewMailEvent, 10);
	        System.out.println("notificationsSubscriptionDTO.getSubscriptionId(): " + notificationsSubscriptionDTO.getSubscriptionId());
	        System.out.println("notificationsSubscriptionDTO.getWatermark(): " + notificationsSubscriptionDTO.getWatermark());
	        
	        

	        EWSEmailDTO email = new EWSEmailDTO();
	        email.setSubject("test email 2");
	        email.setBody("example body");
	        email.setMimeContent("a1");
	        EmailAddressDTO[] to = new EmailAddressDTO[1];
	        EmailAddressDTO to1 = new EmailAddressDTO();
	        to1.setEmailAddress("jectest2@zimbra8.notify.net");
	        to[0] = to1;
	        email.setTo(to);
	        connector.sendEmail(email, ZimbraConstants.draftsFolderId);
	        // sleep till email arrives
	        try {System.out.println("Sleeping 5 secs, waiting to for email to arrieve");Thread.sleep(5000);} catch (InterruptedException e) {}
	        
	        ArrayList notifications = connector.getNotificationEvents(notificationsSubscriptionDTO);


	        if (notifications.size() >= 1) {
	        	EWSNotificationEventDTO notification = (EWSNotificationEventDTO)notifications.get(0);
	        	System.out.println("notification.getNotificationType(): " + notification.getNotificationType());
	        	System.out.println("notification.getItemId(): " + notification.getItemId());
	        	System.out.println("notification.getItemChangeKey(): " + notification.getItemChangeKey());
	        	System.out.println("notification.getTimeStamp(): " + notification.getTimeStamp());
	        	System.out.println("notification.getWatermark(): " + notification.getWatermark());
	        	System.out.println("notification.getParentFolderId(): " + notification.getParentFolderId());
	        	System.out.println("notification.getParentFolderChangeKey(): " + notification.getParentFolderChangeKey());

	        	// getting the new email
	        	EWSEmailDTO newEmail = connector.getFullEmail(notification.getItemId());
	        	System.out.println("newEmail.getId(): " + newEmail.getId());
	        }
	        else {
	        	System.out.println("Didn't find the notification");
	        }

	        // remove the subscription
	        connector.unSubscriptionRequest(notificationsSubscriptionDTO);
	        
	    }


}
